# Enterprise RAG Agent v2.0

Fully offline, intranet-grade AI document assistant built on local LLMs (Ollama), ChromaDB, and DuckDB.

## Architecture

```
User Question
     │
     ▼
 Intent Router  ──── keyword heuristics + LLM classifier
     │
     ├── Semantic (PDF/DOCX/PPTX/TXT/Images)
     │       │
     │       ├── ChromaDB vector search
     │       ├── BM25 keyword search
     │       ├── RRF fusion
     │       ├── CrossEncoder reranker
     │       └── Ollama LLM → Answer
     │
     └── Tabular (CSV / Excel)
             │
             ├── DuckDB SQL generation
             ├── SQL validation (SELECT only)
             ├── Query execution
             └── Ollama LLM → Answer with exact numbers
```

## Directory Structure

```
rag_enterprise/
├── config/
│   └── settings.py          # All configuration (env-overridable)
├── api/
│   ├── app.py               # FastAPI application, middleware, routers
│   └── dependencies.py      # Singleton service instances
├── routers/
│   ├── ingest_router.py     # POST /ingest/upload, DELETE /ingest/source
│   ├── query_router_api.py  # POST /query/ask, POST /query/chat
│   ├── data_router.py       # GET /data/tables
│   └── memory_router.py     # GET/POST /memory/sessions
├── services/
│   ├── ingestion_service.py # Orchestrates text→ChromaDB / tabular→DuckDB
│   └── query_service.py     # Routes, retrieves, generates answers
├── database/
│   └── duckdb_manager.py    # CSV/Excel → DuckDB (accurate SQL math)
├── vectorstore/
│   └── chroma_store.py      # ChromaDB + BM25 + RRF + CrossEncoder reranker
├── ocr/
│   └── ocr_engine.py        # PaddleOCR primary, Tesseract fallback
├── loaders/
│   └── file_loader.py       # Universal loader: PDF/DOCX/PPTX/TXT/CSV/Excel/Images
├── core/
│   └── chunker.py           # Recursive chunking (800 tokens, 100 overlap)
├── tools/
│   ├── query_router.py      # Intent classification (semantic vs tabular)
│   └── sql_generator.py     # NL → DuckDB SQL generation + validation
├── memory/
│   └── conversation_memory.py  # SQLite multi-session conversation history
├── models/
│   └── schemas.py           # Pydantic request/response models
├── utils/
│   └── logger.py            # RotatingFileHandler logging per subsystem
├── logs/                    # Auto-created log files
├── data/                    # DuckDB + SQLite databases
├── chroma_db/               # ChromaDB persistent storage
├── requirements.txt
└── main.py                  # Entry point
```

## Quick Start

### 1. System dependencies
```bash
# Ubuntu/Debian
sudo apt-get install -y tesseract-ocr poppler-utils libgl1-mesa-glx
```

### 2. Install Ollama and pull models
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.2
ollama pull nomic-embed-text
# Optional: better SQL generation
ollama pull qwen
```

### 3. Python environment
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 4. Run
```bash
python main.py
# or
uvicorn main:app --host 0.0.0.0 --port 8000
```

### 5. Open the web UI
Open: http://localhost:8000  (or `http://<server-ip>:8000` from any intranet
machine). This is the full enterprise UI — chat, knowledge base, data
sources, model management, sessions, and system health — served directly
by the FastAPI app, no separate UI process required.

### 6. API docs
Open: http://localhost:8000/docs

## Environment Variables (all optional)

| Variable          | Default               | Description                      |
|-------------------|-----------------------|----------------------------------|
| OLLAMA_BASE_URL   | http://localhost:11434 | Ollama server URL               |
| LLM_MODEL         | llama3.2              | Chat model                       |
| EMBED_MODEL       | nomic-embed-text      | Embedding model                  |
| CHROMA_PATH       | ./chroma_db           | ChromaDB storage path            |
| DUCKDB_PATH       | ./data/tabular.duckdb | DuckDB file path                 |
| SQLITE_PATH       | ./data/memory.db      | Conversation memory path         |
| CHUNK_SIZE        | 800                   | Tokens per chunk                 |
| CHUNK_OVERLAP     | 100                   | Overlap tokens                   |
| TOP_K             | 5                     | Retrieval top-K                  |
| CONFIDENCE_THRESHOLD | 0.5                | Min confidence before warning    |

## Key API Endpoints

### Ingest
```
POST /ingest/upload          Upload files (multipart)
GET  /ingest/stats           Ingestion statistics
DELETE /ingest/source/{name} Remove source from ChromaDB
DELETE /ingest/table/{name}  Remove table from DuckDB
POST /ingest/reset           ⚠️ Reset all data
```

### Query
```
POST /query/ask              Ask a question (auto-routes)
POST /query/chat             Multi-turn chat with session
POST /query/sql/preview      Preview generated SQL
POST /query/sql/execute      Execute raw SQL SELECT
```

### Data
```
GET /data/tables             List DuckDB tables
GET /data/tables/{name}      Table metadata
GET /data/tables/{name}/preview  Preview rows
GET /data/sources            List ChromaDB sources
```

### Memory
```
POST   /memory/sessions                  Create session
GET    /memory/sessions                  List sessions
GET    /memory/sessions/{id}/history     Get chat history
DELETE /memory/sessions/{id}             Delete session
POST   /memory/sessions/{id}/clear       Clear messages
```

### System
```
GET /health    System health check
GET /          API overview
```

## Example Requests

### Upload files
```bash
curl -X POST http://localhost:8000/ingest/upload \
  -F "files=@employee_handbook.pdf" \
  -F "files=@salaries.xlsx"
```

### Ask a document question (semantic)
```bash
curl -X POST http://localhost:8000/query/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "What is the leave policy?"}'
```

### Ask a tabular question (DuckDB SQL)
```bash
curl -X POST http://localhost:8000/query/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "What is the total salary for the Engineering department?"}'
```

### Multi-turn chat
```bash
# First turn
curl -X POST http://localhost:8000/query/chat \
  -H "Content-Type: application/json" \
  -d '{"question": "Who is the highest paid employee?", "session_id": "sess_001"}'

# Follow-up
curl -X POST http://localhost:8000/query/chat \
  -H "Content-Type: application/json" \
  -d '{"question": "What department are they in?", "session_id": "sess_001"}'
```

## Supported File Types

| Type          | Extension           | Pipeline           |
|---------------|---------------------|--------------------|
| PDF (digital) | .pdf                | pypdf → ChromaDB   |
| PDF (scanned) | .pdf                | PaddleOCR → ChromaDB |
| Word          | .docx               | python-docx → ChromaDB |
| PowerPoint    | .pptx               | python-pptx → ChromaDB |
| Text/Markdown | .txt, .md           | Direct → ChromaDB  |
| Images        | .jpg, .png, .tiff   | PaddleOCR → ChromaDB |
| CSV           | .csv                | pandas → DuckDB    |
| Excel         | .xlsx, .xlsm        | pandas → DuckDB (per sheet) |

## Why This Architecture Prevents Hallucination

**Old (wrong) approach:**
```
Excel → convert to text → embed → ChromaDB → LLM "calculates" → WRONG NUMBERS
```

**New (correct) approach:**
```
Excel → DuckDB → SQL → exact numbers → LLM explains → CORRECT NUMBERS
```

Mathematical operations (SUM, AVG, COUNT, MAX, MIN, GROUP BY) are performed
by DuckDB's SQL engine — not estimated by the LLM — guaranteeing accuracy.
