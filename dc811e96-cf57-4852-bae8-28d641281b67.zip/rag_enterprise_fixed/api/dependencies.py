"""api/dependencies.py — Singleton service instances"""

_vector_store      = None
_duckdb_manager    = None
_ingestion_service = None
_query_service     = None
_memory            = None
_model_service     = None


def get_vector_store():
    global _vector_store
    if _vector_store is None:
        from vectorstore.chroma_store import VectorStore
        _vector_store = VectorStore()
    return _vector_store


def get_duckdb_manager():
    global _duckdb_manager
    if _duckdb_manager is None:
        from database.duckdb_manager import DuckDBManager
        _duckdb_manager = DuckDBManager()
    return _duckdb_manager


def get_ingestion_service():
    global _ingestion_service
    if _ingestion_service is None:
        from services.ingestion_service import IngestionService
        _ingestion_service = IngestionService(
            vector_store=get_vector_store(),
            duckdb_manager=get_duckdb_manager(),
        )
    return _ingestion_service


def get_query_service():
    global _query_service
    if _query_service is None:
        from services.query_service import QueryService
        _query_service = QueryService(
            vector_store=get_vector_store(),
            duckdb_manager=get_duckdb_manager(),
        )
    return _query_service


def get_model_service():
    """
    Singleton ModelService.
    Shares current_llm state with the QueryService instance so that
    switch_model() mutates both in one call.
    """
    global _model_service
    if _model_service is None:
        from services.model_service import ModelService
        from config.settings import OLLAMA_BASE_URL, LLM_MODEL, EMBED_MODEL
        _model_service = ModelService(
            ollama_url=OLLAMA_BASE_URL,
            current_llm=LLM_MODEL,
            current_embed=EMBED_MODEL,
        )
    return _model_service


def get_memory():
    global _memory
    if _memory is None:
        from memory.conversation_memory import ConversationMemory
        _memory = ConversationMemory()
    return _memory
