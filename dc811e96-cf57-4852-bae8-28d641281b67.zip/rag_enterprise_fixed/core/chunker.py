"""
core/chunker.py — Text chunking with token-aware overlap.

Splits documents into fixed-size chunks with overlap using tiktoken for accurate
token counting. Supports min/max chunk size filtering.
"""

import re
from typing import Any, Dict, List, Optional

from utils.logger import get_logger

logger = get_logger("chunker")


def _get_tokenizer():
    """Return tiktoken encoder, with graceful fallback."""
    try:
        import tiktoken
        return tiktoken.get_encoding("cl100k_base")
    except Exception:
        return None


def _token_count(text: str, tokenizer=None) -> int:
    """Count tokens in text. Falls back to word-based estimate."""
    if tokenizer is not None:
        try:
            return len(tokenizer.encode(text))
        except Exception:
            pass
    return len(text.split())


def _split_text(
    text: str,
    chunk_size: int,
    chunk_overlap: int,
    tokenizer=None,
) -> List[str]:
    """
    Split text into overlapping chunks of approximately chunk_size tokens.
    Uses sentence boundaries when possible to avoid mid-sentence splits.
    """
    # Split into sentences first for natural boundaries
    sentence_endings = re.compile(r"(?<=[.!?])\s+")
    sentences = sentence_endings.split(text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]

    if not sentences:
        return []

    chunks = []
    current_tokens = []
    current_size = 0

    for sentence in sentences:
        sent_tokens = sentence.split()  # approximate
        sent_size = _token_count(sentence, tokenizer)

        # If a single sentence exceeds chunk_size, hard-split it by words
        if sent_size > chunk_size:
            words = sentence.split()
            sub_chunk: List[str] = []
            sub_size = 0
            for word in words:
                word_size = _token_count(word, tokenizer)
                if sub_size + word_size > chunk_size and sub_chunk:
                    chunks.append(" ".join(sub_chunk))
                    # Keep overlap
                    overlap_words = sub_chunk[-max(1, chunk_overlap // 10):]
                    sub_chunk = overlap_words + [word]
                    sub_size = sum(_token_count(w, tokenizer) for w in sub_chunk)
                else:
                    sub_chunk.append(word)
                    sub_size += word_size
            if sub_chunk:
                current_tokens = sub_chunk
                current_size = sub_size
            continue

        # If adding this sentence would overflow, flush current chunk
        if current_size + sent_size > chunk_size and current_tokens:
            chunks.append(" ".join(current_tokens))
            # Keep overlap: retain tail of current chunk
            overlap_size = 0
            overlap_tokens = []
            for token in reversed(current_tokens):
                token_size = _token_count(token, tokenizer)
                if overlap_size + token_size > chunk_overlap:
                    break
                overlap_tokens.insert(0, token)
                overlap_size += token_size
            current_tokens = overlap_tokens
            current_size = overlap_size

        current_tokens.extend(sent_tokens)
        current_size += sent_size

    if current_tokens:
        chunks.append(" ".join(current_tokens))

    return chunks


def chunk_documents(
    documents: List[Dict[str, Any]],
    chunk_size: int = 800,
    chunk_overlap: int = 100,
    min_chunk_size: int = 50,
    max_chunk_size: int = 1200,
) -> List[Dict[str, Any]]:
    """
    Split a list of document dicts into chunks.

    Each document dict must have:
      - "text": str — the document text
      - "metadata": dict — source metadata (source_name, source, type, page/slide, etc.)

    Returns a list of chunk dicts with the same metadata schema plus "chunk_index".
    """
    tokenizer = _get_tokenizer()
    all_chunks: List[Dict[str, Any]] = []

    for doc in documents:
        text = doc.get("text", "").strip()
        metadata = dict(doc.get("metadata", {}))

        if not text:
            continue

        raw_chunks = _split_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap, tokenizer=tokenizer)

        for idx, chunk_text in enumerate(raw_chunks):
            chunk_text = chunk_text.strip()
            token_len = _token_count(chunk_text, tokenizer)

            # Skip chunks that are too small or too large
            if token_len < min_chunk_size:
                continue
            if token_len > max_chunk_size:
                # Re-split this oversized chunk
                sub_chunks = _split_text(
                    chunk_text,
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                    tokenizer=tokenizer,
                )
                for sub_idx, sub_text in enumerate(sub_chunks):
                    sub_text = sub_text.strip()
                    if _token_count(sub_text, tokenizer) >= min_chunk_size:
                        chunk_meta = dict(metadata)
                        chunk_meta["chunk_index"] = len(all_chunks)
                        chunk_meta["token_count"] = _token_count(sub_text, tokenizer)
                        all_chunks.append({"text": sub_text, "metadata": chunk_meta})
                continue

            chunk_meta = dict(metadata)
            chunk_meta["chunk_index"] = len(all_chunks)
            chunk_meta["token_count"] = token_len
            all_chunks.append({"text": chunk_text, "metadata": chunk_meta})

    logger.info(f"Chunked {len(documents)} docs → {len(all_chunks)} chunks")
    return all_chunks


def chunk_stats(chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Return summary statistics about a list of chunks."""
    if not chunks:
        return {"total_chunks": 0, "avg_tokens": 0, "min_tokens": 0, "max_tokens": 0}

    token_counts = [c.get("metadata", {}).get("token_count", len(c["text"].split())) for c in chunks]

    return {
        "total_chunks": len(chunks),
        "avg_tokens": round(sum(token_counts) / len(token_counts), 1),
        "min_tokens": min(token_counts),
        "max_tokens": max(token_counts),
    }
