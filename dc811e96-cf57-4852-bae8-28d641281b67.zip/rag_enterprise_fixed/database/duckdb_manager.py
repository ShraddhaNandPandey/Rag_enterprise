"""
database/duckdb_manager.py — Enterprise DuckDB Tabular Data Layer

Handles all CSV and Excel files with accurate SQL-based calculations.
Never uses embeddings for numerical data — prevents hallucination.
"""

import re
import json
import duckdb
import pandas as pd
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

from config.settings import DUCKDB_PATH, SQL_FORBIDDEN_PATTERNS
from utils.logger import get_logger

logger = get_logger("sql")


class DuckDBManager:
    """Manages tabular data ingestion and SQL query execution via DuckDB."""

    def __init__(self, db_path: str = DUCKDB_PATH):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[duckdb.DuckDBPyConnection] = None
        self._connect()
        logger.info(f"DuckDB initialized at: {db_path}")

    def _connect(self) -> None:
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass

        try:
            self._conn = duckdb.connect(database=self.db_path, read_only=False)
            return
        except duckdb.CatalogException as e:
            # A WAL (write-ahead log) file left over from an unclean shutdown (Ctrl+C,
            # crash, killed process mid-write) can conflict with what's already
            # committed in the main .duckdb file — DuckDB then refuses to even open
            # the database. The WAL only ever contains the *uncommitted* tail of the
            # last session, so it's always safe to drop it and reopen; at worst you
            # lose the last incomplete write, never previously-committed data.
            wal_path = Path(f"{self.db_path}.wal")
            if "already exists" in str(e) and wal_path.exists():
                logger.warning(
                    f"DuckDB WAL replay conflict on connect ({e}). This usually means the "
                    f"server was stopped uncleanly last time. Removing stale WAL file "
                    f"'{wal_path}' and retrying — any not-yet-committed writes from the "
                    f"last session are discarded, but previously saved tables are kept."
                )
                try:
                    wal_path.unlink()
                except Exception as unlink_err:
                    logger.error(f"Could not remove stale WAL file '{wal_path}': {unlink_err}")
                    raise
                self._conn = duckdb.connect(database=self.db_path, read_only=False)
                logger.info("DuckDB reconnected successfully after WAL recovery.")
                return
            raise

    @property
    def conn(self) -> duckdb.DuckDBPyConnection:
        try:
            self._conn.execute("SELECT 1")
        except Exception:
            logger.warning("DuckDB connection lost, reconnecting...")
            self._connect()
        return self._conn

    def _sanitize_table_name(self, name: str) -> str:
        name = Path(name).stem
        name = re.sub(r"[^a-zA-Z0-9_]", "_", name)
        name = re.sub(r"_+", "_", name).strip("_").lower()
        if name and name[0].isdigit():
            name = "t_" + name
        return name or "table_unnamed"

    def _ensure_unique_table_name(self, base_name: str) -> str:
        existing = {t.lower() for t in self.list_tables()}
        name = base_name
        counter = 1
        while name.lower() in existing:
            name = f"{base_name}_{counter}"
            counter += 1
        return name

    def _clean_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        df.columns = [
            re.sub(r"[^a-zA-Z0-9_]", "_", str(c)).strip("_").lower() or f"col_{i}"
            for i, c in enumerate(df.columns)
        ]
        seen: Dict[str, int] = {}
        new_cols = []
        for col in df.columns:
            if col in seen:
                seen[col] += 1
                new_cols.append(f"{col}_{seen[col]}")
            else:
                seen[col] = 0
                new_cols.append(col)
        df.columns = new_cols
        return df

    def _init_registry(self) -> None:
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS _rag_table_registry (
                table_name   VARCHAR PRIMARY KEY,
                source_file  VARCHAR,
                sheet_name   VARCHAR,
                row_count    INTEGER,
                col_count    INTEGER,
                columns_json VARCHAR,
                loaded_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

    def _register_metadata(self, table_name, source_file, sheet_name, row_count, col_count, columns):
        self._init_registry()
        self.conn.execute("""
            INSERT OR REPLACE INTO _rag_table_registry
            (table_name, source_file, sheet_name, row_count, col_count, columns_json)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [table_name, source_file, sheet_name, row_count, col_count, json.dumps(columns)])

    # ─── Public: Data Loading ─────────────────────────────────────────────

    def load_csv(self, file_path: str, table_name: Optional[str] = None, encoding: str = "utf-8") -> Dict[str, Any]:
        """Load a CSV or TSV file into a DuckDB table."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"CSV not found: {file_path}")
        # Auto-detect separator: .tsv files use tab, otherwise sniff
        sep = "\t" if path.suffix.lower() == ".tsv" else None
        try:
            df = pd.read_csv(file_path, encoding=encoding, encoding_errors="replace",
                             sep=sep, engine="python" if sep is None else "c")
        except Exception:
            df = pd.read_csv(file_path, encoding="latin-1", encoding_errors="replace",
                             sep=sep, engine="python" if sep is None else "c")

        df = self._clean_dataframe(df)
        tname = table_name or self._ensure_unique_table_name(self._sanitize_table_name(path.name))
        self.conn.execute(f'DROP TABLE IF EXISTS "{tname}"')
        self.conn.execute(f'CREATE TABLE "{tname}" AS SELECT * FROM df')
        self._register_metadata(tname, str(path), "", len(df), len(df.columns), list(df.columns))
        logger.info(f"Loaded CSV '{path.name}' -> table '{tname}' ({len(df)} rows)")
        return {"table_name": tname, "source_file": str(path), "sheet_name": None,
                "row_count": len(df), "col_count": len(df.columns), "columns": list(df.columns)}

    def load_excel(self, file_path: str, sheet_names: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Load Excel file — each sheet becomes a separate DuckDB table."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Excel not found: {file_path}")
        xl = pd.ExcelFile(file_path)
        sheets = sheet_names or xl.sheet_names
        results = []
        for sheet in sheets:
            try:
                df = xl.parse(sheet)
                df = self._clean_dataframe(df)
                base = self._sanitize_table_name(f"{path.stem}_{sheet}")
                tname = self._ensure_unique_table_name(base)
                self.conn.execute(f'DROP TABLE IF EXISTS "{tname}"')
                self.conn.execute(f'CREATE TABLE "{tname}" AS SELECT * FROM df')
                self._register_metadata(tname, str(path), sheet, len(df), len(df.columns), list(df.columns))
                logger.info(f"Loaded Excel '{path.name}' sheet '{sheet}' -> table '{tname}' ({len(df)} rows)")
                results.append({"table_name": tname, "source_file": str(path), "sheet_name": sheet,
                                "row_count": len(df), "col_count": len(df.columns), "columns": list(df.columns)})
            except Exception as e:
                logger.error(f"Failed to load sheet '{sheet}' from '{path.name}': {e}")
        return results

    def register_table(self, df: pd.DataFrame, table_name: str, source_file: str = "") -> str:
        """Register an in-memory DataFrame as a DuckDB table."""
        df = self._clean_dataframe(df)
        tname = self._ensure_unique_table_name(self._sanitize_table_name(table_name))
        self.conn.execute(f'DROP TABLE IF EXISTS "{tname}"')
        self.conn.execute(f'CREATE TABLE "{tname}" AS SELECT * FROM df')
        self._register_metadata(tname, source_file, "", len(df), len(df.columns), list(df.columns))
        return tname

    # ─── Public: Query Execution ──────────────────────────────────────────

    def validate_sql(self, sql: str) -> Tuple[bool, str]:
        """Validate SQL for safety (SELECT only)."""
        sql_upper = sql.upper().strip()
        if not (sql_upper.startswith("SELECT") or sql_upper.startswith("WITH")):
            return False, "Only SELECT queries are allowed."
        for pattern in SQL_FORBIDDEN_PATTERNS:
            if re.search(pattern, sql_upper, re.IGNORECASE):
                return False, f"Forbidden pattern detected: {pattern}"
        return True, "OK"

    def execute_query(self, sql: str) -> Dict[str, Any]:
        """Execute a validated SELECT query and return structured results."""
        is_valid, reason = self.validate_sql(sql)
        if not is_valid:
            logger.warning(f"SQL rejected: {reason} | SQL: {sql}")
            raise ValueError(f"Invalid SQL: {reason}")
        logger.info(f"Executing SQL: {sql}")
        try:
            result = self.conn.execute(sql).fetchdf()
            rows = result.to_dict(orient="records")
            for row in rows:
                for k, v in row.items():
                    if isinstance(v, float) and pd.isna(v):
                        row[k] = None
                    elif hasattr(v, "item"):
                        row[k] = v.item()
            logger.info(f"Query returned {len(rows)} row(s)")
            return {"columns": list(result.columns), "rows": rows,
                    "row_count": len(rows), "sql_executed": sql}
        except Exception as e:
            logger.error(f"SQL execution error: {e} | SQL: {sql}")
            raise RuntimeError(f"Query execution failed: {e}")

    # ─── Public: Introspection ─────────────────────────────────────────────

    def list_tables(self) -> List[str]:
        """List all user-created tables (excludes internal _rag_ registry tables)."""
        try:
            # Use starts_with() instead of LIKE ESCAPE to avoid SyntaxWarning in Python
            result = self.conn.execute(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = 'main' AND NOT starts_with(table_name, '_rag_')"
            ).fetchall()
            return [row[0] for row in result]
        except Exception as e:
            logger.error(f"list_tables failed: {e}")
            return []

    def get_schema(self, table_name: Optional[str] = None) -> str:
        """Return schema description for SQL generation prompt."""
        self._init_registry()
        try:
            query = "SELECT * FROM _rag_table_registry"
            params = []
            if table_name:
                query += " WHERE table_name = ?"
                params = [table_name]
            rows = self.conn.execute(query, params).fetchall()
        except Exception:
            rows = []

        if not rows:
            tables = self.list_tables()
            if not tables:
                return "No tabular data loaded."
            parts = []
            for t in tables:
                try:
                    cols = self.conn.execute(f'DESCRIBE "{t}"').fetchdf()
                    col_str = ", ".join(f"{r['column_name']} ({r['column_type']})" for _, r in cols.iterrows())
                    parts.append(f'Table: "{t}"\nColumns: {col_str}')
                except Exception:
                    parts.append(f'Table: "{t}" (schema unavailable)')
            return "\n\n".join(parts)

        parts = []
        for row in rows:
            tname, source_file, sheet_name, row_count, col_count, columns_json = row[:6]
            try:
                type_info = self.conn.execute(f'DESCRIBE "{tname}"').fetchdf()
                col_defs = [f"{r['column_name']} ({r['column_type']})" for _, r in type_info.iterrows()]
            except Exception:
                col_defs = json.loads(columns_json or "[]")
            source_label = Path(source_file).name if source_file else "unknown"
            sheet_label  = f" | Sheet: {sheet_name}" if sheet_name else ""
            parts.append(
                f'Table: "{tname}" | Source: {source_label}{sheet_label} | {row_count} rows\n'
                f'Columns: {", ".join(col_defs)}'
            )
        return "\n\n".join(parts)

    def get_table_info(self, table_name: str) -> Optional[Dict[str, Any]]:
        """Return metadata dict for a specific table."""
        self._init_registry()
        try:
            row = self.conn.execute(
                "SELECT * FROM _rag_table_registry WHERE table_name = ?", [table_name]
            ).fetchone()
            if not row:
                return None
            tname, source_file, sheet_name, row_count, col_count, columns_json = row[:6]
            return {"table_name": tname, "source_file": source_file, "sheet_name": sheet_name,
                    "row_count": row_count, "col_count": col_count, "columns": json.loads(columns_json or "[]")}
        except Exception as e:
            logger.error(f"get_table_info failed: {e}")
            return None

    def get_tables_by_source(self, source_name: str) -> List[Dict[str, Any]]:
        """
        Return all tables whose source_file basename matches source_name.
        Used by the delete-document flow to find all DuckDB tables for a file.
        """
        self._init_registry()
        try:
            rows = self.conn.execute(
                "SELECT * FROM _rag_table_registry"
            ).fetchall()
            result = []
            for row in rows:
                tname, source_file, sheet_name, row_count, col_count, columns_json = row[:6]
                if Path(source_file).name == source_name:
                    result.append({
                        "table_name":  tname,
                        "source_file": source_file,
                        "sheet_name":  sheet_name,
                        "row_count":   row_count,
                        "col_count":   col_count,
                        "columns":     json.loads(columns_json or "[]"),
                    })
            return result
        except Exception as e:
            logger.error(f"get_tables_by_source failed: {e}")
            return []

    def drop_table(self, table_name: str) -> bool:
        """Remove a table from DuckDB."""
        try:
            self.conn.execute(f'DROP TABLE IF EXISTS "{table_name}"')
            self._init_registry()
            self.conn.execute("DELETE FROM _rag_table_registry WHERE table_name = ?", [table_name])
            logger.info(f"Dropped table '{table_name}'")
            return True
        except Exception as e:
            logger.error(f"drop_table failed: {e}")
            return False

    def reset(self) -> None:
        """Drop all user tables and registry."""
        tables = self.list_tables()
        for t in tables:
            self.conn.execute(f'DROP TABLE IF EXISTS "{t}"')
        try:
            self.conn.execute("DROP TABLE IF EXISTS _rag_table_registry")
        except Exception:
            pass
        logger.info(f"DuckDB reset: dropped {len(tables)} table(s)")


    def get_schema_with_samples(self, table_name: Optional[str] = None, sample_rows: int = 3) -> tuple:
        """
        FIX v2: Return (schema_str, sample_rows_str) together.
        Providing sample rows to the SQL generator dramatically improves accuracy
        because the LLM can see actual values, not just column names.
        """
        schema = self.get_schema(table_name)
        samples_parts = []
        tables = [table_name] if table_name else self.list_tables()
        for t in tables:
            try:
                result = self.conn.execute(f'SELECT * FROM "{t}" LIMIT {sample_rows}').fetchdf()
                sample_str = result.to_string(index=False, max_cols=10)
                samples_parts.append(f'Table "{t}" sample:\n{sample_str}')
            except Exception:
                pass
        return schema, "\n\n".join(samples_parts) if samples_parts else None

    def close(self) -> None:
        """Close the DuckDB connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
