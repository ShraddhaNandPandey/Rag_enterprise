@echo off
REM ═══════════════════════════════════════════════════════════
REM  Enterprise RAG Agent — One-click fix script (Windows)
REM  Run this ONCE after downloading the fixed zip.
REM ═══════════════════════════════════════════════════════════

echo.
echo  Installing/pinning required packages...
echo.

pip install "gradio==5.38.0"           --quiet
pip install "chromadb==1.5.9"          --quiet
pip install "duckdb==1.5.4"            --quiet
pip install "sentence-transformers"    --quiet
pip install "fastapi>=0.111.0"         --quiet
pip install "uvicorn[standard]>=0.29.0" --quiet
pip install "python-multipart>=0.0.9"  --quiet
pip install "rank-bm25>=0.2.2"         --quiet
pip install "tiktoken>=0.7.0"          --quiet
pip install "pypdf>=4.0.0"             --quiet
pip install "python-docx>=1.1.0"       --quiet
pip install "pandas>=2.2.0"            --quiet
pip install "openpyxl>=3.1.0"          --quiet
pip install "python-dotenv>=1.0.0"     --quiet

echo.
echo  Checking Ollama is running...
curl -s http://localhost:11434/api/tags > nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo  [WARNING] Ollama is NOT running. Start it with:  ollama serve
    echo            Then pull model with:                  ollama pull llama3.2
    echo            And pull embeddings with:              ollama pull nomic-embed-text
) ELSE (
    echo  [OK] Ollama is running.
)

echo.
echo  ═══════════════════════════════════════════════
echo  All done! Now run in two separate terminals:
echo    Terminal 1:  python main.py
echo    Terminal 2:  python ui.py
echo  ═══════════════════════════════════════════════
echo.
pause
