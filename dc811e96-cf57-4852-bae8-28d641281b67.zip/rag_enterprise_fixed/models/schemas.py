"""
models/schemas.py — Pydantic request/response schemas for FastAPI
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


# ─── Request Models ───────────────────────────────────────────────────────────

class AskRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=2000)
    session_id: Optional[str] = None
    filters: Optional[Dict[str, Any]] = None
    k: int = Field(default=5, ge=1, le=20)
    # Multi-document scoping: restrict retrieval to these filenames.
    # None / [] = search ALL documents (default behaviour).
    source_names: Optional[List[str]] = Field(
        default=None,
        description="Restrict retrieval to these document filenames. None or [] = all docs.",
    )
    # When True + source_names has 2+ docs: return one answer per doc + a synthesised answer.
    per_document_answers: bool = Field(
        default=False,
        description="Return separate answers per selected document and a synthesised summary.",
    )

class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=2000)
    session_id: str = Field(..., min_length=1)
    filters: Optional[Dict[str, Any]] = None

class SQLRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=2000)

class SessionCreateRequest(BaseModel):
    session_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


# ─── Response Models ──────────────────────────────────────────────────────────

class PerDocResult(BaseModel):
    """Answer scoped to a single document — one entry in multi-doc mode."""
    source_name: str
    answer: str
    confidence: float
    chunks_used: int
    has_answer: bool  # False if the doc had no relevant content for this question


class AskResponse(BaseModel):
    answer: str                          # synthesised / main answer
    query_type: str
    confidence: float
    sources: List[str]
    sql: Optional[str] = None
    sql_result: Optional[Dict[str, Any]] = None
    session_id: Optional[str] = None
    low_confidence_warning: bool = False
    # Multi-document fields (populated only when per_document_answers=True)
    per_doc_results: Optional[List[PerDocResult]] = None
    docs_searched: Optional[List[str]] = None  # filenames that were in scope

class IngestResponse(BaseModel):
    success: bool
    files_total: int
    chunks_embedded: int
    tabular_tables: int
    tabular_rows: int
    details: Optional[Dict[str, Any]] = None

class TableInfo(BaseModel):
    table_name: str
    source_file: str
    sheet_name: Optional[str] = None
    row_count: int
    col_count: int
    columns: List[str]

class KBDocument(BaseModel):
    """One document card in the Knowledge Base panel."""
    name: str                          # filename, e.g. "Shraddha.pdf"
    doc_type: str                      # "semantic" | "tabular" | "both"
    chunk_count: int = 0               # ChromaDB chunks (0 for tabular-only)
    tables: List[TableInfo] = []       # DuckDB tables (empty for semantic-only)

class KBStats(BaseModel):
    documents: List[KBDocument]
    total_files: int
    total_chunks: int
    total_tables: int

class DeleteDocResponse(BaseModel):
    success: bool
    document: str
    deleted_chunks: int
    deleted_tables: List[str]
    message: str

class StatsResponse(BaseModel):
    vector_store: Dict[str, Any]
    tabular_tables: List[str]
    has_semantic: bool
    has_tabular: bool

class SessionResponse(BaseModel):
    session_id: str
    message_count: Optional[int] = None

class HealthResponse(BaseModel):
    status: str
    ollama: bool
    vector_store_docs: int
    tabular_tables: int
    version: str

# ─── Model Management ─────────────────────────────────────────────────────────

class OllamaModel(BaseModel):
    name: str                                  # e.g. "llama3.2:latest"
    display_name: str                          # e.g. "llama3.2"
    family: Optional[str] = None              # e.g. "llama"
    parameter_size: Optional[str] = None      # e.g. "3.2B"
    quantization: Optional[str] = None        # e.g. "Q4_K_M"
    size_gb: Optional[float] = None           # download size in GB
    is_current: bool = False                  # True if this is the active LLM
    is_embed: bool = False                    # True if this is the active embed model

class ModelListResponse(BaseModel):
    models: List[OllamaModel]
    current_llm: str
    current_embed: str
    ollama_available: bool
    error: Optional[str] = None

class ModelSwitchRequest(BaseModel):
    model_name: str = Field(..., min_length=1, max_length=200)

class ModelSwitchResponse(BaseModel):
    success: bool
    model_name: str
    previous_model: str
    message: str
    warning: Optional[str] = None
