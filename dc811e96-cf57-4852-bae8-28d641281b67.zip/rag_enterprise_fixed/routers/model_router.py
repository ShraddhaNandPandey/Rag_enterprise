"""
routers/model_router.py — Model management endpoints

GET  /models          — list all locally installed Ollama models
GET  /models/current  — current active model names
POST /models/switch   — hot-swap LLM model at runtime (no restart)
"""

from fastapi import APIRouter, HTTPException
from models.schemas import (
    ModelListResponse, ModelSwitchRequest, ModelSwitchResponse,
)
from utils.logger import get_logger

logger = get_logger("api")
router = APIRouter(prefix="/models", tags=["Models"])


@router.get("/", response_model=ModelListResponse)
async def list_models():
    """List all Ollama models installed locally, with current model flagged."""
    from api.dependencies import get_model_service
    return get_model_service().list_models()


@router.get("/current")
async def get_current_model():
    """Return the currently active LLM and embedding model names."""
    from api.dependencies import get_model_service
    return get_model_service().get_current()


@router.post("/switch", response_model=ModelSwitchResponse)
async def switch_model(request: ModelSwitchRequest):
    """
    Hot-swap the active LLM model at runtime without restarting the server.

    Raises:
      503 — Ollama is not running
      404 — model not installed locally (with install hint)
      422 — model installed but failed smoke-test
      500 — unexpected error
    """
    from api.dependencies import get_model_service, get_query_service
    from services.model_service import (
        OllamaUnavailableError, ModelNotFoundError, ModelSwitchError,
    )

    model_svc = get_model_service()
    query_svc = get_query_service()

    try:
        result = model_svc.switch_model(request.model_name, query_svc)
        return result
    except OllamaUnavailableError as e:
        raise HTTPException(
            status_code=503,
            detail=f"Ollama is not running. Start it with: ollama serve\n{e}",
        )
    except ModelNotFoundError as e:
        raise HTTPException(
            status_code=404,
            detail=str(e),
        )
    except ModelSwitchError as e:
        raise HTTPException(
            status_code=422,
            detail=str(e),
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"switch_model unexpected: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")
