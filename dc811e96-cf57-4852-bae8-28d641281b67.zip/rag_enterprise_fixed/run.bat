@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ============================================================
echo   Enterprise RAG Agent - Backend Server
echo ============================================================
echo.

if not exist venv\Scripts\activate.bat (
    echo [ERROR] venv not found. Run install.bat first!
    pause & exit /b 1
)

call venv\Scripts\activate.bat
echo [OK] venv activated

:: Verify critical packages with correct versions
python -c "import chromadb; assert chromadb.__version__=='1.5.9', f'Need chromadb==1.5.9 got {chromadb.__version__}'" >nul 2>&1
if errorlevel 1 (
    echo [FIX] Installing correct chromadb version...
    pip install "chromadb==1.5.9" --quiet
)

python -c "import duckdb; assert duckdb.__version__=='1.5.4', f'Need duckdb==1.5.4 got {duckdb.__version__}'" >nul 2>&1
if errorlevel 1 (
    echo [FIX] Installing correct duckdb version...
    pip install "duckdb==1.5.4" --quiet
)

python -c "import gradio; assert gradio.__version__=='5.38.0', f'Need gradio==5.38.0 got {gradio.__version__}'" >nul 2>&1
if errorlevel 1 (
    echo [FIX] Installing correct gradio version...
    pip install "gradio==5.38.0" --quiet
)

python -c "import fastapi" >nul 2>&1
if errorlevel 1 (
    echo [FIX] Installing missing packages...
    pip install -r requirements.txt --quiet
)

:: Check Ollama
echo [INFO] Checking Ollama...
curl -s --max-time 3 http://localhost:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo [INFO] Starting Ollama in background...
    start "" /b ollama serve
    echo [INFO] Waiting for Ollama...
    timeout /t 8 /nobreak >nul
    curl -s --max-time 3 http://localhost:11434/api/tags >nul 2>&1
    if errorlevel 1 (
        echo [WARN] Ollama not responding.
        echo        Open NEW terminal: ollama serve
        echo        Then re-run this file.
        pause & exit /b 1
    )
)
echo [OK] Ollama running

:: Directories
if not exist logs mkdir logs
if not exist data mkdir data
if not exist chroma_db mkdir chroma_db

:: Offline flags
set TRANSFORMERS_OFFLINE=1
set HF_HUB_OFFLINE=1
set ANONYMIZED_TELEMETRY=False
set CHROMA_TELEMETRY=False

echo.
echo ============================================================
echo   Server:   http://localhost:8000
echo   API Docs: http://localhost:8000/docs
echo   Health:   http://localhost:8000/health
echo ============================================================
echo   Press Ctrl+C to stop
echo.

python main.py
pause
