@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ============================================================
echo   Enterprise RAG Agent - Web UI
echo ============================================================
echo   Make sure run.bat is running in another terminal first!
echo ============================================================
echo.

if not exist venv\Scripts\activate.bat (
    echo [ERROR] venv not found. Run install.bat first!
    pause & exit /b 1
)

call venv\Scripts\activate.bat
echo [OK] venv activated

:: Verify gradio version
python -c "import gradio; assert gradio.__version__=='5.38.0', 'wrong version'" >nul 2>&1
if errorlevel 1 (
    echo [FIX] Installing correct gradio version...
    pip install "gradio==5.38.0" --quiet
)

:: Offline flags
set TRANSFORMERS_OFFLINE=1
set HF_HUB_OFFLINE=1
set ANONYMIZED_TELEMETRY=False

echo [INFO] Opening at http://localhost:7860
echo.

python ui.py
pause
