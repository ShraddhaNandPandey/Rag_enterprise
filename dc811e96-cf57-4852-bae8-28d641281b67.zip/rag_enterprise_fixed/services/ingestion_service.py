"""
services/ingestion_service.py — Enterprise Ingestion Pipeline

Text files  → OCR if needed → Chunking → Embeddings → ChromaDB
CSV/Excel   → DuckDB (direct, no embedding)
"""

from pathlib import Path
from typing import List, Dict, Any

from loaders.file_loader import load_files, TABULAR_MARKER
from core.chunker import chunk_documents, chunk_stats
from vectorstore.chroma_store import VectorStore
from database.duckdb_manager import DuckDBManager
from config.settings import CHUNK_SIZE, CHUNK_OVERLAP, MIN_CHUNK_SIZE, MAX_CHUNK_SIZE
from utils.logger import get_logger

logger = get_logger("ingestion")


class IngestionService:
    """Routes text docs → ChromaDB and tabular files → DuckDB."""

    def __init__(self, vector_store: VectorStore, duckdb_manager: DuckDBManager):
        self.vector_store   = vector_store
        self.duckdb_manager = duckdb_manager

    def ingest(self, file_paths: List[str], chunk_size: int = CHUNK_SIZE, chunk_overlap: int = CHUNK_OVERLAP) -> Dict[str, Any]:
        logger.info(f"Starting ingestion of {len(file_paths)} file(s)")

        try:
            all_docs = load_files(file_paths)
        except Exception as e:
            logger.error(f"load_files failed: {e}", exc_info=True)
            raise RuntimeError(f"Could not read uploaded files: {e}") from e

        tabular_docs = [d for d in all_docs if d.get("text") == TABULAR_MARKER]
        text_docs    = [d for d in all_docs if d.get("text") != TABULAR_MARKER]

        # Run tabular and semantic ingestion independently so a failure in one
        # doesn't discard results already committed by the other.
        try:
            tabular_stats = self._ingest_tabular(tabular_docs)
        except Exception as e:
            logger.error(f"Tabular ingestion stage failed: {e}", exc_info=True)
            tabular_stats = {"tables": 0, "rows": 0, "details": [], "error": str(e)}

        try:
            semantic_stats = self._ingest_semantic(text_docs, chunk_size, chunk_overlap)
        except Exception as e:
            logger.error(f"Semantic ingestion stage failed: {e}", exc_info=True)
            semantic_stats = {"docs": 0, "chunks": 0, "embedded": 0, "chunk_stats": {}, "error": str(e)}

        result = {
            "files_total": len(file_paths),
            "text_sections": semantic_stats["docs"],
            "chunks_created": semantic_stats["chunks"],
            "chunks_embedded": semantic_stats["embedded"],
            "tabular_tables": tabular_stats["tables"],
            "tabular_rows": tabular_stats["rows"],
            "chunk_stats": semantic_stats.get("chunk_stats", {}),
            "tabular_details": tabular_stats["details"],
        }

        errors = []
        if "error" in tabular_stats:
            errors.append(f"tabular: {tabular_stats['error']}")
        if "error" in semantic_stats:
            errors.append(f"semantic: {semantic_stats['error']}")
        if errors:
            result["partial_errors"] = errors

        logger.info(f"Ingestion complete: {result['chunks_embedded']} chunks, {result['tabular_tables']} tables")
        return result

    def _ingest_tabular(self, tabular_docs: List[Dict]) -> Dict[str, Any]:
        tables, rows, details = 0, 0, []
        for doc in tabular_docs:
            path  = doc["metadata"]["source"]
            ftype = doc["metadata"]["type"]
            try:
                if ftype in ("csv", "tsv"):
                    info = self.duckdb_manager.load_csv(path)
                    tables += 1; rows += info["row_count"]; details.append(info)
                elif ftype in ("xlsx", "xlsm", "xls"):
                    infos = self.duckdb_manager.load_excel(path)
                    tables += len(infos)
                    for info in infos:
                        rows += info["row_count"]; details.append(info)
            except Exception as e:
                logger.error(f"Tabular ingestion failed '{path}': {e}")
        return {"tables": tables, "rows": rows, "details": details}

    def _ingest_semantic(self, text_docs: List[Dict], chunk_size: int, chunk_overlap: int) -> Dict[str, Any]:
        if not text_docs:
            return {"docs": 0, "chunks": 0, "embedded": 0}
        chunks = chunk_documents(text_docs, chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                  min_chunk_size=MIN_CHUNK_SIZE, max_chunk_size=MAX_CHUNK_SIZE)
        stats    = chunk_stats(chunks)
        embedded = self.vector_store.add_chunks(chunks)
        return {"docs": len(text_docs), "chunks": stats.get("total_chunks", 0), "embedded": embedded, "chunk_stats": stats}

    def get_ingestion_summary(self) -> Dict[str, Any]:
        try:
            vs = self.vector_store.get_stats()
        except Exception as e:
            logger.error(f"get_ingestion_summary: vector_store.get_stats() failed: {e}", exc_info=True)
            vs = {"total_chunks": 0, "unique_sources": 0, "sources": []}

        try:
            tables = self.duckdb_manager.list_tables()
        except Exception as e:
            logger.error(f"get_ingestion_summary: duckdb_manager.list_tables() failed: {e}", exc_info=True)
            tables = []

        return {"vector_store": vs, "tabular_tables": tables,
                "has_semantic": vs.get("total_chunks", 0) > 0, "has_tabular": len(tables) > 0}

    def get_knowledge_base(self) -> Dict[str, Any]:
        """
        Build a unified per-document view merging ChromaDB and DuckDB.
        Returns one KBDocument per unique filename across both stores.
        If one backend fails, still returns data from the other rather than
        failing the whole view.
        """
        from collections import defaultdict

        docs: Dict[str, Dict] = defaultdict(lambda: {
            "name": "", "doc_type": "semantic",
            "chunk_count": 0, "tables": []
        })

        # Semantic docs from ChromaDB
        try:
            semantic_entries = self.vector_store.get_knowledge_base()
        except Exception as e:
            logger.error(f"get_knowledge_base: vector_store.get_knowledge_base() failed: {e}", exc_info=True)
            semantic_entries = []

        for entry in semantic_entries:
            name = entry["source_name"]
            docs[name]["name"]        = name
            docs[name]["chunk_count"] = entry["chunk_count"]
            docs[name]["doc_type"]    = "semantic"

        # Tabular docs from DuckDB
        try:
            table_names = self.duckdb_manager.list_tables()
        except Exception as e:
            logger.error(f"get_knowledge_base: duckdb_manager.list_tables() failed: {e}", exc_info=True)
            table_names = []

        for tname in table_names:
            try:
                info = self.duckdb_manager.get_table_info(tname)
            except Exception as e:
                logger.warning(f"get_table_info failed for '{tname}': {e}")
                continue
            if not info:
                continue
            name = Path(info["source_file"]).name
            if name in docs:
                docs[name]["doc_type"] = "both"
            else:
                docs[name]["name"]     = name
                docs[name]["doc_type"] = "tabular"
            docs[name]["tables"].append(info)

        doc_list = sorted(docs.values(), key=lambda d: d["name"])
        total_chunks = sum(d["chunk_count"] for d in doc_list)
        total_tables = sum(len(d["tables"]) for d in doc_list)

        return {
            "documents":    doc_list,
            "total_files":  len(doc_list),
            "total_chunks": total_chunks,
            "total_tables": total_tables,
        }

    def delete_document(self, doc_name: str) -> Dict[str, Any]:
        """
        Fully remove a document from every store:
          - ChromaDB embeddings + BM25 index
          - All DuckDB tables whose source file matches doc_name
          - Registry metadata entries

        Each store is attempted independently — a failure in one does not
        prevent deletion from the other, and is reported in 'errors'.
        """
        errors = []

        # 1. Remove from ChromaDB + BM25
        try:
            deleted_chunks = self.vector_store.delete_source(doc_name)
        except Exception as e:
            logger.error(f"delete_document: vector_store.delete_source failed for '{doc_name}': {e}", exc_info=True)
            deleted_chunks = 0
            errors.append(f"ChromaDB deletion failed: {e}")

        # 2. Find and drop all DuckDB tables for this file
        deleted_tables: List[str] = []
        try:
            tables_info = self.duckdb_manager.get_tables_by_source(doc_name)
        except Exception as e:
            logger.error(f"delete_document: get_tables_by_source failed for '{doc_name}': {e}", exc_info=True)
            tables_info = []
            errors.append(f"DuckDB lookup failed: {e}")

        for info in tables_info:
            try:
                if self.duckdb_manager.drop_table(info["table_name"]):
                    deleted_tables.append(info["table_name"])
            except Exception as e:
                logger.error(f"delete_document: drop_table failed for '{info['table_name']}': {e}", exc_info=True)
                errors.append(f"Could not drop table '{info['table_name']}': {e}")

        total = deleted_chunks + len(deleted_tables)
        logger.info(
            f"Deleted '{doc_name}': {deleted_chunks} chunks, "
            f"{len(deleted_tables)} tables {deleted_tables}"
        )

        result = {
            "success":        total > 0,
            "document":       doc_name,
            "deleted_chunks": deleted_chunks,
            "deleted_tables": deleted_tables,
            "message": (
                f"Removed {deleted_chunks} chunk(s) from ChromaDB and "
                f"{len(deleted_tables)} table(s) from DuckDB."
                if total > 0 else
                (f"Could not verify or delete '{doc_name}' due to backend errors."
                 if errors else
                 f"'{doc_name}' not found in any store.")
            ),
        }
        if errors:
            result["errors"] = errors
        return result
