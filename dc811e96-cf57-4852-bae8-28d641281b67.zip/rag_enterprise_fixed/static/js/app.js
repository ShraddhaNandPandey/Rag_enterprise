/* ============================================================
   Enterprise RAG Platform — frontend application logic
   Vanilla JS, no build step, no external dependencies (intranet-safe)
   Talks to the existing FastAPI backend (same origin).
   ============================================================ */

(() => {
  "use strict";

  const API = ""; // same-origin; backend mounted at the same FastAPI app

  const SESSION_ID = "ui-" + Math.random().toString(16).slice(2, 10);

  const state = {
    view: "chat",
    route: "auto",
    sessionId: SESSION_ID,
    messages: [],     // {role, content, meta}
    pendingFiles: [],
    sessions: { activeId: null },
  };

  // ───────────────────────── helpers ─────────────────────────

  function $(sel, root = document) { return root.querySelector(sel); }
  function $all(sel, root = document) { return [...root.querySelectorAll(sel)]; }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // Minimal, safe markdown-lite renderer: code fences, inline code, bold, line breaks.
  function renderRichText(text) {
    let out = escapeHtml(text);
    out = out.replace(/```([\s\S]*?)```/g, (_, code) => `<pre>${code.trim()}</pre>`);
    out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
    out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    out = out.replace(/\n/g, "<br>");
    return out;
  }

  async function apiGet(path, timeoutMs = 15000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(API + path, { signal: ctrl.signal });
      const body = await safeJson(res);
      if (!res.ok) throw new Error(body?.detail || `HTTP ${res.status}`);
      return body;
    } finally { clearTimeout(t); }
  }

  async function apiPost(path, payload, timeoutMs = 360000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(API + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload || {}),
        signal: ctrl.signal,
      });
      const body = await safeJson(res);
      if (!res.ok) throw new Error(body?.detail || `HTTP ${res.status}`);
      return body;
    } finally { clearTimeout(t); }
  }

  async function apiDelete(path) {
    const res = await fetch(API + path, { method: "DELETE" });
    const body = await safeJson(res);
    if (!res.ok) throw new Error(body?.detail || `HTTP ${res.status}`);
    return body;
  }

  async function safeJson(res) {
    try { return await res.json(); } catch { return null; }
  }

  function toast(message, type = "info", ms = 4500) {
    const stack = $("#toast-stack");
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.textContent = message;
    stack.appendChild(el);
    setTimeout(() => el.remove(), ms);
  }

  function confirmModal(title, body) {
    return new Promise((resolve) => {
      const overlay = $("#modal-overlay");
      $("#modal-title").textContent = title;
      $("#modal-body").textContent = body;
      overlay.hidden = false;
      const cleanup = (result) => {
        overlay.hidden = true;
        confirmBtn.removeEventListener("click", onConfirm);
        cancelBtn.removeEventListener("click", onCancel);
        resolve(result);
      };
      const confirmBtn = $("#modal-confirm");
      const cancelBtn = $("#modal-cancel");
      const onConfirm = () => cleanup(true);
      const onCancel = () => cleanup(false);
      confirmBtn.addEventListener("click", onConfirm);
      cancelBtn.addEventListener("click", onCancel);
    });
  }

  // ───────────────────────── navigation ─────────────────────────

  const VIEW_META = {
    chat:     { title: "Chat",              sub: "Ask questions across your ingested documents and spreadsheets." },
    kb:       { title: "Knowledge Base",    sub: "Upload, inspect, and manage ingested documents." },
    data:     { title: "Data Sources",      sub: "Tabular tables available for SQL-backed questions." },
    models:   { title: "Model Management",  sub: "View and hot-swap the active language model." },
    sessions: { title: "Sessions",          sub: "Browse conversation memory across chat sessions." },
    system:   { title: "System Health",     sub: "Backend status, version, and OCR engine diagnostics." },
  };

  function setView(view) {
    state.view = view;
    $all(".nav-item").forEach(btn => btn.classList.toggle("is-active", btn.dataset.view === view));
    $all(".view").forEach(sec => { sec.hidden = sec.dataset.view !== view; });
    $("#view-title").textContent = VIEW_META[view].title;
    $("#view-subtitle").textContent = VIEW_META[view].sub;

    if (view === "kb") refreshKb();
    if (view === "data") refreshTables();
    if (view === "models") refreshModels();
    if (view === "sessions") refreshSessions();
    if (view === "system") refreshSystem();
  }

  $("#nav").addEventListener("click", (e) => {
    const btn = e.target.closest(".nav-item");
    if (btn) setView(btn.dataset.view);
  });

  // ───────────────────────── header / health polling ─────────────────────────

  async function refreshHeader() {
    try {
      const h = await apiGet("/health");
      const ok = !!h.ollama;
      $("#hc-dot").className = "dot " + (ok ? "ok" : "bad");
      $("#hc-text").textContent = ok ? "Online" : "Ollama down";
      $("#sb-dot").className = "dot " + (ok ? "ok" : "bad");
      $("#sb-status-text").textContent = ok ? "Connected" : "Degraded";
      $("#sb-version").textContent = "v" + (h.version || "—");
      $("#docs-chip-text").textContent = `${h.vector_store_docs ?? 0} chunks · ${h.tabular_tables ?? 0} tables`;

      try {
        const m = await apiGet("/models/current");
        $("#model-chip-text").textContent = "model: " + (m.current_llm || "—");
      } catch { /* non-fatal */ }
    } catch (e) {
      $("#hc-dot").className = "dot bad";
      $("#hc-text").textContent = "Unreachable";
      $("#sb-dot").className = "dot bad";
      $("#sb-status-text").textContent = "Unreachable";
    }
  }

  // ───────────────────────── CHAT ─────────────────────────

  $("#session-id-display").textContent = state.sessionId;

  $("#route-toggle").addEventListener("click", (e) => {
    const btn = e.target.closest(".route-opt");
    if (!btn) return;
    state.route = btn.dataset.route;
    $all(".route-opt").forEach(b => b.classList.toggle("is-active", b === btn));
  });

  $("#new-session-btn").addEventListener("click", () => {
    state.sessionId = "ui-" + Math.random().toString(16).slice(2, 10);
    state.messages = [];
    $("#session-id-display").textContent = state.sessionId;
    renderChat();
    toast("Started a new session", "success");
  });

  $("#example-chips").addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    $("#chat-input").value = chip.dataset.q;
    submitChat();
  });

  const chatInput = $("#chat-input");
  chatInput.addEventListener("input", () => {
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 160) + "px";
  });
  chatInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submitChat();
    }
  });
  $("#chat-form").addEventListener("submit", (e) => {
    e.preventDefault();
    submitChat();
  });

  function renderChat() {
    const log = $("#chat-log");
    if (state.messages.length === 0) {
      log.innerHTML = "";
      log.appendChild($("#chat-empty") || buildEmptyState());
      $("#chat-empty").hidden = false;
      return;
    }
    log.innerHTML = "";
    for (const m of state.messages) log.appendChild(renderMessage(m));
    log.scrollTop = log.scrollHeight;
  }

  function buildEmptyState() {
    // fallback if original empty node was removed from DOM; shouldn't normally trigger
    const div = document.createElement("div");
    div.id = "chat-empty";
    div.className = "chat-empty";
    div.textContent = "Start a conversation.";
    return div;
  }

  const QTYPE_LABEL = {
    tabular: { text: "TABULAR · SQL", cls: "tag-tabular" },
    semantic: { text: "SEMANTIC · RAG", cls: "tag-semantic" },
    tabular_fallback_semantic: { text: "TABULAR → SEMANTIC", cls: "tag-tabular" },
    multi_document: { text: "MULTI-DOCUMENT", cls: "tag-semantic" },
  };

  function renderMessage(m) {
    const wrap = document.createElement("div");
    wrap.className = "msg " + m.role;

    const avatar = document.createElement("div");
    avatar.className = "msg-avatar";
    avatar.textContent = m.role === "user" ? "You" : "AI";
    wrap.appendChild(avatar);

    const col = document.createElement("div");
    col.style.minWidth = "0";

    const bubble = document.createElement("div");
    bubble.className = "msg-bubble";
    if (m.pending) {
      bubble.innerHTML = `<div class="msg-typing"><span></span><span></span><span></span></div>`;
    } else {
      bubble.innerHTML = renderRichText(m.content);
    }
    col.appendChild(bubble);

    if (m.meta && !m.pending) {
      const meta = document.createElement("div");
      meta.className = "msg-meta";
      const qt = QTYPE_LABEL[m.meta.query_type] || { text: (m.meta.query_type || "").toUpperCase(), cls: "tag-source" };
      if (m.meta.query_type) {
        const t = document.createElement("span");
        t.className = "tag " + qt.cls;
        t.textContent = qt.text;
        meta.appendChild(t);
      }
      if (typeof m.meta.confidence === "number") {
        const c = document.createElement("span");
        c.className = "tag tag-conf";
        c.textContent = "confidence " + Math.round(m.meta.confidence * 100) + "%";
        meta.appendChild(c);
      }
      if (m.meta.low_confidence_warning) {
        const w = document.createElement("span");
        w.className = "tag tag-warn";
        w.textContent = "low confidence";
        meta.appendChild(w);
      }
      (m.meta.sources || []).forEach(s => {
        const sChip = document.createElement("span");
        sChip.className = "tag tag-source";
        sChip.textContent = "📎 " + s;
        meta.appendChild(sChip);
      });
      col.appendChild(meta);

      if (m.meta.sql) {
        const pre = document.createElement("pre");
        pre.className = "code-block";
        pre.style.marginTop = "8px";
        pre.textContent = m.meta.sql;
        col.appendChild(pre);
      }
    }

    wrap.appendChild(col);
    return wrap;
  }

  async function submitChat() {
    const text = chatInput.value.trim();
    if (!text) return;
    chatInput.value = "";
    chatInput.style.height = "auto";

    state.messages.push({ role: "user", content: text });
    const pendingMsg = { role: "assistant", content: "", pending: true };
    state.messages.push(pendingMsg);
    renderChat();

    $("#send-btn").disabled = true;

    let question = text;
    if (state.route === "tabular") question = `[TABULAR] ${text}`;
    if (state.route === "semantic") question = `[SEMANTIC] ${text}`;

    try {
      const result = await apiPost("/query/chat", {
        question,
        session_id: state.sessionId,
      });
      pendingMsg.pending = false;
      pendingMsg.content = result.answer || "No answer.";
      pendingMsg.meta = {
        query_type: result.query_type,
        confidence: result.confidence,
        sources: result.sources,
        sql: result.sql,
        low_confidence_warning: result.low_confidence_warning,
      };
    } catch (e) {
      pendingMsg.pending = false;
      pendingMsg.content = "Could not reach the server. " + (e.message || "");
      pendingMsg.meta = null;
      toast("Chat request failed: " + (e.message || "unknown error"), "error");
    }
    renderChat();
    $("#send-btn").disabled = false;
    refreshHeader();
  }

  // ───────────────────────── KNOWLEDGE BASE ─────────────────────────

  const dropzone = $("#dropzone");
  const fileInput = $("#file-input");

  $("#browse-btn").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", () => addFiles([...fileInput.files]));

  ["dragenter", "dragover"].forEach(evt =>
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.add("is-dragover"); })
  );
  ["dragleave", "drop"].forEach(evt =>
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.remove("is-dragover"); })
  );
  dropzone.addEventListener("drop", (e) => {
    const files = [...(e.dataTransfer?.files || [])];
    addFiles(files);
  });

  function addFiles(files) {
    state.pendingFiles.push(...files);
    renderFilePills();
  }

  function renderFilePills() {
    const row = $("#upload-file-list");
    row.innerHTML = "";
    state.pendingFiles.forEach((f, idx) => {
      const pill = document.createElement("div");
      pill.className = "file-pill";
      pill.innerHTML = `<span>${escapeHtml(f.name)}</span>`;
      const rm = document.createElement("button");
      rm.textContent = "×";
      rm.addEventListener("click", () => {
        state.pendingFiles.splice(idx, 1);
        renderFilePills();
      });
      pill.appendChild(rm);
      row.appendChild(pill);
    });
    $("#ingest-btn").disabled = state.pendingFiles.length === 0;
  }

  $("#ingest-btn").addEventListener("click", async () => {
    if (state.pendingFiles.length === 0) return;
    const btn = $("#ingest-btn");
    btn.disabled = true;
    $("#upload-status").textContent = "Uploading and ingesting…";
    try {
      const form = new FormData();
      state.pendingFiles.forEach(f => form.append("files", f));
      const res = await fetch(API + "/ingest/upload", { method: "POST", body: form });
      const body = await safeJson(res);
      if (!res.ok) throw new Error(body?.detail || `HTTP ${res.status}`);
      const lines = [`${body.files_total} file(s) ingested`];
      if (body.chunks_embedded) lines.push(`${body.chunks_embedded} chunks → vector store`);
      if (body.tabular_tables) lines.push(`${body.tabular_tables} table(s), ${body.tabular_rows} rows → SQL store`);
      $("#upload-status").textContent = lines.join(" · ");
      toast("Ingestion complete", "success");
      state.pendingFiles = [];
      renderFilePills();
      refreshKb();
      refreshHeader();
    } catch (e) {
      $("#upload-status").textContent = "Upload failed: " + e.message;
      toast("Upload failed: " + e.message, "error");
    } finally {
      btn.disabled = state.pendingFiles.length === 0;
    }
  });

  $("#kb-refresh-btn").addEventListener("click", refreshKb);

  async function refreshKb() {
    try {
      const kb = await apiGet("/ingest/kb");
      $("#kb-stat-files").textContent = kb.total_files ?? 0;
      $("#kb-stat-chunks").textContent = kb.total_chunks ?? 0;
      $("#kb-stat-tables").textContent = kb.total_tables ?? 0;

      const list = $("#kb-list");
      const docs = kb.documents || [];
      if (docs.length === 0) {
        list.innerHTML = `<div class="empty-state">No documents yet — upload files above.</div>`;
        return;
      }
      list.innerHTML = "";
      docs.forEach(doc => list.appendChild(renderDocRow(doc)));
    } catch (e) {
      toast("Could not load knowledge base: " + e.message, "error");
    }
  }

  function renderDocRow(doc) {
    const row = document.createElement("div");
    row.className = "doc-row";
    const icon = doc.doc_type === "semantic" ? "📄" : (doc.doc_type === "tabular" ? "📊" : "📄📊");

    const subParts = [];
    if (doc.chunk_count) subParts.push(`<code>${doc.chunk_count} chunk${doc.chunk_count !== 1 ? "s" : ""}</code>`);
    (doc.tables || []).forEach(t => {
      const sheet = t.sheet_name ? ` · ${escapeHtml(t.sheet_name)}` : "";
      subParts.push(`<code>${escapeHtml(t.table_name)}${sheet} · ${t.row_count} rows</code>`);
    });

    row.innerHTML = `
      <div class="doc-icon">${icon}</div>
      <div class="doc-main">
        <div class="doc-name">${escapeHtml(doc.name)}</div>
        <div class="doc-sub">${subParts.join(" &nbsp; ") || "No content extracted"}</div>
      </div>
    `;
    const delBtn = document.createElement("button");
    delBtn.className = "btn-ghost btn-xs";
    delBtn.textContent = "Delete";
    delBtn.addEventListener("click", async () => {
      const ok = await confirmModal("Delete document", `Permanently remove "${doc.name}" from all stores (embeddings, SQL tables, registry)?`);
      if (!ok) return;
      try {
        const result = await apiDelete(`/ingest/kb/${encodeURIComponent(doc.name)}`);
        toast(`Deleted ${doc.name} (${result.deleted_chunks || 0} chunks)`, "success");
        refreshKb();
        refreshHeader();
      } catch (e) {
        toast("Delete failed: " + e.message, "error");
      }
    });
    row.appendChild(delBtn);
    return row;
  }

  // ───────────────────────── DATA SOURCES ─────────────────────────

  $("#data-refresh-btn").addEventListener("click", refreshTables);

  async function refreshTables() {
    try {
      const data = await apiGet("/data/tables");
      const list = $("#table-list");
      const tables = data.tables || [];
      if (tables.length === 0) {
        list.innerHTML = `<div class="empty-state">No tables yet — upload a CSV or Excel file in Knowledge Base.</div>`;
        return;
      }
      list.innerHTML = "";
      tables.forEach(name => {
        const card = document.createElement("div");
        card.className = "table-card";
        card.innerHTML = `<div class="table-card-name">${escapeHtml(name)}</div><div class="table-card-meta">Click to preview rows</div>`;
        card.addEventListener("click", () => previewTable(name));
        list.appendChild(card);
      });
    } catch (e) {
      toast("Could not load tables: " + e.message, "error");
    }
  }

  async function previewTable(name) {
    try {
      const result = await apiGet(`/data/tables/${encodeURIComponent(name)}/preview?limit=10`);
      const rows = result.rows || result.data || [];
      const cols = result.columns || (rows[0] ? Object.keys(rows[0]) : []);
      let html = `<strong>${escapeHtml(name)}</strong> — preview (first ${rows.length} rows)`;
      if (cols.length) {
        html += `<table class="preview-table"><thead><tr>${cols.map(c => `<th>${escapeHtml(c)}</th>`).join("")}</tr></thead><tbody>`;
        rows.forEach(r => {
          const cells = Array.isArray(r) ? r : cols.map(c => r[c]);
          html += `<tr>${cells.map(c => `<td>${escapeHtml(c)}</td>`).join("")}</tr>`;
        });
        html += `</tbody></table>`;
      }
      $("#sql-output").innerHTML = html;
    } catch (e) {
      toast("Preview failed: " + e.message, "error");
    }
  }

  $("#sql-preview-btn").addEventListener("click", async () => {
    const q = $("#sql-question").value.trim();
    if (!q) { toast("Enter a question first", "info"); return; }
    $("#sql-output").textContent = "Generating…";
    try {
      const result = await apiPost("/query/sql/preview", { question: q });
      $("#sql-output").textContent =
        `SQL:\n${result.sql || "(none generated)"}\n\nValid: ${result.is_valid}\n${result.message || ""}`;
    } catch (e) {
      $("#sql-output").textContent = "Error: " + e.message;
    }
  });

  $("#sql-exec-btn").addEventListener("click", async () => {
    const q = $("#sql-question").value.trim();
    if (!q) { toast("Enter raw SQL in the box first", "info"); return; }
    $("#sql-output").textContent = "Running…";
    try {
      const result = await apiPost("/query/sql/execute", { question: q });
      $("#sql-output").textContent = JSON.stringify(result, null, 2);
    } catch (e) {
      $("#sql-output").textContent = "Error: " + e.message;
    }
  });

  // ───────────────────────── MODELS ─────────────────────────

  $("#models-refresh-btn").addEventListener("click", refreshModels);

  async function refreshModels() {
    const list = $("#model-list");
    list.innerHTML = `<div class="empty-state">Loading models…</div>`;
    try {
      const data = await apiGet("/models/");
      if (!data.ollama_available) {
        list.innerHTML = `<div class="empty-state">${escapeHtml(data.error || "Ollama not available")}</div>`;
        return;
      }
      const models = (data.models || []).filter(m => !m.is_embed);
      if (models.length === 0) {
        list.innerHTML = `<div class="empty-state">No models installed. Run: <code>ollama pull llama3.2</code></div>`;
        return;
      }
      list.innerHTML = "";
      models.forEach(m => list.appendChild(renderModelCard(m)));
    } catch (e) {
      list.innerHTML = `<div class="empty-state">Could not load models: ${escapeHtml(e.message)}</div>`;
    }
  }

  function renderModelCard(m) {
    const card = document.createElement("div");
    card.className = "model-card" + (m.is_current ? " is-active" : "");
    const meta = [];
    if (m.parameter_size) meta.push(m.parameter_size);
    if (m.size_gb) meta.push(m.size_gb + " GB");
    if (m.quantization) meta.push(m.quantization);
    card.innerHTML = `
      <div class="model-card-name">${escapeHtml(m.display_name)}</div>
      <div class="model-card-meta">${meta.map(x => `<span>${escapeHtml(x)}</span>`).join(" · ")}</div>
      <div class="model-card-foot">
        ${m.is_current ? `<span class="tag tag-semantic">Active</span>` : `<span></span>`}
      </div>
    `;
    if (!m.is_current) {
      const btn = document.createElement("button");
      btn.className = "btn-secondary btn-sm";
      btn.textContent = "Switch to this model";
      btn.addEventListener("click", () => switchModel(m.name, btn));
      card.querySelector(".model-card-foot").appendChild(btn);
    }
    return card;
  }

  async function switchModel(name, btn) {
    btn.disabled = true;
    btn.textContent = "Switching…";
    $("#model-status").textContent = `Switching to ${name}…`;
    try {
      const result = await apiPost("/models/switch", { model_name: name }, 90000);
      $("#model-status").textContent = `Switched to ${result.model_name}.`;
      toast(`Active model is now ${result.model_name}`, "success");
      refreshModels();
      refreshHeader();
    } catch (e) {
      $("#model-status").textContent = "Switch failed: " + e.message;
      toast("Model switch failed: " + e.message, "error");
      btn.disabled = false;
      btn.textContent = "Switch to this model";
    }
  }

  // ───────────────────────── SESSIONS ─────────────────────────

  $("#sessions-refresh-btn").addEventListener("click", refreshSessions);

  async function refreshSessions() {
    const list = $("#sessions-list");
    try {
      const data = await apiGet("/memory/sessions");
      const sessions = data.sessions || [];
      if (sessions.length === 0) {
        list.innerHTML = `<div class="empty-state">No sessions yet.</div>`;
        return;
      }
      list.innerHTML = "";
      sessions.forEach(s => {
        const id = typeof s === "string" ? s : (s.session_id || s.id || JSON.stringify(s));
        const row = document.createElement("div");
        row.className = "session-row" + (id === state.sessions.activeId ? " is-active" : "");
        row.innerHTML = `<span class="session-row-name">${escapeHtml(id)}</span>`;
        const actions = document.createElement("div");
        actions.style.display = "flex";
        actions.style.gap = "6px";

        const viewBtn = document.createElement("button");
        viewBtn.className = "btn-ghost btn-xs";
        viewBtn.textContent = "View";
        viewBtn.addEventListener("click", () => loadSessionHistory(id));

        const delBtn = document.createElement("button");
        delBtn.className = "btn-ghost btn-xs";
        delBtn.textContent = "Delete";
        delBtn.addEventListener("click", async () => {
          const ok = await confirmModal("Delete session", `Delete session "${id}" and all its messages?`);
          if (!ok) return;
          try {
            await apiDelete(`/memory/sessions/${encodeURIComponent(id)}`);
            toast("Session deleted", "success");
            refreshSessions();
          } catch (e) { toast("Delete failed: " + e.message, "error"); }
        });

        actions.append(viewBtn, delBtn);
        row.appendChild(actions);
        list.appendChild(row);
      });
    } catch (e) {
      list.innerHTML = `<div class="empty-state">Could not load sessions: ${escapeHtml(e.message)}</div>`;
    }
  }

  async function loadSessionHistory(id) {
    state.sessions.activeId = id;
    refreshSessions();
    $("#session-detail-title").textContent = id;
    const body = $("#session-detail-body");
    body.innerHTML = `<div class="empty-state">Loading…</div>`;
    try {
      const data = await apiGet(`/memory/sessions/${encodeURIComponent(id)}/history?limit=50`);
      const messages = data.messages || [];
      if (messages.length === 0) {
        body.innerHTML = `<div class="empty-state">No messages in this session.</div>`;
        return;
      }
      body.innerHTML = "";
      messages.forEach(m => {
        const row = document.createElement("div");
        row.className = "transcript-row";
        row.innerHTML = `<div class="transcript-role">${escapeHtml(m.role || "")}</div><div>${renderRichText(m.content || "")}</div>`;
        body.appendChild(row);
      });
    } catch (e) {
      body.innerHTML = `<div class="empty-state">Could not load history: ${escapeHtml(e.message)}</div>`;
    }
  }

  // ───────────────────────── SYSTEM HEALTH ─────────────────────────

  $("#ocr-refresh-btn").addEventListener("click", refreshOcr);

  async function refreshSystem() {
    try {
      const h = await apiGet("/health");
      $("#sys-stat-status").textContent = h.status || "—";
      $("#sys-stat-ollama").textContent = h.ollama ? "Online" : "Offline";
      $("#sys-stat-version").textContent = h.version || "—";
      $("#health-raw").textContent = JSON.stringify(h, null, 2);
    } catch (e) {
      $("#health-raw").textContent = "Error: " + e.message;
    }
    refreshOcr();
  }

  async function refreshOcr() {
    const grid = $("#ocr-status");
    try {
      const data = await apiGet("/data/ocr/status");
      const status = data.engine_status || {};
      const entries = Object.entries(status);
      if (entries.length === 0) {
        grid.innerHTML = `<div class="empty-state">No OCR engine info available.</div>`;
        return;
      }
      grid.innerHTML = "";
      entries.forEach(([engine, value]) => {
        const card = document.createElement("div");
        card.className = "ocr-card";
        card.innerHTML = `<div class="ocr-card-title">${escapeHtml(engine)}</div><div>${escapeHtml(value)}</div>`;
        grid.appendChild(card);
      });
      if (data.recommendation) {
        const rec = document.createElement("div");
        rec.className = "ocr-card";
        rec.innerHTML = `<div class="ocr-card-title">Recommendation</div><div>${escapeHtml(data.recommendation)}</div>`;
        grid.appendChild(rec);
      }
    } catch (e) {
      grid.innerHTML = `<div class="empty-state">Could not load OCR status: ${escapeHtml(e.message)}</div>`;
    }
  }

  // ───────────────────────── init ─────────────────────────

  setView("chat");
  refreshHeader();
  setInterval(refreshHeader, 15000);
})();
