"""utils/logger.py — Centralized logging setup for Enterprise RAG Agent."""

import logging
import logging.handlers
import os
import sys
from pathlib import Path

_logging_configured = False


def setup_logging() -> None:
    """Configure root logging once. Safe to call multiple times."""
    global _logging_configured
    if _logging_configured:
        return

    try:
        from config.settings import LOG_LEVEL, LOGS_DIR, LOG_MAX_BYTES, LOG_BACKUP_COUNT
        level = getattr(logging, LOG_LEVEL.upper(), logging.INFO)
        log_dir = Path(LOGS_DIR)
    except Exception:
        level = logging.INFO
        log_dir = Path(__file__).resolve().parent.parent / "logs"

    log_dir.mkdir(parents=True, exist_ok=True)

    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(level)

    # Avoid adding duplicate handlers
    if not root.handlers:
        # Console handler
        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(fmt)
        ch.setLevel(level)
        root.addHandler(ch)

        # Rotating file handler
        try:
            log_max_bytes = 10 * 1024 * 1024  # 10 MB default
            log_backup_count = 5
            try:
                from config.settings import LOG_MAX_BYTES, LOG_BACKUP_COUNT
                log_max_bytes = LOG_MAX_BYTES
                log_backup_count = LOG_BACKUP_COUNT
            except Exception:
                pass

            fh = logging.handlers.RotatingFileHandler(
                log_dir / "app.log",
                maxBytes=log_max_bytes,
                backupCount=log_backup_count,
                encoding="utf-8",
            )
            fh.setFormatter(fmt)
            fh.setLevel(level)
            root.addHandler(fh)
        except Exception:
            pass

    # Quieten noisy third-party loggers
    for noisy in ("httpx", "httpcore", "urllib3", "chromadb", "sentence_transformers"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    _logging_configured = True


def get_logger(name: str) -> logging.Logger:
    """Return a named logger. Ensures logging is configured."""
    setup_logging()
    return logging.getLogger(name)
