"""
loaders/file_loader.py — Multi-format document loader.

Routes files by extension:
  - PDF, DOCX, PPTX, TXT, MD  → extracted as text docs (for ChromaDB)
  - CSV, XLSX, XLS, TSV       → marked TABULAR_MARKER (handled by DuckDB)
  - Images (jpg/png/etc.)     → OCR'd into text docs

Returns a flat list of dicts: {"text": str, "metadata": dict}
Tabular files return {"text": TABULAR_MARKER, "metadata": {"source": path, "type": ext}}
"""

from pathlib import Path
from typing import Any, Dict, List

from config.settings import TABULAR_EXTENSIONS, IMAGE_EXTENSIONS, PDF_TEXT_MIN_LEN
from utils.logger import get_logger

logger = get_logger("loaders")

TABULAR_MARKER = "__TABULAR__"


def load_files(file_paths: List[str]) -> List[Dict[str, Any]]:
    """Load a list of files, routing each to the appropriate loader."""
    all_docs: List[Dict[str, Any]] = []
    for path in file_paths:
        try:
            docs = load_single_file(path)
            all_docs.extend(docs)
        except Exception as e:
            logger.error(f"Failed to load '{path}': {e}", exc_info=True)
    return all_docs


def load_single_file(path: str) -> List[Dict[str, Any]]:
    """Load one file and return a list of doc dicts (usually one per page/slide/sheet)."""
    p = Path(path)
    ext = p.suffix.lower()
    name = p.name

    if ext in TABULAR_EXTENSIONS:
        ftype = ext.lstrip(".")
        return [{
            "text": TABULAR_MARKER,
            "metadata": {"source": str(p), "source_name": name, "type": ftype},
        }]

    if ext in IMAGE_EXTENSIONS:
        return _load_image(p)

    if ext == ".pdf":
        return _load_pdf(p)

    if ext in (".docx", ".doc"):
        return _load_docx(p)

    if ext == ".pptx":
        return _load_pptx(p)

    if ext in (".txt", ".md"):
        return _load_text(p)

    logger.warning(f"Unsupported extension '{ext}' for file '{name}', skipping.")
    return []


# ─── PDF ──────────────────────────────────────────────────────────────────────

def _load_pdf(p: Path) -> List[Dict[str, Any]]:
    """Extract text per-page from a PDF. Falls back to OCR for pages with little/no text."""
    docs: List[Dict[str, Any]] = []
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(p))
        for i, page in enumerate(reader.pages, 1):
            try:
                text = page.extract_text() or ""
            except Exception as e:
                logger.warning(f"PDF page {i} extraction failed for '{p.name}': {e}")
                text = ""

            text = text.strip()

            if len(text) < PDF_TEXT_MIN_LEN:
                # Likely a scanned page — try OCR fallback
                ocr_text = _ocr_pdf_page(p, i)
                if ocr_text and len(ocr_text.strip()) > len(text):
                    text = ocr_text.strip()

            if text:
                docs.append({
                    "text": text,
                    "metadata": {
                        "source": str(p),
                        "source_name": p.name,
                        "type": "pdf",
                        "page": i,
                    },
                })
    except Exception as e:
        logger.error(f"Failed to read PDF '{p.name}': {e}", exc_info=True)

    return docs


def _ocr_pdf_page(p: Path, page_num: int) -> str:
    """OCR a single PDF page by rasterizing it to an image first."""
    try:
        from pdf2image import convert_from_path
        from config.settings import OCR_DPI

        images = convert_from_path(
            str(p), dpi=OCR_DPI, first_page=page_num, last_page=page_num
        )
        if not images:
            return ""

        from ocr.ocr_engine import OCREngine
        from config.settings import OCR_ENGINE, LLAVA_MODEL, TROCR_MODEL

        engine = OCREngine(engine=OCR_ENGINE, llava_model=LLAVA_MODEL, trocr_model=TROCR_MODEL)
        return engine.extract_text(images[0])
    except Exception as e:
        logger.warning(f"OCR fallback failed for '{p.name}' page {page_num}: {e}")
        return ""


# ─── DOCX ─────────────────────────────────────────────────────────────────────

def _load_docx(p: Path) -> List[Dict[str, Any]]:
    """Extract all paragraph and table text from a Word document as a single doc."""
    try:
        import docx
        document = docx.Document(str(p))

        parts = []
        for para in document.paragraphs:
            if para.text.strip():
                parts.append(para.text.strip())

        for table in document.tables:
            for row in table.rows:
                row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                if row_text:
                    parts.append(row_text)

        full_text = "\n".join(parts)
        if not full_text.strip():
            return []

        return [{
            "text": full_text,
            "metadata": {"source": str(p), "source_name": p.name, "type": "docx"},
        }]
    except Exception as e:
        logger.error(f"Failed to read DOCX '{p.name}': {e}", exc_info=True)
        return []


# ─── PPTX ─────────────────────────────────────────────────────────────────────

def _load_pptx(p: Path) -> List[Dict[str, Any]]:
    """Extract text per-slide from a PowerPoint file."""
    docs: List[Dict[str, Any]] = []
    try:
        from pptx import Presentation
        prs = Presentation(str(p))

        for i, slide in enumerate(prs.slides, 1):
            parts = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        text = "".join(run.text for run in para.runs).strip()
                        if text:
                            parts.append(text)
                if shape.has_table:
                    for row in shape.table.rows:
                        row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                        if row_text:
                            parts.append(row_text)

            # Speaker notes
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                notes = slide.notes_slide.notes_text_frame.text.strip()
                if notes:
                    parts.append(f"[Notes: {notes}]")

            slide_text = "\n".join(parts).strip()
            if slide_text:
                docs.append({
                    "text": slide_text,
                    "metadata": {
                        "source": str(p),
                        "source_name": p.name,
                        "type": "pptx",
                        "slide": i,
                    },
                })
    except Exception as e:
        logger.error(f"Failed to read PPTX '{p.name}': {e}", exc_info=True)

    return docs


# ─── Plain text / Markdown ────────────────────────────────────────────────────

def _load_text(p: Path) -> List[Dict[str, Any]]:
    """Load a plain text or markdown file."""
    try:
        text = p.read_text(encoding="utf-8", errors="ignore").strip()
        if not text:
            return []
        ftype = "markdown" if p.suffix.lower() == ".md" else "text"
        return [{
            "text": text,
            "metadata": {"source": str(p), "source_name": p.name, "type": ftype},
        }]
    except Exception as e:
        logger.error(f"Failed to read text file '{p.name}': {e}", exc_info=True)
        return []


# ─── Images ───────────────────────────────────────────────────────────────────

def _load_image(p: Path) -> List[Dict[str, Any]]:
    """Run OCR on an image file and return extracted text as a doc."""
    try:
        from PIL import Image
        from ocr.ocr_engine import OCREngine
        from config.settings import OCR_ENGINE, LLAVA_MODEL, TROCR_MODEL

        image = Image.open(str(p))
        engine = OCREngine(engine=OCR_ENGINE, llava_model=LLAVA_MODEL, trocr_model=TROCR_MODEL)
        text = engine.extract_text(image)

        if not text or not text.strip():
            logger.warning(f"No text extracted from image '{p.name}'")
            return []

        return [{
            "text": text.strip(),
            "metadata": {"source": str(p), "source_name": p.name, "type": "image"},
        }]
    except Exception as e:
        logger.error(f"Failed to OCR image '{p.name}': {e}", exc_info=True)
        return []
