"""
memory/conversation_memory.py — SQLite-backed conversation memory.

Stores chat sessions and messages so multi-turn conversations can reference
prior context, and the UI can display chat history per session.

Every public method wraps its SQLite calls in proper exception handling:
sqlite3 errors (locked DB, disk I/O, corruption) are caught, logged, and
re-raised as a clear RuntimeError instead of leaking a raw sqlite3.Error
up through the router layer.
"""

import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from config.settings import SQLITE_PATH
from utils.logger import get_logger

logger = get_logger("memory")


class ConversationMemory:
    """Manages chat sessions and message history using SQLite."""

    def __init__(self, db_path: str = SQLITE_PATH):
        self.db_path = db_path
        try:
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(
                f"Cannot create directory for SQLite memory store '{db_path}': {e}. "
                f"Check filesystem permissions and available disk space."
            ) from e

        try:
            self._init_db()
        except sqlite3.Error as e:
            raise RuntimeError(
                f"Failed to initialize SQLite memory store at '{db_path}': {e}. "
                f"The database file may be corrupted or locked by another process."
            ) from e

        logger.info(f"ConversationMemory initialized at: {db_path}")

    def _connect(self) -> sqlite3.Connection:
        try:
            conn = sqlite3.connect(self.db_path, timeout=10)
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.Error as e:
            raise RuntimeError(f"Could not connect to SQLite memory store: {e}") from e

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    metadata   TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id  TEXT NOT NULL,
                    role        TEXT NOT NULL,
                    content     TEXT NOT NULL,
                    query_type  TEXT,
                    confidence  REAL,
                    sources     TEXT,
                    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_messages_session
                ON messages(session_id, id)
            """)
            conn.commit()
        finally:
            conn.close()

    # ── Session management ───────────────────────────────────────────────────

    def create_session(self, session_id: Optional[str] = None, metadata: Optional[Dict] = None) -> str:
        """Create a new session, returning its id. If session_id exists, returns it unchanged."""
        sid = session_id or str(uuid.uuid4())
        conn = self._connect()
        try:
            try:
                existing = conn.execute(
                    "SELECT session_id FROM sessions WHERE session_id = ?", (sid,)
                ).fetchone()
                if not existing:
                    conn.execute(
                        "INSERT INTO sessions (session_id, metadata) VALUES (?, ?)",
                        (sid, json.dumps(metadata or {})),
                    )
                    conn.commit()
                    logger.info(f"Created session: {sid}")
            except sqlite3.Error as e:
                logger.error(f"create_session failed for '{sid}': {e}", exc_info=True)
                raise RuntimeError(f"Could not create session '{sid}': {e}") from e
        finally:
            conn.close()
        return sid

    def get_or_create_session(self, session_id: str) -> str:
        """Ensure a session exists; create if missing."""
        return self.create_session(session_id)

    def list_sessions(self) -> List[Dict[str, Any]]:
        """List all sessions with basic stats."""
        conn = self._connect()
        try:
            try:
                rows = conn.execute("""
                    SELECT s.session_id, s.metadata, s.created_at,
                           COUNT(m.id) as message_count,
                           MAX(m.created_at) as last_activity
                    FROM sessions s
                    LEFT JOIN messages m ON s.session_id = m.session_id
                    GROUP BY s.session_id
                    ORDER BY last_activity DESC NULLS LAST, s.created_at DESC
                """).fetchall()
            except sqlite3.Error as e:
                logger.error(f"list_sessions failed: {e}", exc_info=True)
                raise RuntimeError(f"Could not list sessions: {e}") from e

            results = []
            for r in rows:
                try:
                    metadata = json.loads(r["metadata"] or "{}")
                except (json.JSONDecodeError, TypeError) as e:
                    logger.warning(f"Corrupt metadata JSON for session '{r['session_id']}': {e}")
                    metadata = {}
                results.append({
                    "session_id": r["session_id"],
                    "metadata": metadata,
                    "created_at": r["created_at"],
                    "message_count": r["message_count"],
                    "last_activity": r["last_activity"],
                })
            return results
        finally:
            conn.close()

    def delete_session(self, session_id: str) -> bool:
        """Delete a session and all its messages. Returns True if session existed."""
        conn = self._connect()
        try:
            try:
                existing = conn.execute(
                    "SELECT session_id FROM sessions WHERE session_id = ?", (session_id,)
                ).fetchone()
                if not existing:
                    return False
                conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
                conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
                conn.commit()
                logger.info(f"Deleted session: {session_id}")
                return True
            except sqlite3.Error as e:
                logger.error(f"delete_session failed for '{session_id}': {e}", exc_info=True)
                raise RuntimeError(f"Could not delete session '{session_id}': {e}") from e
        finally:
            conn.close()

    def clear_session(self, session_id: str) -> int:
        """Delete all messages in a session but keep the session record. Returns count deleted."""
        conn = self._connect()
        try:
            try:
                cur = conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
                conn.commit()
                return cur.rowcount
            except sqlite3.Error as e:
                logger.error(f"clear_session failed for '{session_id}': {e}", exc_info=True)
                raise RuntimeError(f"Could not clear session '{session_id}': {e}") from e
        finally:
            conn.close()

    def get_session_stats(self, session_id: str) -> Dict[str, Any]:
        """Return statistics for a session."""
        conn = self._connect()
        try:
            try:
                session = conn.execute(
                    "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
                ).fetchone()
                if not session:
                    return {"session_id": session_id, "exists": False}

                rows = conn.execute(
                    """SELECT role, query_type, confidence FROM messages
                       WHERE session_id = ?""",
                    (session_id,),
                ).fetchall()
            except sqlite3.Error as e:
                logger.error(f"get_session_stats failed for '{session_id}': {e}", exc_info=True)
                raise RuntimeError(f"Could not load session stats for '{session_id}': {e}") from e

            user_msgs = sum(1 for r in rows if r["role"] == "user")
            assistant_msgs = sum(1 for r in rows if r["role"] == "assistant")
            confidences = [r["confidence"] for r in rows if r["confidence"] is not None]
            avg_confidence = round(sum(confidences) / len(confidences), 4) if confidences else None

            return {
                "session_id": session_id,
                "exists": True,
                "total_messages": len(rows),
                "user_messages": user_msgs,
                "assistant_messages": assistant_msgs,
                "avg_confidence": avg_confidence,
                "created_at": session["created_at"],
            }
        finally:
            conn.close()

    # ── Message management ───────────────────────────────────────────────────

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        query_type: Optional[str] = None,
        confidence: Optional[float] = None,
        sources: Optional[List[str]] = None,
    ) -> None:
        """Append a message to a session's history. Auto-creates session if missing."""
        self.get_or_create_session(session_id)
        conn = self._connect()
        try:
            try:
                conn.execute(
                    """INSERT INTO messages (session_id, role, content, query_type, confidence, sources)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (session_id, role, content, query_type, confidence,
                     json.dumps(sources) if sources is not None else None),
                )
                conn.commit()
            except sqlite3.Error as e:
                logger.error(f"add_message failed for session '{session_id}': {e}", exc_info=True)
                raise RuntimeError(f"Could not save message to session '{session_id}': {e}") from e
        finally:
            conn.close()

    def get_history(self, session_id: str, limit: int = 10) -> List[Dict[str, str]]:
        """
        Return recent messages formatted for LLM chat context:
        [{"role": "user"|"assistant", "content": str}, ...]
        Ordered oldest → newest, limited to the most recent `limit` messages.
        """
        conn = self._connect()
        try:
            try:
                rows = conn.execute(
                    """SELECT role, content FROM messages
                       WHERE session_id = ?
                       ORDER BY id DESC LIMIT ?""",
                    (session_id, limit),
                ).fetchall()
            except sqlite3.Error as e:
                logger.error(f"get_history failed for session '{session_id}': {e}", exc_info=True)
                raise RuntimeError(f"Could not load history for session '{session_id}': {e}") from e

            history = [{"role": r["role"], "content": r["content"]} for r in rows]
            history.reverse()
            return history
        finally:
            conn.close()

    def get_full_history(self, session_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Return full message records (with metadata) for the UI history view."""
        conn = self._connect()
        try:
            try:
                rows = conn.execute(
                    """SELECT role, content, query_type, confidence, sources, created_at
                       FROM messages WHERE session_id = ?
                       ORDER BY id ASC LIMIT ?""",
                    (session_id, limit),
                ).fetchall()
            except sqlite3.Error as e:
                logger.error(f"get_full_history failed for session '{session_id}': {e}", exc_info=True)
                raise RuntimeError(f"Could not load full history for session '{session_id}': {e}") from e

            results = []
            for r in rows:
                try:
                    sources = json.loads(r["sources"]) if r["sources"] else None
                except (json.JSONDecodeError, TypeError) as e:
                    logger.warning(f"Corrupt sources JSON in message history for session '{session_id}': {e}")
                    sources = None
                results.append({
                    "role": r["role"],
                    "content": r["content"],
                    "query_type": r["query_type"],
                    "confidence": r["confidence"],
                    "sources": sources,
                    "created_at": r["created_at"],
                })
            return results
        finally:
            conn.close()
