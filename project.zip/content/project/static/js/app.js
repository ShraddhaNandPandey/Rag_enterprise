/* ============================================================
   Enterprise RAG Platform — frontend application logic
   Vanilla JS, no build step, no external dependencies (intranet-safe)
   Talks to the existing FastAPI backend (same origin).
   ============================================================ */

(() => {
  "use strict";

  const API = ""; // same-origin; backend mounted at the same FastAPI app

  const SESSION_ID = "ui-" + Math.random().toString(16).slice(2, 10);

  const state = {
    view: "dashboard",
    route: "auto",
    sessionId: SESSION_ID,
    messages: [],     // {role, content, meta}
    pendingFiles: [],
    sessions: { activeId: null },
    isSending: false,
    sendGeneration: 0,  // bumped whenever an in-flight chat request should be treated as stale
    editingIndex: null, // index of the user message currently being edited, or null
    kbDocs: [],          // cached /ingest/kb documents, filtered/sorted client-side
    kbSearch: "",
    kbFilter: "all",
    kbSort: { field: "name", dir: "asc" },
    chatPendingFiles: [],   // files attached in Chat, waiting to be sent/ingested
  };

  // ───────────────────────── helpers ─────────────────────────

  function $(sel, root = document) { return root.querySelector(sel); }
  function $all(sel, root = document) { return [...root.querySelectorAll(sel)]; }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // Minimal, safe markdown-lite renderer.
  // Turns fenced/inline code, bold, GFM-style pipe tables, and bullet/numbered
  // lists into real structured HTML (<table>, <ul>, <ol>) instead of dumping
  // everything as one text blob with <br> line breaks. Model answers that
  // naturally have tabular or list-shaped data (e.g. "list all departments",
  // "compare X vs Y") render as an actual table/list this way.
  function renderRichText(text) {
    if (!text) return "";

    // Pull fenced code blocks out first so table/list parsing never looks
    // inside them; put them back verbatim at the end.
    const codeBlocks = [];
    const withPlaceholders = String(text).replace(/```([\s\S]*?)```/g, (_, code) => {
      codeBlocks.push(code.trim());
      return `\u0000CODEBLOCK${codeBlocks.length - 1}\u0000`;
    });

    const lines = escapeHtml(withPlaceholders).split("\n");
    const isTableRow = (l) => l.includes("|") && l.trim() !== "";
    const isTableSep = (l) => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(l);
    const isBullet = (l) => /^\s*[-*]\s+/.test(l);
    const isOrdered = (l) => /^\s*\d+[.)]\s+/.test(l);
    const inline = (s) => s
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    const splitRow = (l) => {
      let s = l.trim();
      if (s.startsWith("|")) s = s.slice(1);
      if (s.endsWith("|")) s = s.slice(0, -1);
      return s.split("|").map((c) => c.trim());
    };

    const parts = [];
    let i = 0;
    while (i < lines.length) {
      const line = lines[i];

      if (line.trim() === "") { i++; continue; }

      // GFM pipe table: header row + separator row + 0 or more data rows
      if (isTableRow(line) && i + 1 < lines.length && isTableSep(lines[i + 1])) {
        const header = splitRow(line);
        let j = i + 2;
        const rows = [];
        while (j < lines.length && isTableRow(lines[j]) && !isTableSep(lines[j])) {
          rows.push(splitRow(lines[j]));
          j++;
        }
        const thead = `<thead><tr>${header.map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead>`;
        const tbody = `<tbody>${rows.map((r) =>
          `<tr>${header.map((_, ci) => `<td>${inline(r[ci] ?? "")}</td>`).join("")}</tr>`
        ).join("")}</tbody>`;
        parts.push(`<table class="msg-table">${thead}${tbody}</table>`);
        i = j;
        continue;
      }

      // Bullet list
      if (isBullet(line)) {
        const items = [];
        while (i < lines.length && isBullet(lines[i])) {
          items.push(lines[i].replace(/^\s*[-*]\s+/, ""));
          i++;
        }
        parts.push(`<ul>${items.map((it) => `<li>${inline(it)}</li>`).join("")}</ul>`);
        continue;
      }

      // Numbered list
      if (isOrdered(line)) {
        const items = [];
        while (i < lines.length && isOrdered(lines[i])) {
          items.push(lines[i].replace(/^\s*\d+[.)]\s+/, ""));
          i++;
        }
        parts.push(`<ol>${items.map((it) => `<li>${inline(it)}</li>`).join("")}</ol>`);
        continue;
      }

      // Plain paragraph: consume consecutive lines until a blank line or the
      // start of a table/list block.
      const paraLines = [];
      while (
        i < lines.length && lines[i].trim() !== "" &&
        !isBullet(lines[i]) && !isOrdered(lines[i]) &&
        !(isTableRow(lines[i]) && i + 1 < lines.length && isTableSep(lines[i + 1]))
      ) {
        paraLines.push(lines[i]);
        i++;
      }
      if (paraLines.length) parts.push(`<p>${paraLines.map(inline).join("<br>")}</p>`);
    }

    return parts.join("")
      .replace(/\u0000CODEBLOCK(\d+)\u0000/g, (_, idx) => `<pre>${escapeHtml(codeBlocks[Number(idx)])}</pre>`);
  }

  async function apiGet(path, timeoutMs = 15000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(API + path, { signal: ctrl.signal });
      const body = await safeJson(res);
      if (!res.ok) {
        const err = new Error(body?.detail || `HTTP ${res.status}`);
        err.status = res.status;
        throw err;
      }
      return body;
    } finally { clearTimeout(t); }
  }

  async function apiPost(path, payload, timeoutMs = 360000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(API + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload || {}),
        signal: ctrl.signal,
      });
      const body = await safeJson(res);
      if (!res.ok) {
        const err = new Error(body?.detail || `HTTP ${res.status}`);
        err.status = res.status;
        throw err;
      }
      return body;
    } finally { clearTimeout(t); }
  }

  async function apiDelete(path) {
    const res = await fetch(API + path, { method: "DELETE" });
    const body = await safeJson(res);
    if (!res.ok) throw new Error(body?.detail || `HTTP ${res.status}`);
    return body;
  }

  async function safeJson(res) {
    try { return await res.json(); } catch { return null; }
  }

  // Small inline icon set for the per-message action row (time/copy/edit/reload).
  const ICONS = {
    reload: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>`,
    edit:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg>`,
    copy:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`,
    check:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
    download: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`,
    attach: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>`,
    file:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>`,
    close:  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`,
  };

  function formatTime(ts) {
    try { return new Date(ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }); }
    catch { return ""; }
  }

  async function exportMessageAsPDF(m, btn) {
    const originalTitle = btn.title;
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.title = "Generating PDF…";
    try {
      const meta = m.meta || {};
      const payload = {
        question: m.forQuestion || "",
        answer: m.content || "",
        meta: {
          query_type: meta.query_type,
          confidence: meta.confidence,
          low_confidence_warning: meta.low_confidence_warning,
          response_time_ms: meta.responseTimeMs,
          sql: meta.sql,
          sources: meta.sources,
        },
      };

      const res = await fetch(API + "/export/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const body = await safeJson(res);
        throw new Error(body?.detail || `HTTP ${res.status}`);
      }

      const blob = await res.blob();

      // Prefer the server-suggested filename (Content-Disposition) so it
      // matches the report's own "Generated On" timestamp; fall back to a
      // client-side name if the header is ever stripped by a proxy.
      let filename = `EnterpriseRAG_${new Date().toISOString().replace(/[:.]/g, "-")}.pdf`;
      const disposition = res.headers.get("Content-Disposition") || "";
      const starMatch = disposition.match(/filename\*=UTF-8''([^;]+)/i);
      const plainMatch = disposition.match(/filename="([^"]+)"/i);
      if (starMatch) filename = decodeURIComponent(starMatch[1]);
      else if (plainMatch) filename = plainMatch[1];

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast("PDF report exported", "success");
    } catch (e) {
      toast("PDF export failed: " + e.message, "error");
    } finally {
      btn.disabled = false;
      btn.title = originalTitle;
      btn.innerHTML = originalHTML;
    }
  }

  async function copyMessageText(text, btn) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        // Fallback for non-secure contexts (e.g. plain-http intranet hosts).
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      }
      const original = btn.innerHTML;
      btn.innerHTML = ICONS.check;
      btn.classList.add("is-done");
      setTimeout(() => { btn.innerHTML = original; btn.classList.remove("is-done"); }, 1200);
    } catch (e) {
      toast("Could not copy to clipboard", "error");
    }
  }

  function toast(message, type = "info", ms = 4500) {
    const stack = $("#toast-stack");
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.textContent = message;
    stack.appendChild(el);
    setTimeout(() => el.remove(), ms);
  }

  function confirmModal(title, body) {
    return new Promise((resolve) => {
      const overlay = $("#modal-overlay");
      $("#modal-title").textContent = title;
      $("#modal-body").textContent = body;
      overlay.hidden = false;
      const cleanup = (result) => {
        overlay.hidden = true;
        confirmBtn.removeEventListener("click", onConfirm);
        cancelBtn.removeEventListener("click", onCancel);
        resolve(result);
      };
      const confirmBtn = $("#modal-confirm");
      const cancelBtn = $("#modal-cancel");
      const onConfirm = () => cleanup(true);
      const onCancel = () => cleanup(false);
      confirmBtn.addEventListener("click", onConfirm);
      cancelBtn.addEventListener("click", onCancel);
    });
  }

  // ───────────────────────── navigation ─────────────────────────

  const VIEW_META = {
    dashboard:{ title: "Dashboard",         sub: "Overview of the knowledge base, models, and system status." },
    chat:     { title: "Chat",              sub: "Ask questions across your ingested documents and spreadsheets." },
    kb:       { title: "Knowledge Base",    sub: "Upload, inspect, and manage ingested documents." },
    data:     { title: "Data Sources",      sub: "Tabular tables available for SQL-backed questions." },
    models:   { title: "Model Management",  sub: "View and hot-swap the active language model." },
    sessions: { title: "Sessions",          sub: "Browse conversation memory across chat sessions." },
    system:   { title: "System Health",     sub: "Backend status, version, and OCR engine diagnostics." },
  };

  function setView(view) {
    state.view = view;
    $all(".nav-item").forEach(btn => {
      const active = btn.dataset.view === view;
      btn.classList.toggle("is-active", active);
      if (active) btn.setAttribute("aria-current", "page");
      else btn.removeAttribute("aria-current");
    });
    $all(".view").forEach(sec => { sec.hidden = sec.dataset.view !== view; });
    $("#view-title").textContent = VIEW_META[view].title;
    $("#view-subtitle").textContent = VIEW_META[view].sub;

    if (view === "dashboard") refreshDashboard();
    if (view === "kb") refreshKb();
    if (view === "chat") refreshExampleChips();
    if (view === "data") refreshTables();
    if (view === "models") refreshModels();
    if (view === "sessions") refreshSessions();
    if (view === "system") refreshSystem();
  }

  $("#nav").addEventListener("click", (e) => {
    const btn = e.target.closest(".nav-item");
    if (btn) setView(btn.dataset.view);
  });

  // ───────────────────────── header / status polling ─────────────────────────
  // Centralized polling manager for /health and /models/current.
  //   - /health   is fetched at most once every HEALTH_TTL_MS (30s)
  //   - /models/current is cached for MODEL_TTL_MS (60s) and only re-fetched
  //     when stale or explicitly invalidated (e.g. after a model switch)
  //   - both are fetched in parallel with Promise.all() when both are due
  //   - a single setInterval drives polling; duplicate timers are prevented
  //   - polling pauses while the tab is hidden and resumes when it's visible

  const HEALTH_TTL_MS = 30000; // /health poll interval
  const MODEL_TTL_MS  = 60000; // /models/current cache lifetime

  const statusCache = {
    health: null, healthAt: 0,
    model:  null, modelAt: 0,
  };

  function invalidateModelCache() {
    statusCache.modelAt = 0;
  }

  async function fetchHealth() {
    const h = await apiGet("/health");
    statusCache.health = h;
    statusCache.healthAt = Date.now();
    return h;
  }

  async function fetchModelCurrent() {
    const m = await apiGet("/models/current");
    statusCache.model = m;
    statusCache.modelAt = Date.now();
    return m;
  }

  // Refreshes /health (always) and /models/current (only if stale/forced),
  // running both in parallel via Promise.all() whenever both are actually needed.
  async function refreshStatus({ forceModel = false } = {}) {
    const modelStale = forceModel || !statusCache.model || (Date.now() - statusCache.modelAt >= MODEL_TTL_MS);
    if (modelStale) {
      const [health, model] = await Promise.all([
        fetchHealth(),
        fetchModelCurrent().catch(() => statusCache.model), // model fetch failure is non-fatal
      ]);
      return { health, model };
    }
    const health = await fetchHealth();
    return { health, model: statusCache.model };
  }

  function applyHeaderStatus(h, m) {
    const ok = !!h.ollama;
    $("#hc-dot").className = "dot " + (ok ? "ok" : "bad");
    $("#hc-text").textContent = ok ? "Online" : "Ollama down";
    $("#sb-dot").className = "dot " + (ok ? "ok" : "bad");
    $("#sb-status-text").textContent = ok ? "Connected" : "Degraded";
    $("#sb-version").textContent = "v" + (h.version || "—");
    $("#docs-chip-text").textContent = `${h.vector_store_docs ?? 0} chunks · ${h.tabular_tables ?? 0} tables`;
    if (m) {
      $("#model-chip-text").textContent = "model: " + (m.current_llm || "—");
    }
  }

  async function refreshHeader({ forceModel = false } = {}) {
    try {
      const { health, model } = await refreshStatus({ forceModel });
      applyHeaderStatus(health, model);
    } catch (e) {
      $("#hc-dot").className = "dot bad";
      $("#hc-text").textContent = "Unreachable";
      $("#sb-dot").className = "dot bad";
      $("#sb-status-text").textContent = "Unreachable";
    }
  }

  // ── single polling timer, guarded against duplicates, visibility-aware ──
  let pollTimer = null;

  function startPolling() {
    if (pollTimer) return;                   // a timer is already running
    if (window.__ragPollerStarted) return;    // guard in case app.js is ever initialized twice
    window.__ragPollerStarted = true;
    pollTimer = setInterval(() => refreshHeader(), HEALTH_TTL_MS);
  }

  function stopPolling() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      stopPolling();
    } else {
      refreshHeader();   // catch up immediately on return
      startPolling();
    }
  });

  // Prevent leaked timers across navigation/unload of this page.
  window.addEventListener("beforeunload", stopPolling);
  window.addEventListener("pagehide", stopPolling);

  // ───────────────────────── CHAT ─────────────────────────

  $("#session-id-display").textContent = state.sessionId;

  // The empty-state block (icon + example chips) lives inside #chat-log in the
  // original HTML. renderChat() does log.innerHTML = "" once messages exist,
  // which would otherwise destroy it permanently. Clone it once up front so
  // it can always be restored in full (not a bare-text fallback).
  const emptyStateTemplate = $("#chat-empty").cloneNode(true);
  emptyStateTemplate.hidden = false;

  // The starter chips shown before any message is sent used to be hardcoded
  // demo questions ("leave policy", "average revenue by department", ...)
  // from a sample HR/finance dataset — completely unrelated to whatever the
  // user has actually ingested. This builds them from the real Knowledge
  // Base instead, so the suggestions are always relevant to what's actually
  // there (and prompts an upload when there's nothing yet).
  function shortenName(name, max = 26) {
    if (!name) return "";
    return name.length > max ? name.slice(0, max - 1) + "…" : name;
  }

  async function refreshExampleChips() {
    const row = emptyStateTemplate.querySelector("#example-chips");
    if (!row) return;

    let sources;
    try {
      sources = await apiGet("/ingest/sources");
    } catch (e) {
      return; // non-fatal — leave whatever chips are already showing
    }

    const semantic = sources.semantic || [];
    const tabular = sources.tabular || [];
    const chips = [];

    if (semantic.length === 0 && tabular.length === 0) {
      row.innerHTML = "";
      const hint = document.createElement("div");
      hint.className = "chip-row-empty";
      hint.textContent = "No documents yet —";
      const btn = document.createElement("button");
      btn.className = "chip";
      btn.dataset.nav = "kb";
      btn.textContent = "Upload documents to get started";
      row.appendChild(hint);
      row.appendChild(btn);
      if (state.messages.length === 0) renderChat();
      return;
    }

    if (semantic.length) {
      const first = semantic[0];
      chips.push({ q: `Summarize ${first}`, label: `Summarize ${shortenName(first)}` });
      if (semantic.length > 1) {
        chips.push({ q: `Compare ${semantic[0]} and ${semantic[1]}.`, label: `Compare ${shortenName(semantic[0])} & ${shortenName(semantic[1])}` });
      } else {
        chips.push({ q: `What are the key points in ${first}?`, label: `Key points in ${shortenName(first)}` });
      }
    }
    if (tabular.length) {
      const t = tabular[0];
      chips.push({ q: `How many rows are in ${t}?`, label: `Rows in ${shortenName(t)}` });
      chips.push({ q: `Give me a summary of the data in ${t}.`, label: `Summarize ${shortenName(t)} data` });
    }
    if (semantic.length && tabular.length === 0) {
      chips.push({ q: "Summarize everything in my knowledge base.", label: "Summarize everything" });
    }

    row.innerHTML = "";
    chips.slice(0, 5).forEach(c => {
      const btn = document.createElement("button");
      btn.className = "chip";
      btn.dataset.q = c.q;
      btn.textContent = c.label;
      row.appendChild(btn);
    });

    if (state.messages.length === 0) renderChat();
  }

  const ROUTE_LABELS = {
    auto:     "Auto (smart routing)",
    tabular:  "Tabular (SQL / spreadsheets)",
    semantic: "Semantic (documents)",
  };

  $("#route-toggle").addEventListener("click", (e) => {
    const btn = e.target.closest(".route-opt");
    if (!btn) return;
    const newRoute = btn.dataset.route;
    if (newRoute === state.route) return; // already selected — nothing actually changed
    state.route = newRoute;
    $all(".route-opt").forEach(b => b.classList.toggle("is-active", b === btn));
    toast(`Switched to ${ROUTE_LABELS[newRoute] || newRoute} mode`, "success");
  });

  $("#new-session-btn").addEventListener("click", () => {
    state.sessionId = "ui-" + Math.random().toString(16).slice(2, 10);
    state.messages = [];
    state.sendGeneration++;   // invalidate any in-flight request from the old session
    state.isSending = false;
    state.editingIndex = null;
    $("#send-btn").disabled = false;
    chatInput.disabled = false;
    $("#session-id-display").textContent = state.sessionId;
    renderChat();
    toast("Started a new session", "success");
  });

  $("#chat-log").addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    if (chip.dataset.nav) { setView(chip.dataset.nav); return; }
    if (!chip.dataset.q) return;
    $("#chat-input").value = chip.dataset.q;
    submitChat();
  });

  const chatInput = $("#chat-input");
  chatInput.addEventListener("input", () => {
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 160) + "px";
  });
  chatInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (state.isSending) return;
      submitChat();
    }
  });
  $("#chat-form").addEventListener("submit", (e) => {
    e.preventDefault();
    if (state.isSending) return;
    submitChat();
  });

  // ───────────────────────── CHAT FILE ATTACHMENTS ─────────────────────────
  // Files attached from the Chat view go through the exact same
  // /ingest/upload/start pipeline as the Knowledge Base uploader, so anything
  // sent here shows up in Knowledge Base / Data Sources immediately too.

  const chatFileInput = $("#chat-file-input");
  const chatAttachBtn = $("#chat-attach-btn");

  chatAttachBtn.addEventListener("click", () => chatFileInput.click());
  chatFileInput.addEventListener("change", () => {
    addChatFiles([...chatFileInput.files]);
    chatFileInput.value = "";
  });

  function addChatFiles(files) {
    if (!files.length) return;
    const existingNames = new Set(state.chatPendingFiles.map(f => f.name));
    const accepted = [];
    let duplicates = 0;
    files.forEach(f => {
      if (existingNames.has(f.name)) { duplicates++; return; }
      existingNames.add(f.name);
      accepted.push(f);
    });
    state.chatPendingFiles.push(...accepted);
    if (duplicates > 0) toast(`Skipped ${duplicates} duplicate file${duplicates !== 1 ? "s" : ""}`, "info");
    renderChatAttachments();
    chatInput.focus();
  }

  function formatFileSize(bytes) {
    if (!bytes && bytes !== 0) return "";
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  }

  function renderChatAttachments() {
    const row = $("#chat-attachments");
    row.innerHTML = "";
    row.hidden = state.chatPendingFiles.length === 0;
    chatAttachBtn.classList.toggle("has-files", state.chatPendingFiles.length > 0);
    state.chatPendingFiles.forEach((f, idx) => {
      const chip = document.createElement("div");
      chip.className = "chat-attachment-chip";
      chip.innerHTML = `
        <span class="cac-icon">${ICONS.file}</span>
        <span class="cac-name" title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</span>
        <span class="cac-size">${formatFileSize(f.size)}</span>
      `;
      const rm = document.createElement("button");
      rm.type = "button";
      rm.title = "Remove";
      rm.innerHTML = ICONS.close;
      rm.addEventListener("click", () => {
        state.chatPendingFiles.splice(idx, 1);
        renderChatAttachments();
      });
      chip.appendChild(rm);
      row.appendChild(chip);
    });
  }

  // Uploads+ingests attached files via the shared ingestion job endpoint,
  // rendering live progress inside a chat bubble, then resolves once the
  // job reaches a terminal state (done / done_with_errors / cancelled / error).
  function ingestFilesFromChat(files, statusMsg) {
    return new Promise(async (resolve) => {
      statusMsg.uploadState = { files: files.map(f => ({ name: f.name, size: f.size })), status: "uploading", detail: "Uploading…" };
      renderChat();
      try {
        const form = new FormData();
        files.forEach(f => form.append("files", f));
        const res = await fetch(API + "/ingest/upload/start", { method: "POST", body: form });
        const body = await safeJson(res);
        if (!res.ok) throw new Error(body?.detail || `HTTP ${res.status}`);

        const jobId = body.job_id;
        const poll = async () => {
          let job;
          try {
            job = await apiGet(`/ingest/upload/${jobId}/status`);
          } catch (e) {
            statusMsg.uploadState.status = "error";
            statusMsg.uploadState.detail = "Lost connection while ingesting: " + (e.message || "");
            renderChat();
            resolve(statusMsg.uploadState);
            return;
          }
          const label = job.current_file ? ` — ${job.current_file}` : "";
          statusMsg.uploadState.detail = `Ingesting ${job.files_done} / ${job.files_total} file(s)…${label}`;
          renderChat();
          if (job.status === "running") { setTimeout(poll, 1000); return; }

          statusMsg.uploadState.status = job.status;
          if (job.status === "done") {
            const bits = [`${job.files_done} file(s) added to the Knowledge Base`];
            if (job.chunks_embedded) bits.push(`${job.chunks_embedded} chunk(s) embedded`);
            if (job.tabular_tables) bits.push(`${job.tabular_tables} table(s)`);
            statusMsg.uploadState.detail = bits.join(" · ");
          } else if (job.status === "done_with_errors") {
            statusMsg.uploadState.detail = `Added with ${job.errors.length} issue(s): ${summarizeErrors(job.errors)}`;
          } else if (job.status === "cancelled") {
            statusMsg.uploadState.detail = "Upload was cancelled.";
          } else {
            statusMsg.uploadState.detail = "Upload failed" + (job.errors?.length ? ": " + summarizeErrors(job.errors) : ".");
          }
          renderChat();
          refreshKb();
          refreshHeader();
          refreshExampleChips();
          resolve(statusMsg.uploadState);
        };
        poll();
      } catch (e) {
        statusMsg.uploadState.status = "error";
        statusMsg.uploadState.detail = "Upload failed: " + (e.message || "");
        renderChat();
        toast("Upload failed: " + (e.message || ""), "error");
        resolve(statusMsg.uploadState);
      }
    });
  }


  function renderChat() {
    const log = $("#chat-log");
    if (state.messages.length === 0) {
      log.innerHTML = "";
      log.appendChild(emptyStateTemplate.cloneNode(true));
      return;
    }
    log.innerHTML = "";
    state.messages.forEach((m, idx) => log.appendChild(renderMessage(m, idx)));
    log.scrollTop = log.scrollHeight;
  }

  function buildEmptyState() {
    // Unused fallback kept only in case emptyStateTemplate somehow fails to
    // capture the original markup; renderChat() no longer relies on this.
    const div = document.createElement("div");
    div.id = "chat-empty";
    div.className = "chat-empty";
    div.textContent = "Start a conversation.";
    return div;
  }

  const QTYPE_LABEL = {
    tabular: { text: "TABULAR · SQL", cls: "tag-tabular" },
    semantic: { text: "SEMANTIC · RAG", cls: "tag-semantic" },
    tabular_fallback_semantic: { text: "TABULAR → SEMANTIC", cls: "tag-tabular" },
    multi_document: { text: "MULTI-DOCUMENT", cls: "tag-semantic" },
  };

  function renderMessage(m, idx) {
    const wrap = document.createElement("div");
    wrap.className = "msg " + m.role;

    const avatar = document.createElement("div");
    avatar.className = "msg-avatar";
    avatar.textContent = m.role === "user" ? "You" : "AI";
    wrap.appendChild(avatar);

    const col = document.createElement("div");
    col.style.minWidth = "0";

    // Inline edit mode: user message becomes an editable textarea in place of
    // the bubble. Saving resends the edited question and drops everything
    // after it (old reply + any later turns), mirroring Claude's own
    // edit-and-resend behavior — fully driven by the existing /query/chat API.
    if (m.role === "user" && idx === state.editingIndex) {
      const editBox = document.createElement("div");
      editBox.className = "msg-edit-box";

      const ta = document.createElement("textarea");
      ta.value = m.content;
      ta.rows = Math.min(6, Math.max(2, Math.ceil(m.content.length / 60)));
      editBox.appendChild(ta);

      const editActions = document.createElement("div");
      editActions.className = "msg-edit-actions";

      const cancelBtn = document.createElement("button");
      cancelBtn.className = "btn-ghost btn-xs";
      cancelBtn.type = "button";
      cancelBtn.textContent = "Cancel";
      cancelBtn.addEventListener("click", () => { state.editingIndex = null; renderChat(); });

      const saveBtn = document.createElement("button");
      saveBtn.className = "btn-primary btn-xs";
      saveBtn.type = "button";
      saveBtn.textContent = "Save & submit";
      saveBtn.addEventListener("click", () => submitEdit(idx, ta.value));

      ta.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitEdit(idx, ta.value); }
        if (e.key === "Escape") { state.editingIndex = null; renderChat(); }
      });

      editActions.append(cancelBtn, saveBtn);
      editBox.appendChild(editActions);
      col.appendChild(editBox);
      wrap.appendChild(col);
      setTimeout(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = ta.value.length; }, 0);
      return wrap;
    }

    const bubble = document.createElement("div");
    bubble.className = "msg-bubble";
    if (m.uploadState) {
      const iconFor = (status) => status === "done" ? ICONS.check : ICONS.file;
      const rows = m.uploadState.files.map(f =>
        `<div class="msg-upload-row ${m.uploadState.status === "done" ? "is-done" : ""}">
           <span class="miu-icon">${iconFor(m.uploadState.status)}</span>
           <span>${escapeHtml(f.name)}</span>
           <span style="color:var(--text-faint);margin-left:auto;">${formatFileSize(f.size)}</span>
         </div>`
      ).join("");
      bubble.innerHTML = `<div class="msg-upload-card">${rows}<div class="msg-upload-status">${escapeHtml(m.uploadState.detail || "")}</div></div>` +
        (m.content ? renderRichText(m.content) : "");
    } else if (m.pending) {
      bubble.innerHTML = `<div class="msg-typing"><span></span><span></span><span></span></div>`;
    } else {
      bubble.innerHTML = renderRichText(m.content);
    }
    col.appendChild(bubble);

    if (m.meta && !m.pending) {
      const meta = document.createElement("div");
      meta.className = "msg-meta";
      const qt = QTYPE_LABEL[m.meta.query_type] || { text: (m.meta.query_type || "").toUpperCase(), cls: "tag-source" };
      if (m.meta.query_type) {
        const t = document.createElement("span");
        t.className = "tag " + qt.cls;
        t.textContent = qt.text;
        meta.appendChild(t);
      }
      if (typeof m.meta.confidence === "number") {
        const c = document.createElement("span");
        c.className = "tag tag-conf";
        c.textContent = "confidence " + Math.round(m.meta.confidence * 100) + "%";
        meta.appendChild(c);
      }
      if (m.meta.low_confidence_warning) {
        const w = document.createElement("span");
        w.className = "tag tag-warn";
        w.textContent = "low confidence";
        meta.appendChild(w);
      }
      if (typeof m.meta.responseTimeMs === "number") {
        const rt = document.createElement("span");
        rt.className = "tag tag-conf";
        rt.textContent = (m.meta.responseTimeMs / 1000).toFixed(1) + "s";
        meta.appendChild(rt);
      }
      (m.meta.sources || []).forEach(s => {
        const sChip = document.createElement("span");
        sChip.className = "tag tag-source";
        sChip.textContent = "📎 " + s;
        meta.appendChild(sChip);
      });
      col.appendChild(meta);

      if (m.meta.sql) {
        const pre = document.createElement("pre");
        pre.className = "code-block";
        pre.style.marginTop = "8px";
        pre.textContent = m.meta.sql;
        col.appendChild(pre);
      }
    }

    // Action row: timestamp + copy (all messages), regenerate (assistant only),
    // edit (user only). Hidden while a message is still pending/streaming.
    if (!m.pending) {
      const actions = document.createElement("div");
      actions.className = "msg-actions";

      const time = document.createElement("span");
      time.className = "msg-time";
      time.textContent = formatTime(m.createdAt || Date.now());
      actions.appendChild(time);

      if (m.role === "assistant" && m.forQuestion) {
        const reloadBtn = document.createElement("button");
        reloadBtn.className = "msg-action-btn";
        reloadBtn.type = "button";
        reloadBtn.title = "Regenerate response";
        reloadBtn.innerHTML = ICONS.reload;
        reloadBtn.addEventListener("click", () => regenerateMessage(idx));
        actions.appendChild(reloadBtn);
      }

      if (m.role === "user" && !m.uploadState) {
        const editBtn = document.createElement("button");
        editBtn.className = "msg-action-btn";
        editBtn.type = "button";
        editBtn.title = "Edit message";
        editBtn.innerHTML = ICONS.edit;
        editBtn.addEventListener("click", () => { state.editingIndex = idx; renderChat(); });
        actions.appendChild(editBtn);
      }

      if (m.content) {
        const copyBtn = document.createElement("button");
        copyBtn.className = "msg-action-btn";
        copyBtn.type = "button";
        copyBtn.title = "Copy";
        copyBtn.innerHTML = ICONS.copy;
        copyBtn.addEventListener("click", () => copyMessageText(m.content, copyBtn));
        actions.appendChild(copyBtn);
      }

      if (m.role === "assistant" && m.content) {
        const exportBtn = document.createElement("button");
        exportBtn.className = "msg-action-btn";
        exportBtn.type = "button";
        exportBtn.title = "Export response as PDF";
        exportBtn.innerHTML = ICONS.download;
        exportBtn.addEventListener("click", () => exportMessageAsPDF(m, exportBtn));
        actions.appendChild(exportBtn);
      }

      col.appendChild(actions);
    }

    wrap.appendChild(col);
    return wrap;
  }

  function routeQuestion(text) {
    if (state.route === "tabular") return `[TABULAR] ${text}`;
    if (state.route === "semantic") return `[SEMANTIC] ${text}`;
    return text;
  }

  // Shared by submitChat(), regenerateMessage(), and submitEdit() — every path
  // that talks to the backend goes through this one function and the same
  // /query/chat contract, so edit/reload stay fully compatible with the API.
  async function runChatTurn(routedQ, pendingMsg) {
    state.isSending = true;
    const myGeneration = ++state.sendGeneration;
    $("#send-btn").disabled = true;
    chatInput.disabled = true;
    const t0 = performance.now();

    try {
      const result = await apiPost("/query/chat", {
        question: routedQ,
        session_id: state.sessionId,
      });
      pendingMsg.pending = false;
      pendingMsg.content = result.answer || "No answer.";
      pendingMsg.createdAt = Date.now();
      pendingMsg.meta = {
        query_type: result.query_type,
        confidence: result.confidence,
        sources: result.sources,
        sql: result.sql,
        low_confidence_warning: result.low_confidence_warning,
        responseTimeMs: Math.round(performance.now() - t0),
      };
    } catch (e) {
      pendingMsg.pending = false;
      pendingMsg.content = "Could not reach the server. " + (e.message || "");
      pendingMsg.createdAt = Date.now();
      pendingMsg.meta = null;
      toast("Chat request failed: " + (e.message || "unknown error"), "error");
    }

    // If "New session" (or another send) superseded this request while it was
    // in flight, don't touch shared UI state — it no longer belongs to us.
    if (myGeneration !== state.sendGeneration) return;

    renderChat();
    state.isSending = false;
    $("#send-btn").disabled = false;
    chatInput.disabled = false;
    chatInput.focus();
    refreshHeader();
  }

  async function submitChat() {
    if (state.isSending) return;
    const text = chatInput.value.trim();
    const files = state.chatPendingFiles;
    if (!text && files.length === 0) return;

    chatInput.value = "";
    chatInput.style.height = "auto";
    state.chatPendingFiles = [];
    renderChatAttachments();

    if (files.length > 0) {
      state.isSending = true;
      const myGeneration = ++state.sendGeneration;
      $("#send-btn").disabled = true;
      chatInput.disabled = true;

      const uploadMsg = {
        role: "user",
        content: text,
        createdAt: Date.now(),
        uploadState: { files: files.map(f => ({ name: f.name, size: f.size })), status: "uploading", detail: "Uploading…" },
      };
      state.messages.push(uploadMsg);
      renderChat();

      await ingestFilesFromChat(files, uploadMsg);

      // "New session" (or something else) superseded this upload while it was
      // in flight — don't touch state that no longer belongs to us.
      if (myGeneration !== state.sendGeneration) return;

      state.isSending = false;
      $("#send-btn").disabled = false;
      chatInput.disabled = false;

      if (!text) { chatInput.focus(); return; } // files only, nothing to ask — done

      // A question was asked alongside the upload: ask it as its own turn so
      // the answer can draw on the file that was just ingested.
      const routedQ = routeQuestion(text);
      const pendingMsg = { role: "assistant", content: "", pending: true, forQuestion: routedQ };
      state.messages.push(pendingMsg);
      renderChat();
      await runChatTurn(routedQ, pendingMsg);
      return;
    }

    const routedQ = routeQuestion(text);
    state.messages.push({ role: "user", content: text, createdAt: Date.now(), sentQuestion: routedQ });
    const pendingMsg = { role: "assistant", content: "", pending: true, forQuestion: routedQ };
    state.messages.push(pendingMsg);
    renderChat();

    await runChatTurn(routedQ, pendingMsg);
  }

  // Re-ask the question tied to an existing assistant reply, replacing its
  // content in place once the new answer comes back.
  async function regenerateMessage(idx) {
    if (state.isSending) { toast("Please wait for the current response to finish.", "info"); return; }
    const msg = state.messages[idx];
    if (!msg || msg.role !== "assistant" || !msg.forQuestion) return;
    msg.pending = true;
    msg.content = "";
    msg.meta = null;
    renderChat();
    await runChatTurn(msg.forQuestion, msg);
  }

  // Edit a previous user message and resend it. Drops that message and
  // everything after it (its old reply + any later turns) before resending,
  // same as Claude/ChatGPT's edit-and-resend UX.
  async function submitEdit(idx, rawText) {
    const text = rawText.trim();
    if (!text) { toast("Message can't be empty", "info"); return; }
    if (state.isSending) { toast("Please wait for the current response to finish.", "info"); return; }

    state.messages = state.messages.slice(0, idx);
    state.editingIndex = null;

    const routedQ = routeQuestion(text);
    state.messages.push({ role: "user", content: text, createdAt: Date.now(), sentQuestion: routedQ });
    const pendingMsg = { role: "assistant", content: "", pending: true, forQuestion: routedQ };
    state.messages.push(pendingMsg);
    renderChat();

    await runChatTurn(routedQ, pendingMsg);
  }

  // ───────────────────────── KNOWLEDGE BASE ─────────────────────────

  const dropzone = $("#dropzone");
  const fileInput = $("#file-input");

  $("#browse-btn").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", () => addFiles([...fileInput.files]));

  // dragenter/dragleave fire per-element as the pointer crosses child nodes
  // (icon, text, button) inside the dropzone, not just at its outer boundary.
  // A naive add-on-enter/remove-on-leave toggle flickers as those fire in
  // quick succession; a counter keeps the highlight steady until the pointer
  // has actually left every nested element.
  let dragCounter = 0;
  dropzone.addEventListener("dragenter", (e) => {
    e.preventDefault();
    dragCounter++;
    dropzone.classList.add("is-dragover");
  });
  dropzone.addEventListener("dragover", (e) => { e.preventDefault(); });
  dropzone.addEventListener("dragleave", (e) => {
    e.preventDefault();
    dragCounter = Math.max(0, dragCounter - 1);
    if (dragCounter === 0) dropzone.classList.remove("is-dragover");
  });
  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dragCounter = 0;
    dropzone.classList.remove("is-dragover");
    const files = [...(e.dataTransfer?.files || [])];
    addFiles(files);
  });

  function addFiles(files) {
    const existingNames = new Set(state.pendingFiles.map(f => f.name));
    const accepted = [];
    let duplicates = 0;
    files.forEach(f => {
      if (existingNames.has(f.name)) { duplicates++; return; }
      existingNames.add(f.name);
      accepted.push(f);
    });
    state.pendingFiles.push(...accepted);
    if (duplicates > 0) {
      toast(`Skipped ${duplicates} duplicate file${duplicates !== 1 ? "s" : ""} already in the upload list`, "info");
    }
    renderFilePills();
  }

  function renderFilePills() {
    const row = $("#upload-file-list");
    row.innerHTML = "";
    state.pendingFiles.forEach((f, idx) => {
      const pill = document.createElement("div");
      pill.className = "file-pill";
      pill.innerHTML = `<span>${escapeHtml(f.name)}</span>`;
      const rm = document.createElement("button");
      rm.textContent = "×";
      rm.addEventListener("click", () => {
        state.pendingFiles.splice(idx, 1);
        renderFilePills();
      });
      pill.appendChild(rm);
      row.appendChild(pill);
    });
    $("#ingest-btn").disabled = !!activeIngestJob.id || state.pendingFiles.length === 0;
  }

  // Tracks the currently running ingestion job (if any) so the Stop button
  // and the status poller both know what to act on.
  let activeIngestJob = { id: null, pollTimer: null };

  function setIngestingUi(isRunning) {
    $("#ingest-btn").disabled = isRunning || state.pendingFiles.length === 0;
    $("#ingest-cancel-btn").hidden = !isRunning;
    $("#upload-progress").hidden = !isRunning;
  }

  $("#ingest-btn").addEventListener("click", async () => {
    if (state.pendingFiles.length === 0 || activeIngestJob.id) return;
    $("#upload-status").classList.remove("warn", "error");
    $("#upload-progress").classList.remove("warn", "error");
    $("#upload-status").textContent = "Uploading…";
    setIngestingUi(true);
    try {
      const form = new FormData();
      state.pendingFiles.forEach(f => form.append("files", f));
      const res = await fetch(API + "/ingest/upload/start", { method: "POST", body: form });
      const body = await safeJson(res);
      if (!res.ok) throw new Error(body?.detail || `HTTP ${res.status}`);

      activeIngestJob.id = body.job_id;
      $("#upload-status").textContent = `Ingesting 0 / ${body.files_total} file(s)…`;
      $("#upload-progress").textContent = "Starting…";
      pollIngestJob(body.job_id);
    } catch (e) {
      $("#upload-status").textContent = "Upload failed: " + e.message;
      toast("Upload failed: " + e.message, "error");
      setIngestingUi(false);
      activeIngestJob.id = null;
    }
  });

  $("#ingest-cancel-btn").addEventListener("click", async () => {
    if (!activeIngestJob.id) return;
    $("#ingest-cancel-btn").disabled = true;
    $("#ingest-cancel-btn").textContent = "Stopping…";
    try {
      await apiPost(`/ingest/upload/${activeIngestJob.id}/cancel`, {});
      toast("Stopping after the current file finishes…", "info");
    } catch (e) {
      toast("Could not stop ingestion: " + e.message, "error");
      $("#ingest-cancel-btn").disabled = false;
      $("#ingest-cancel-btn").textContent = "Stop ingesting";
    }
  });

  function pollIngestJob(jobId) {
    if (activeIngestJob.pollTimer) clearTimeout(activeIngestJob.pollTimer);
    let consecutiveFailures = 0;
    const MAX_CONSECUTIVE_FAILURES = 20; // ~30s of transient failures before giving up

    const tick = async () => {
      if (activeIngestJob.id !== jobId) return; // a new job replaced this one
      let job;
      try {
        job = await apiGet(`/ingest/upload/${jobId}/status`);
        consecutiveFailures = 0;
      } catch (e) {
        if (e.status === 404) {
          // The job is gone for good (expired, or the server restarted and
          // lost its in-memory job list) — retrying forever would just spin.
          // Treat it as a stopped/unknown job and let the KB refresh show
          // whatever actually made it into the stores.
          toast("Lost track of that ingestion job (server may have restarted). Refreshing status…", "info");
          finishIngestJob({
            status: "error", files_done: 0, files_total: 0,
            chunks_embedded: 0, tabular_tables: 0, tabular_rows: 0,
            errors: ["Ingestion job not found — check the Knowledge Base list for what was actually ingested."],
          });
          return;
        }
        consecutiveFailures++;
        if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
          toast("Lost connection while checking ingestion progress.", "error");
          finishIngestJob({
            status: "error", files_done: 0, files_total: 0,
            chunks_embedded: 0, tabular_tables: 0, tabular_rows: 0,
            errors: [e.message || "Could not reach the server."],
          });
          return;
        }
        // Transient network hiccup — try again rather than giving up on one miss.
        activeIngestJob.pollTimer = setTimeout(tick, 1500);
        return;
      }

      const label = job.current_file ? ` — ${job.current_file}` : "";
      $("#upload-status").textContent = `Ingesting ${job.files_done} / ${job.files_total} file(s)…${label}`;
      const progressBits = [`${job.chunks_embedded} chunk(s) embedded so far`];
      if (job.tabular_tables) progressBits.push(`${job.tabular_tables} table(s), ${job.tabular_rows} rows`);
      if (job.errors && job.errors.length) {
        progressBits.push(`⚠ ${job.errors.length} issue(s) so far`);
        $("#upload-progress").classList.add("warn");
      } else {
        $("#upload-progress").classList.remove("warn");
      }
      $("#upload-progress").textContent = progressBits.join(" · ");

      if (job.status === "running") {
        activeIngestJob.pollTimer = setTimeout(tick, 1200);
        return;
      }

      // Terminal state: done | cancelled | error
      finishIngestJob(job);
    };

    tick();
  }

  function summarizeErrors(errors, max = 3) {
    if (!errors || errors.length === 0) return "";
    const shown = errors.slice(0, max).join("; ");
    const more = errors.length > max ? ` (+${errors.length - max} more)` : "";
    return shown + more;
  }

  function finishIngestJob(job) {
    activeIngestJob.id = null;
    if (activeIngestJob.pollTimer) { clearTimeout(activeIngestJob.pollTimer); activeIngestJob.pollTimer = null; }

    $("#ingest-cancel-btn").disabled = false;
    $("#ingest-cancel-btn").textContent = "Stop ingesting";
    setIngestingUi(false);

    const statusEl = $("#upload-status");
    statusEl.classList.remove("warn", "error");

    if (job.status === "done") {
      const lines = [`${job.files_done} file(s) ingested`];
      if (job.chunks_embedded) lines.push(`${job.chunks_embedded} chunks → vector store`);
      if (job.tabular_tables) lines.push(`${job.tabular_tables} table(s), ${job.tabular_rows} rows → SQL store`);
      statusEl.textContent = lines.join(" · ");
      $("#upload-progress").textContent = "";
      toast("Ingestion complete", "success");
      state.pendingFiles = [];
      renderFilePills();

    } else if (job.status === "done_with_errors") {
      // Completed, but part of it silently failed (bad table, chunks that
      // wouldn't embed, etc.) — never report this as a clean success.
      statusEl.classList.add("warn");
      statusEl.textContent =
        `Ingested with issues: ${job.files_done} / ${job.files_total} file(s) processed, ` +
        `${job.errors.length} issue(s) — ${summarizeErrors(job.errors)}`;
      $("#upload-progress").textContent = "";
      toast(`Ingestion finished with ${job.errors.length} issue(s) — check the status line for details`, "error");
      state.pendingFiles = [];
      renderFilePills();

    } else if (job.status === "cancelled") {
      statusEl.classList.add("warn");
      let msg =
        `Stopped after ${job.files_done} / ${job.files_total} file(s). ` +
        `Rolled back ${job.rolled_back_chunks} chunk(s)` +
        (job.rolled_back_tables ? ` and ${job.rolled_back_tables} table(s)` : "") + " — nothing partial was kept.";
      if (job.errors && job.errors.length) {
        msg += ` Also hit ${job.errors.length} issue(s) before stopping: ${summarizeErrors(job.errors)}`;
      }
      statusEl.textContent = msg;
      $("#upload-progress").textContent = "";
      toast("Ingestion stopped — partial data was rolled back", "info");
      state.pendingFiles = [];
      renderFilePills();

    } else {
      statusEl.classList.add("error");
      statusEl.textContent = "Ingestion failed" + (job.errors?.length ? ": " + summarizeErrors(job.errors) : ".");
      $("#upload-progress").textContent = "";
      toast("Ingestion failed", "error");
    }

    refreshKb();
    refreshHeader();
    refreshExampleChips();
  }

  $("#kb-refresh-btn").addEventListener("click", refreshKb);
  $("#kb-search").addEventListener("input", (e) => { state.kbSearch = e.target.value.trim().toLowerCase(); renderKbTable(); });
  $("#kb-filter").addEventListener("change", (e) => { state.kbFilter = e.target.value; renderKbTable(); });

  async function refreshKb() {
    const list = $("#kb-list");
    list.innerHTML = `<div class="skeleton-row"></div><div class="skeleton-row"></div><div class="skeleton-row"></div>`;
    try {
      const kb = await apiGet("/ingest/kb");
      $("#kb-stat-files").textContent = kb.total_files ?? 0;
      $("#kb-stat-chunks").textContent = kb.total_chunks ?? 0;
      $("#kb-stat-tables").textContent = kb.total_tables ?? 0;
      state.kbDocs = kb.documents || [];
      renderKbTable();
    } catch (e) {
      toast("Could not load knowledge base: " + e.message, "error");
      list.innerHTML = `<div class="empty-state">Could not load knowledge base: ${escapeHtml(e.message)}</div>`;
    }
  }

  function docTypeKey(doc) {
    if (doc.doc_type === "semantic" || doc.doc_type === "tabular") return doc.doc_type;
    return "mixed";
  }

  function renderKbTable() {
    const list = $("#kb-list");
    let docs = state.kbDocs.slice();

    if (state.kbSearch) {
      docs = docs.filter(d => (d.name || "").toLowerCase().includes(state.kbSearch));
    }
    if (state.kbFilter !== "all") {
      docs = docs.filter(d => docTypeKey(d) === state.kbFilter);
    }

    const { field, dir } = state.kbSort;
    docs.sort((a, b) => {
      let av, bv;
      if (field === "chunks") { av = a.chunk_count || 0; bv = b.chunk_count || 0; }
      else { av = (a.name || "").toLowerCase(); bv = (b.name || "").toLowerCase(); }
      if (av < bv) return dir === "asc" ? -1 : 1;
      if (av > bv) return dir === "asc" ? 1 : -1;
      return 0;
    });

    if (state.kbDocs.length === 0) {
      list.innerHTML = `<div class="empty-state">No documents yet — upload files above.</div>`;
      return;
    }
    if (docs.length === 0) {
      list.innerHTML = `<div class="empty-state">No documents match your search/filter.</div>`;
      return;
    }

    const arrow = (f) => f === field ? ` is-sorted${dir === "desc" ? " is-desc" : ""}` : "";
    const table = document.createElement("table");
    table.className = "doc-table";
    table.innerHTML = `
      <thead><tr>
        <th data-sort="name" class="${arrow("name").trim()}">Name</th>
        <th>Type</th>
        <th data-sort="chunks" class="${arrow("chunks").trim()}">Content</th>
        <th></th>
      </tr></thead>
      <tbody></tbody>
    `;
    table.querySelectorAll("th[data-sort]").forEach(th => {
      th.addEventListener("click", () => {
        const f = th.dataset.sort;
        if (state.kbSort.field === f) state.kbSort.dir = state.kbSort.dir === "asc" ? "desc" : "asc";
        else state.kbSort = { field: f, dir: "asc" };
        renderKbTable();
      });
    });

    const tbody = table.querySelector("tbody");
    docs.forEach(doc => tbody.appendChild(renderDocRow(doc)));
    list.innerHTML = "";
    list.appendChild(table);
  }

  function renderDocRow(doc) {
    const row = document.createElement("tr");
    const icon = doc.doc_type === "semantic" ? "📄" : (doc.doc_type === "tabular" ? "📊" : "📄📊");
    const typeKey = docTypeKey(doc);
    const typeLabel = typeKey === "semantic" ? "Semantic" : typeKey === "tabular" ? "Tabular" : "Mixed";

    const subParts = [];
    if (doc.chunk_count) subParts.push(`<code>${doc.chunk_count} chunk${doc.chunk_count !== 1 ? "s" : ""}</code>`);
    (doc.tables || []).forEach(t => {
      const sheet = t.sheet_name ? ` · ${escapeHtml(t.sheet_name)}` : "";
      subParts.push(`<code>${escapeHtml(t.table_name)}${sheet} · ${t.row_count} rows</code>`);
    });

    row.innerHTML = `
      <td><div class="doc-name-cell">${icon} ${escapeHtml(doc.name)}</div></td>
      <td><span class="status-badge ${typeKey}">${typeLabel}</span></td>
      <td>${subParts.join(" &nbsp; ") || "No content extracted"}</td>
    `;
    const actionsTd = document.createElement("td");
    const previewBtn = document.createElement("button");
    previewBtn.className = "btn-ghost btn-xs dp-preview-trigger";
    previewBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg><span>Preview</span>`;
    previewBtn.title = `Preview ${doc.name}`;
    previewBtn.addEventListener("click", () => {
      if (window.DocPreview) window.DocPreview.open(doc.name);
    });
    actionsTd.appendChild(previewBtn);
    const delBtn = document.createElement("button");
    delBtn.className = "btn-ghost btn-xs";
    delBtn.textContent = "Delete";
    delBtn.addEventListener("click", async () => {
      const ok = await confirmModal("Delete document", `Permanently remove "${doc.name}" from all stores (embeddings, SQL tables, registry)?`);
      if (!ok) return;
      try {
        const result = await apiDelete(`/ingest/kb/${encodeURIComponent(doc.name)}`);
        toast(`Deleted ${doc.name} (${result.deleted_chunks || 0} chunks)`, "success");
        refreshKb();
        refreshHeader();
        refreshExampleChips();
      } catch (e) {
        toast("Delete failed: " + e.message, "error");
      }
    });
    actionsTd.appendChild(delBtn);
    row.appendChild(actionsTd);
    return row;
  }

  // ───────────────────────── DATA SOURCES ─────────────────────────

  $("#data-refresh-btn").addEventListener("click", refreshTables);

  async function refreshTables() {
    const list = $("#table-list");
    list.innerHTML = `<div class="skeleton-card"></div><div class="skeleton-card"></div>`;
    try {
      const data = await apiGet("/data/tables");
      const tables = data.tables || [];
      if (tables.length === 0) {
        list.innerHTML = `<div class="empty-state">No tables yet — upload a CSV or Excel file in Knowledge Base.</div>`;
        return;
      }
      list.innerHTML = "";
      tables.forEach(name => {
        const card = document.createElement("div");
        card.className = "table-card";
        card.innerHTML = `<div class="table-card-name">${escapeHtml(name)}</div><div class="table-card-meta">Click to preview rows</div>`;
        card.addEventListener("click", () => previewTable(name));
        list.appendChild(card);
      });
    } catch (e) {
      toast("Could not load tables: " + e.message, "error");
      list.innerHTML = `<div class="empty-state">Could not load tables: ${escapeHtml(e.message)}</div>`;
    }
  }

  async function previewTable(name) {
    try {
      const result = await apiGet(`/data/tables/${encodeURIComponent(name)}/preview?limit=10`);
      const rows = result.rows || result.data || [];
      const cols = result.columns || (rows[0] ? Object.keys(rows[0]) : []);
      let html = `<strong>${escapeHtml(name)}</strong> — preview (first ${rows.length} rows)`;
      if (cols.length) {
        html += `<table class="preview-table"><thead><tr>${cols.map(c => `<th>${escapeHtml(c)}</th>`).join("")}</tr></thead><tbody>`;
        rows.forEach(r => {
          const cells = Array.isArray(r) ? r : cols.map(c => r[c]);
          html += `<tr>${cells.map(c => `<td>${c === null || c === undefined ? "" : escapeHtml(c)}</td>`).join("")}</tr>`;
        });
        html += `</tbody></table>`;
      }
      $("#sql-output").innerHTML = html;
    } catch (e) {
      toast("Preview failed: " + e.message, "error");
    }
  }

  $("#sql-preview-btn").addEventListener("click", async () => {
    const q = $("#sql-question").value.trim();
    if (!q) { toast("Enter a question first", "info"); return; }
    $("#sql-output").textContent = "Generating…";
    try {
      const result = await apiPost("/query/sql/preview", { question: q });
      $("#sql-output").textContent =
        `SQL:\n${result.sql || "(none generated)"}\n\nValid: ${result.is_valid}\n${result.message || ""}`;
    } catch (e) {
      $("#sql-output").textContent = "Error: " + e.message;
    }
  });

  $("#sql-exec-btn").addEventListener("click", async () => {
    const q = $("#sql-question").value.trim();
    if (!q) { toast("Enter raw SQL in the box first", "info"); return; }
    $("#sql-output").textContent = "Running…";
    try {
      const result = await apiPost("/query/sql/execute", { question: q });
      $("#sql-output").textContent = JSON.stringify(result, null, 2);
    } catch (e) {
      $("#sql-output").textContent = "Error: " + e.message;
    }
  });

  // ───────────────────────── MODELS ─────────────────────────

  $("#models-refresh-btn").addEventListener("click", refreshModels);

  async function refreshModels() {
    const list = $("#model-list");
    list.innerHTML = `<div class="skeleton-card"></div><div class="skeleton-card"></div><div class="skeleton-card"></div>`;
    try {
      const data = await apiGet("/models/");

      // Current-configuration summary — reuses cached /models/current data,
      // only fetching if it isn't already warm from header polling.
      const current = statusCache.model || await fetchModelCurrent().catch(() => null);
      $("#models-stat-llm").textContent = (current && current.current_llm) || "—";
      $("#models-stat-embed").textContent = (current && current.current_embed) || "—";

      if (!data.ollama_available) {
        list.innerHTML = `<div class="empty-state">${escapeHtml(data.error || "Ollama not available")}</div>`;
        $("#models-stat-memory").textContent = "—";
        return;
      }
      const models = (data.models || []).filter(m => !m.is_embed);
      const activeModel = models.find(m => m.is_current);
      $("#models-stat-memory").textContent = (activeModel && activeModel.size_gb) ? activeModel.size_gb + " GB" : "—";

      if (models.length === 0) {
        list.innerHTML = `<div class="empty-state">No models installed. Run: <code>ollama pull llama3.2</code></div>`;
        return;
      }
      list.innerHTML = "";
      models.forEach(m => list.appendChild(renderModelCard(m)));
    } catch (e) {
      list.innerHTML = `<div class="empty-state">Could not load models: ${escapeHtml(e.message)}</div>`;
      $("#models-stat-memory").textContent = "—";
    }
  }

  function renderModelCard(m) {
    const card = document.createElement("div");
    card.className = "model-card" + (m.is_current ? " is-active" : "");
    const meta = [];
    if (m.parameter_size) meta.push(m.parameter_size);
    if (m.size_gb) meta.push(m.size_gb + " GB");
    if (m.quantization) meta.push(m.quantization);
    card.innerHTML = `
      <div class="model-card-name">${escapeHtml(m.display_name)}</div>
      <div class="model-card-meta">${meta.map(x => `<span>${escapeHtml(x)}</span>`).join(" · ")}</div>
      <div class="model-card-foot">
        ${m.is_current ? `<span class="tag tag-semantic">Active</span>` : `<span></span>`}
      </div>
    `;
    if (!m.is_current) {
      const btn = document.createElement("button");
      btn.className = "btn-secondary btn-sm";
      btn.textContent = "Switch to this model";
      btn.addEventListener("click", () => switchModel(m.name, btn));
      card.querySelector(".model-card-foot").appendChild(btn);
    }
    return card;
  }

  async function switchModel(name, btn) {
    btn.disabled = true;
    btn.textContent = "Switching…";
    $("#model-status").textContent = `Switching to ${name}…`;
    try {
      const result = await apiPost("/models/switch", { model_name: name }, 90000);
      $("#model-status").textContent = `Switched to ${result.model_name}.`;
      toast(`Active model is now ${result.model_name}`, "success");
      refreshModels();
      invalidateModelCache();
      refreshHeader({ forceModel: true });
    } catch (e) {
      $("#model-status").textContent = "Switch failed: " + e.message;
      toast("Model switch failed: " + e.message, "error");
      btn.disabled = false;
      btn.textContent = "Switch to this model";
    }
  }

  // ───────────────────────── SESSIONS ─────────────────────────

  $("#sessions-refresh-btn").addEventListener("click", refreshSessions);

  async function refreshSessions() {
    const list = $("#sessions-list");
    list.innerHTML = `<div class="skeleton-row"></div><div class="skeleton-row"></div>`;
    try {
      const data = await apiGet("/memory/sessions");
      const sessions = data.sessions || [];
      if (sessions.length === 0) {
        list.innerHTML = `<div class="empty-state">No sessions yet.</div>`;
        return;
      }
      list.innerHTML = "";
      sessions.forEach(s => {
        const id = typeof s === "string" ? s : (s.session_id || s.id || JSON.stringify(s));
        const row = document.createElement("div");
        row.className = "session-row" + (id === state.sessions.activeId ? " is-active" : "");
        row.innerHTML = `<span class="session-row-name">${escapeHtml(id)}</span>`;
        const actions = document.createElement("div");
        actions.style.display = "flex";
        actions.style.gap = "6px";

        const viewBtn = document.createElement("button");
        viewBtn.className = "btn-ghost btn-xs";
        viewBtn.textContent = "View";
        viewBtn.addEventListener("click", () => loadSessionHistory(id));

        const delBtn = document.createElement("button");
        delBtn.className = "btn-ghost btn-xs";
        delBtn.textContent = "Delete";
        delBtn.addEventListener("click", async () => {
          const ok = await confirmModal("Delete session", `Delete session "${id}" and all its messages?`);
          if (!ok) return;
          try {
            await apiDelete(`/memory/sessions/${encodeURIComponent(id)}`);
            toast("Session deleted", "success");
            refreshSessions();
          } catch (e) { toast("Delete failed: " + e.message, "error"); }
        });

        actions.append(viewBtn, delBtn);
        row.appendChild(actions);
        list.appendChild(row);
      });
    } catch (e) {
      list.innerHTML = `<div class="empty-state">Could not load sessions: ${escapeHtml(e.message)}</div>`;
    }
  }

  async function loadSessionHistory(id) {
    state.sessions.activeId = id;
    refreshSessions();
    $("#session-detail-title").textContent = id;
    const body = $("#session-detail-body");
    body.innerHTML = `<div class="empty-state">Loading…</div>`;
    try {
      const data = await apiGet(`/memory/sessions/${encodeURIComponent(id)}/history?limit=50`);
      const messages = data.messages || [];
      if (messages.length === 0) {
        body.innerHTML = `<div class="empty-state">No messages in this session.</div>`;
        return;
      }
      body.innerHTML = "";
      messages.forEach(m => {
        const row = document.createElement("div");
        row.className = "transcript-row";
        row.innerHTML = `<div class="transcript-role">${escapeHtml(m.role || "")}</div><div>${renderRichText(m.content || "")}</div>`;
        body.appendChild(row);
      });
    } catch (e) {
      body.innerHTML = `<div class="empty-state">Could not load history: ${escapeHtml(e.message)}</div>`;
    }
  }

  // ───────────────────────── DASHBOARD ─────────────────────────

  $("#dash-refresh-btn").addEventListener("click", refreshDashboard);
  $("#dash-action-chat").addEventListener("click", () => setView("chat"));
  $("#dash-action-upload").addEventListener("click", () => setView("kb"));
  $("#dash-action-models").addEventListener("click", () => setView("models"));
  $("#dash-action-health").addEventListener("click", () => setView("system"));

  async function refreshDashboard() {
    $("#dash-recent-uploads").innerHTML = `<div class="skeleton-row"></div><div class="skeleton-row"></div>`;
    $("#dash-recent-chats").innerHTML = `<div class="skeleton-row"></div><div class="skeleton-row"></div>`;

    // Knowledge base stats + recent uploads
    try {
      const kb = await apiGet("/ingest/kb");
      $("#dash-files").textContent = kb.total_files ?? 0;
      $("#dash-chunks").textContent = kb.total_chunks ?? 0;
      $("#dash-tables").textContent = kb.total_tables ?? 0;

      const docs = (kb.documents || []).slice(-6).reverse();
      const uploads = $("#dash-recent-uploads");
      if (docs.length === 0) {
        uploads.innerHTML = `<div class="empty-state">No documents yet — upload files in Knowledge Base.</div>`;
      } else {
        uploads.innerHTML = "";
        docs.forEach(d => {
          const row = document.createElement("div");
          row.className = "dash-list-row";
          const contentBits = [];
          if (d.chunk_count) contentBits.push(`${d.chunk_count} chunks`);
          if (d.tables && d.tables.length) contentBits.push(`${d.tables.length} table(s)`);
          row.innerHTML = `<span class="dash-list-row-name">${escapeHtml(d.name)}</span><span class="dash-list-row-meta">${escapeHtml(contentBits.join(" · ") || "—")}</span>`;
          uploads.appendChild(row);
        });
      }
    } catch (e) {
      $("#dash-recent-uploads").innerHTML = `<div class="empty-state">Could not load knowledge base: ${escapeHtml(e.message)}</div>`;
    }

    // Active model
    try {
      const current = statusCache.model || await fetchModelCurrent().catch(() => null);
      $("#dash-model").textContent = (current && current.current_llm) || "—";
    } catch (e) {
      $("#dash-model").textContent = "—";
    }

    // System health summary
    try {
      const h = await fetchHealth();
      const errored = h.status === "error";
      const rows = [
        ["Ollama / LLM engine", h.ollama],
        ["Vector database", !errored],
        ["Tabular database", !errored],
      ];
      $("#dash-health").innerHTML = rows.map(([label, ok]) =>
        `<div class="dash-health-row"><span>${escapeHtml(label)}</span><span class="tag ${ok ? "tag-semantic" : "tag-warn"}">${ok ? "Healthy" : "Degraded"}</span></div>`
      ).join("");
    } catch (e) {
      $("#dash-health").innerHTML = `<div class="empty-state">Could not load system health: ${escapeHtml(e.message)}</div>`;
    }

    // Recent chat sessions
    try {
      const data = await apiGet("/memory/sessions");
      const sessions = (data.sessions || []).slice(-6).reverse();
      const chats = $("#dash-recent-chats");
      if (sessions.length === 0) {
        chats.innerHTML = `<div class="empty-state">No sessions yet.</div>`;
      } else {
        chats.innerHTML = "";
        sessions.forEach(s => {
          const id = typeof s === "string" ? s : (s.session_id || s.id || JSON.stringify(s));
          const row = document.createElement("div");
          row.className = "dash-list-row";
          row.innerHTML = `<span class="dash-list-row-name">${escapeHtml(id)}</span>`;
          const viewBtn = document.createElement("button");
          viewBtn.className = "btn-ghost btn-xs";
          viewBtn.textContent = "View";
          viewBtn.addEventListener("click", () => { setView("sessions"); loadSessionHistory(id); });
          row.appendChild(viewBtn);
          chats.appendChild(row);
        });
      }
    } catch (e) {
      $("#dash-recent-chats").innerHTML = `<div class="empty-state">Could not load sessions: ${escapeHtml(e.message)}</div>`;
    }
  }

  // ───────────────────────── SYSTEM HEALTH ─────────────────────────

  $("#ocr-refresh-btn").addEventListener("click", refreshOcr);

  async function refreshSystem() {
    try {
      const h = await fetchHealth();
      $("#sys-stat-status").textContent = h.status || "—";
      $("#sys-stat-ollama").textContent = h.ollama ? "Online" : "Offline";
      $("#sys-stat-version").textContent = h.version || "—";
      $("#health-raw").textContent = JSON.stringify(h, null, 2);

      const errored = h.status === "error";
      $("#sys-comp-ollama").innerHTML = h.ollama
        ? `<span class="dot ok"></span> Online`
        : `<span class="dot bad"></span> Offline — start Ollama and refresh`;
      $("#sys-comp-vector").innerHTML = errored
        ? `<span class="dot bad"></span> Unavailable`
        : `<span class="dot ok"></span> ${h.vector_store_docs ?? 0} chunk(s) indexed`;
      $("#sys-comp-duckdb").innerHTML = errored
        ? `<span class="dot bad"></span> Unavailable`
        : `<span class="dot ok"></span> ${h.tabular_tables ?? 0} table(s) indexed`;
    } catch (e) {
      $("#health-raw").textContent = "Error: " + e.message;
      $("#sys-comp-ollama").innerHTML = `<span class="dot bad"></span> Unreachable`;
      $("#sys-comp-vector").innerHTML = `<span class="dot bad"></span> Unreachable`;
      $("#sys-comp-duckdb").innerHTML = `<span class="dot bad"></span> Unreachable`;
    }

    // SQLite-backed session store — probed via the real sessions endpoint
    // rather than invented, since /health doesn't break this out separately.
    try {
      await apiGet("/memory/sessions");
      $("#sys-comp-sqlite").innerHTML = `<span class="dot ok"></span> Online`;
    } catch (e) {
      $("#sys-comp-sqlite").innerHTML = `<span class="dot bad"></span> Unreachable`;
    }

    refreshOcr();
  }

  async function refreshOcr() {
    const grid = $("#ocr-status");
    grid.innerHTML = `<div class="skeleton-card"></div><div class="skeleton-card"></div>`;
    try {
      const data = await apiGet("/data/ocr/status");
      const status = data.engine_status || {};
      const entries = Object.entries(status);
      if (entries.length === 0) {
        grid.innerHTML = `<div class="empty-state">No OCR engine info available.</div>`;
        return;
      }
      grid.innerHTML = "";
      entries.forEach(([engine, value]) => {
        const card = document.createElement("div");
        card.className = "ocr-card";
        card.innerHTML = `<div class="ocr-card-title">${escapeHtml(engine)}</div><div>${escapeHtml(value)}</div>`;
        grid.appendChild(card);
      });
      if (data.recommendation) {
        const rec = document.createElement("div");
        rec.className = "ocr-card";
        rec.innerHTML = `<div class="ocr-card-title">Recommendation</div><div>${escapeHtml(data.recommendation)}</div>`;
        grid.appendChild(rec);
      }
    } catch (e) {
      grid.innerHTML = `<div class="empty-state">Could not load OCR status: ${escapeHtml(e.message)}</div>`;
    }
  }

  // ───────────────────────── SPLASH SCREEN ─────────────────────────

  (function initSplash() {
    const splash = $("#splash-screen");
    const fill = $("#splash-bar-fill");
    const status = $("#splash-status");
    if (!splash || !fill || !status) return;

    const steps = [
      { pct: 12, text: "Initializing secure session…" },
      { pct: 28, text: "Loading local AI engine…" },
      { pct: 46, text: "Loading knowledge base…" },
      { pct: 64, text: "Loading vector database…" },
      { pct: 80, text: "Loading models…" },
      { pct: 92, text: "Starting services…" },
      { pct: 100, text: "Ready." },
    ];
    let i = 0;
    const tick = () => {
      if (i >= steps.length) {
        setTimeout(() => splash.classList.add("is-hidden"), 250);
        return;
      }
      fill.style.width = steps[i].pct + "%";
      status.textContent = steps[i].text;
      i++;
      setTimeout(tick, 300);
    };
    tick();

    // Safety net: never let the splash block the app for more than a few seconds.
    setTimeout(() => splash.classList.add("is-hidden"), 4000);
    splash.addEventListener("click", () => splash.classList.add("is-hidden"));
  })();

  // ───────────────────────── SIDEBAR / HAMBURGER (desktop-only collapse) ─────────────────────────

  (function initSidebarToggle() {
    const shell = $("#app-shell");
    const btn = $("#hamburger-btn");
    if (!shell || !btn) return;

    let open = true; // sidebar starts expanded
    btn.setAttribute("aria-expanded", "true");

    btn.addEventListener("click", () => {
      open = !open;
      shell.classList.toggle("is-collapsed", !open);
      btn.setAttribute("aria-expanded", String(open));
    });
  })();

  // ───────────────────────── init ─────────────────────────

  setView("dashboard");
  refreshHeader({ forceModel: true }); // initial load: fetch health + model together
  refreshExampleChips();
  startPolling();
})();
