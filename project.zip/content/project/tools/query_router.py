"""
tools/query_router.py — Routes questions to "tabular" or "semantic" pipelines.

Strategy:
  1. Filename hints — if the question mentions a known tabular/semantic filename, route there.
  2. Keyword heuristics — fast, free, catches most obvious cases.
  3. LLM classification fallback — for ambiguous questions, ask the configured LLM.
"""

import json
import urllib.request
import urllib.error
from typing import Dict, List, Optional

from config.settings import OLLAMA_BASE_URL, LLM_MODEL, ROUTER_SYSTEM_PROMPT
from utils.logger import get_logger

logger = get_logger("router")

_TABULAR_KEYWORDS = [
    "total", "sum", "average", "avg", "count", "maximum", "max", "minimum", "min",
    "how many", "how much", "percentage", "percent", "growth", "rate",
    "highest", "lowest", "top ", "rank", "ranking", "compare", "comparison",
    "mean", "median", "aggregate", "calculate", "number of",
    # Row-lookup phrasing — these ask for a specific record/row, which is a SQL
    # "SELECT * WHERE ..." query, not a semantic/document question, even though
    # they don't contain an obvious aggregation keyword.
    "detail of", "details of", "details for", "detail for", "info about",
    "information about", "info on", "information on", "record of", "record for",
    "profile of", "who is", "tell me about", "show me", "list of", "data for",
    "data on",
]

_SEMANTIC_KEYWORDS = [
    "what is", "explain", "describe", "why", "how to", "policy", "procedure",
    "definition", "meaning", "summary", "summarize", "process", "guideline",
    "rule", "overview",
]


class QueryRouter:
    """Classify a question as 'tabular' or 'semantic'."""

    def __init__(self, model: str = LLM_MODEL, ollama_url: str = OLLAMA_BASE_URL):
        self.model = model
        self.ollama_url = ollama_url
        self.has_tabular = False
        self.has_semantic = False
        self.tabular_sources: List[str] = []
        self.semantic_sources: List[str] = []

    def update_has_tabular(self, has_tabular: bool) -> None:
        self.has_tabular = has_tabular

    def update_has_semantic(self, has_semantic: bool) -> None:
        self.has_semantic = has_semantic

    def update_sources(self, tabular_sources: List[str], semantic_sources: List[str]) -> None:
        self.tabular_sources = tabular_sources or []
        self.semantic_sources = semantic_sources or []

    def route(self, question: str) -> Dict[str, str]:
        """
        Return {"query_type": "tabular"|"semantic", "method": str}.
        method explains which strategy decided the route (for logging/debugging).
        """
        if not self.has_tabular:
            return {"query_type": "semantic", "method": "no_tabular_data"}

        # If the semantic/vector store has no documents at all (e.g. the only uploads
        # were CSV/XLSX files, which are ingested into DuckDB only — see
        # ingestion_service.py's docstring on never embedding numerical data), routing
        # to "semantic" can only ever produce "No documents ingested yet." Skip the
        # keyword/LLM steps entirely and force tabular, since that's the only pipeline
        # that actually has any data to answer from.
        if not self.has_semantic:
            return {"query_type": "tabular", "method": "semantic_store_empty"}

        q_lower = question.lower()

        # 1. Filename hints
        for fname in self.tabular_sources:
            stem = fname.rsplit(".", 1)[0].lower()
            if stem and stem in q_lower:
                return {"query_type": "tabular", "method": "filename_hint"}

        for fname in self.semantic_sources:
            stem = fname.rsplit(".", 1)[0].lower()
            if stem and stem in q_lower:
                return {"query_type": "semantic", "method": "filename_hint"}

        # 2. Keyword heuristics
        tabular_score = sum(1 for kw in _TABULAR_KEYWORDS if kw in q_lower)
        semantic_score = sum(1 for kw in _SEMANTIC_KEYWORDS if kw in q_lower)

        if tabular_score > 0 and tabular_score > semantic_score:
            return {"query_type": "tabular", "method": "keyword_heuristic"}
        if semantic_score > 0 and semantic_score > tabular_score:
            return {"query_type": "semantic", "method": "keyword_heuristic"}

        # 3. LLM fallback for ambiguous cases
        try:
            llm_route = self._llm_classify(question)
            if llm_route:
                return {"query_type": llm_route, "method": "llm_classification"}
        except Exception as e:
            logger.warning(f"LLM routing failed, defaulting to semantic: {e}")

        return {"query_type": "semantic", "method": "default_fallback"}

    def _llm_classify(self, question: str) -> Optional[str]:
        """Ask the LLM to classify the question as tabular or semantic."""
        prompt = ROUTER_SYSTEM_PROMPT.format(question=question)
        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.0, "num_predict": 10},
        }).encode()

        req = urllib.request.Request(
            f"{self.ollama_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            answer = data.get("response", "").strip().lower()

        if "tabular" in answer:
            return "tabular"
        if "semantic" in answer:
            return "semantic"
        return None
