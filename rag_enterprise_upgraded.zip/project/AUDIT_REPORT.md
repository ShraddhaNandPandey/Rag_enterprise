# Enterprise RAG System — Audit & Upgrade Report

**Scope:** targeted improvements to the existing production RAG codebase.
No architecture rewrite. FastAPI, ChromaDB, DuckDB, BM25, OCR, PDF layout
parsing, the chunker, and all existing APIs/frontend are unchanged and
continue to work exactly as before — every change below is additive or
backward-compatible (new optional parameters, `ADD COLUMN IF NOT EXISTS`
migrations, new modules with zero required callers).

---

## 1. Root Cause Analysis (per problem)

| # | Problem | Finding | Status |
|---|---|---|---|
| 1 | Router | `tools/query_router.py` decided almost entirely from two hardcoded keyword lists (`_TABULAR_KEYWORDS`, `_SEMANTIC_KEYWORDS`), only falling to an LLM classifier when both scored zero. A question with no matching keyword, or a misleading one (e.g. "show me the process" — "show me" is a tabular keyword, "process" is semantic), could route wrong. | **Fixed** — added evidence-based probing (§3.1) |
| 2 | Evidence planning | There was no explicit "where does the answer live" decision step — routing *was* the evidence decision, conflating "which pipeline" with "where's the evidence". | **Fixed** — the new evidence probe *is* the evidence-location decision; it measures real retrieval signal from both stores before picking a pipeline, rather than assuming from keywords. |
| 3 | SQL planner | Pipeline already existed end-to-end (schema discovery → sample rows/distinct-value hints → LLM generation → validation → execution → one-shot repair) and was notably mature (has its own "top per group" deterministic shortcut, zero-row repair, etc). | **Already solid** — one gap closed (§3.2) |
| 4 | SQL validation | `validate_sql()` only checked "is this a safe read-only SELECT" (regex-based). It never checked that referenced **tables actually exist** before executing — a hallucinated table name went all the way to a raw DuckDB `CatalogException` before the existing repair loop kicked in. | **Fixed** — `validate_sql_schema()` (§3.2) |
| 5 | Document isolation | No `document_id`, content hash, or version existed anywhere in the codebase. Documents were identified purely by filename. Re-uploading a file (same or changed content) had **no cleanup step** — DuckDB tabular tables self-replace by name via `DROP TABLE IF EXISTS`, but **semantic chunks in ChromaDB were never deleted before re-adding**, so re-ingesting a file duplicated its chunks indefinitely. | **Fixed** — §3.3 |
| 6 | ChromaDB validation | Direct consequence of #5: no duplicate-chunk prevention on re-ingest. Metadata filtering (`build_source_filter`) already existed and worked correctly for scoped queries. | **Fixed** — §3.3 |
| 7 | DuckDB validation | Tabular CSV/XLSX tables already self-replace on re-ingest (`DROP TABLE IF EXISTS` + `CREATE TABLE`), so no duplicate *tables* existed for those — but PDF-extracted tables (registered via `register_table()`, named `{stem}_p{page}_t{idx}`) had no equivalent cleanup, and neither path removed **orphaned** tables from a previous ingestion of a file that changed shape. | **Fixed** — §3.3 |
| 8 | Hybrid retrieval | `_answer_hybrid()` was already well-built: reuses the hardened tabular/semantic paths, gracefully degrades to whichever side has data, and merges both into a single prompt. No changes needed beyond the router/verification upgrades that now also apply to it. | **Already solid** |
| 9 | Context builder | `_build_context()` already tags each chunk with source/page/sheet/relevance and only includes retrieved (already-ranked) chunks — no dead weight. No changes needed. | **Already solid** |
| 10 | Answer verification | There was **no post-generation grounding check**. The system relied entirely on pre-retrieval confidence (`_compute_confidence`) — if retrieval succeeded but the LLM then added unsupported claims in its prose, nothing caught it. | **Fixed** — `core/answer_verifier.py` (§3.4) |
| 11 | Retrieval quality | Hybrid dense+BM25 search, MMR-style fetch multiplier, and merge/rerank logic already existed in `chroma_store.py`. No changes needed. | **Already solid** |
| 12 | Multi-page tables | Confirmed absent — `pdfplumber.page.find_tables()` runs per-page with no cross-page merge step; a table split by a page break produced two smaller, disconnected tables. | **Fixed** — `_merge_multipage_tables()` (§3.5) |
| 13 | Metadata | Page/section/heading/chunk-type metadata already exists (two-level heading hierarchy per the file's own Phase 2 notes). Added `document_id`/`content_hash`/`doc_version` (§3.3) as the missing piece. | **Fixed** (extended) |
| 14 | Performance | Distinct-value hinting already uses `approx_count_distinct` (HLL) to stay cheap on large tables; CSV loading already prefers the fast C-engine path. The new evidence probe adds one extra retrieval call per un-forced query — small, bounded cost for materially better routing. | **No regressions** |
| 15 | Logging | Logging existed throughout as prose `logger.info(...)` calls, but nothing structured/queryable per request. | **Fixed** — structured JSON trace (§3.6) |
| 16 | Automated evaluation | No test/eval framework existed at all. | **Fixed** — `eval/regression_eval.py` (§3.7) |

---

## 2. Files Modified / Added

**New files**
- `utils/doc_identity.py` — content-hash-based document identity + version ledger
- `core/answer_verifier.py` — post-generation grounding/hallucination check
- `eval/regression_eval.py` — regression evaluation harness
- `eval/test_cases.json` — template test-case file (operator fills in real questions)
- `AUDIT_REPORT.md` — this document

**Modified files**
- `tools/query_router.py` — added `route_with_evidence()` (evidence-probing router); `route()` untouched, still used as the fallback/keyword/LLM chain
- `services/query_service.py` — wired evidence-based routing, schema SQL validation, answer verification, structured trace logging (`ask()` split into a thin wrapper + `_ask_impl()`)
- `database/duckdb_manager.py` — added `document_id`/`content_hash`/`doc_version` registry columns (migration-safe), `validate_sql_schema()`, `get_tables_by_document_id()`, identity params on `load_csv`/`load_excel`/`register_table`
- `loaders/file_loader.py` — `load_files()` now stamps every doc's metadata with document identity
- `loaders/pdf_layout_parser.py` — added multi-page table detection/merging
- `services/ingestion_service.py` — added stale-data cleanup before (re-)ingestion; threads document identity into DuckDB registration
- `.gitignore` — ignore the new identity ledger file

---

## 3. What Changed, In Detail

### 3.1 Router — evidence before keywords
`QueryRouter.route_with_evidence(question, vector_store, duckdb_manager)` runs
**one cheap real probe against each store** before any keyword logic:
- Semantic evidence = actual top hybrid-search relevance score (not a guess).
- Table evidence = token overlap between the question and the **discovered**
  schema (table/column names actually present) — not a fixed keyword list.

A strong signal on one/both sides decides the route directly. Only a
genuinely ambiguous case (weak/no signal on both sides) falls through to the
original `route()` — filename hints → keyword heuristic → LLM classification
— so nothing that worked before regresses, and the previously "always
keyword-driven" decision now only fires as a fallback.

### 3.2 SQL planner/validation — catch a hallucinated table before executing
`DuckDBManager.validate_sql_schema()` parses `FROM`/`JOIN` targets out of the
generated SQL and checks them against `list_tables()`. If a query names a
table that was never ingested, it's caught immediately and sent through the
existing one-shot `repair_sql()` loop with a precise, actionable error — the
same self-repair path already used for execution/zero-row failures, just
triggered one step earlier.

### 3.3 Document isolation & stale-data prevention
- `utils/doc_identity.py` computes a SHA-256 content hash per file and
  derives a stable `document_id`; a small on-disk ledger
  (`data/document_identity_ledger.json`) tracks a `doc_version` that only
  increments when a filename's content actually changes (a byte-identical
  re-upload stays at the same version and is flagged as a duplicate).
- `loaders/file_loader.py` stamps `document_id` / `content_hash` /
  `doc_version` onto every doc's metadata in one place (`load_files()`), so
  it flows automatically through the existing chunker → ChromaDB metadata
  pipeline and into the DuckDB registry — no other loader had to change.
- `IngestionService._clear_stale_data_for()` runs **before** every ingestion
  (both the batch `ingest()` and the cancellable `ingest_with_control()`
  paths): it deletes any existing ChromaDB chunks and DuckDB tables already
  registered under that filename. This is what actually fixes the duplicate-
  chunk bug — previously, re-uploading a file only ever *added* new chunks.
- `DuckDBManager`'s registry table gained `document_id` / `content_hash` /
  `doc_version` columns via `ADD COLUMN IF NOT EXISTS`, so **existing
  production databases upgrade automatically** on next connect — verified
  against a simulated pre-upgrade registry (see §4).

### 3.4 Answer verification (hallucination guard)
`core/answer_verifier.py` runs after every semantic/hybrid LLM answer: it
splits the answer into sentences and checks vocabulary overlap against the
actual retrieved evidence text. If a majority of substantive sentences share
no real overlap with anything retrieved, a visible caveat is appended (the
answer is never silently rewritten or withheld — it's flagged, not
suppressed). The raw verification result (`grounded_ratio`,
`unsupported_sentences`) is returned in the response payload for logging/UI
use and is `null`-safe for any caller that doesn't look at it.

### 3.5 Multi-page tables
`loaders/pdf_layout_parser.py::_merge_multipage_tables()` walks the flat
block list after per-page parsing and merges a table into the next page's
table when: the first table is the last block on its page, the second is the
first block on the very next page, and both have the same column count
(repeated headers are detected and dropped). Verified with a unit test
(3-row + 3-row tables across two pages → one 5-row logical table, header
deduplicated).

### 3.6 Structured logging
`QueryService.ask()` is now a thin timing/trace wrapper around the
unchanged `_ask_impl()` pipeline. Every query emits one JSON line to a
dedicated `trace` logger containing: question, routing decision, sources,
SQL, SQL row count, chunk count, confidence, verification result, answer
length, elapsed ms, and any error — independent of the existing prose log
lines, so it can be parsed/aggregated without touching normal logs.

### 3.7 Regression evaluation framework
`eval/regression_eval.py` runs a JSON list of test questions through the
**live** `QueryService` (real integration test, not mocked) and reports
routing accuracy, retrieval accuracy, SQL accuracy, hybrid-case count,
hallucination rate (from the new verifier), and p50/p95/max response time,
plus a `failures` list for anything that didn't match expectations.
`eval/test_cases.json` ships as a generic, fill-in-the-blanks template —
deliberately with no hardcoded assumptions about any specific document's
content, per the "no hardcoded business rules" requirement.

---

## 4. Verification Performed

- Every modified/added `.py` file compiles (`py_compile`) — full project swept, zero errors.
- `core/answer_verifier.py`: unit-tested grounded vs. hallucinated answers against sample evidence — correctly distinguished both.
- `utils/doc_identity.py`: unit-tested same-content re-ingest (version stays 1, flagged duplicate) vs. changed-content re-ingest (version increments, new `document_id`).
- `DuckDBManager.validate_sql_schema()`: tested against a real in-memory DuckDB table — correctly passes valid SQL, rejects both a nonexistent table and a bad JOIN target.
- Registry migration: simulated a **pre-upgrade** `_rag_table_registry` (without the new columns) and confirmed `DuckDBManager` connects and reads existing rows without error — no manual migration needed.
- `_merge_multipage_tables()`: unit-tested a table split across two pages (merges into one, drops repeated header) and a table followed by unrelated content on the same page (correctly left unmerged).
- `QueryRouter.route_with_evidence()`: confirmed it behaves identically to the original `route()` when no live stores are passed (full backward compatibility for any external caller still using the old signature).

## 5. What Was Deliberately Left Alone

Per the "do not redesign" instruction, the following mature subsystems were
reviewed and found already solid, so no changes were made: hybrid dense+BM25
retrieval and merge/rerank (`chroma_store.py`), the SQL generation/repair
loop and "top-per-group" deterministic shortcut, the context builder, the
two-level heading/section metadata hierarchy, and the categorical
ground-truth verification for tabular answers (`compute_categorical_summary`
— a different, already-existing verification mechanism specific to SQL
results, complementary to the new semantic/hybrid answer verifier).

## 6. Post-Delivery Fix: OCR Language-Code Mismatch (found via real-file test)

A real scanned/image-only PDF was tested end-to-end after delivery and failed
ingestion with `"no extractable content found in this file"` — despite
Tesseract being installed and working perfectly when called directly.

**Root cause:** `OCR_LANGUAGE` (default `"en"`) is one shared setting used
for both OCR backends, but the two libraries expect different language-code
standards:
- **EasyOCR** expects ISO 639-1 codes (`"en"`) — the default was correct for it.
- **Tesseract** expects ISO 639-2/3 codes matching its `.traineddata`
  filenames (`"eng"`, not `"en"`) — passing `"en"` makes pytesseract raise
  `Error opening data file .../en.traineddata`.

Because the OCR cascade's exception handling logged failures only at
`DEBUG` level, this misconfiguration was indistinguishable from "OCR
genuinely found no text" — it looked exactly like the page was blank. Any
deployment with only Tesseract installed (EasyOCR is heavier, needs a model
download, and is commonly skipped in offline/intranet setups per the
project's own requirements.txt comments) hits this on **every single**
scanned-page PDF.

**Fix (`ocr/ocr_engine.py`):**
- Added an ISO 639-1 → Tesseract language-code translation table, applied
  only to the Tesseract call path (EasyOCR keeps receiving the original
  code) — `"en"` now correctly becomes `"eng"` for Tesseract while EasyOCR
  is unaffected.
- The cascade now distinguishes "engine not installed" (`ModuleNotFoundError`
  — silent, expected) from "engine installed but errored" (logged at
  `WARNING` with the real exception message) — the exact class of bug that
  was previously invisible.
- `check_engines()` (used by the System Health panel) now actively verifies
  the *configured* language pack is installed via
  `pytesseract.get_languages()`, not just that the tesseract binary exists —
  it will now proactively flag this exact misconfiguration with the correct
  `apt install tesseract-ocr-eng`-style fix instead of reporting a
  misleadingly green "✅ available".

**Verified:** re-ran the full `loaders/file_loader.py` pipeline against the
actual failing 14-page scanned PDF — all 14 pages now extract correctly via
Tesseract OCR (confirmed real, readable text in the output, not placeholder
content).

### 6b. Second Fix: Mixed real-text + scanned PDFs silently dropped scanned pages

While confirming the fix above generalizes beyond the one uploaded file, a
second, related bug was found by testing a **mixed** PDF (page 1 real text,
page 2 a scanned/image-only page in the same document): page 2 was silently
dropped — zero output, no error, no OCR attempt — despite `_blocks_to_docs()`
containing a comment claiming it would OCR-fallback exactly this case.

**Root cause:** the loop that walks pages only ever iterated
`{b["page"] for b in blocks}` — i.e. pages the layout parser found at least
one text block on. A page that is *entirely* a scanned image produces zero
blocks, so it never appeared in that set, so the "page produced nothing at
all, try OCR" branch never actually ran for it. A **fully** scanned PDF
still worked correctly (zero blocks overall triggers the separate legacy
fallback path, which iterates every page unconditionally) — only a **mix**
of real-text and scanned pages in the same file was affected.

**Fix:** `_blocks_to_docs()` now also receives the PDF's true total page
count (via a cheap `pypdf` page-count check, no rendering) and iterates
every page in the document, not just the ones with detected blocks — so a
zero-block page anywhere in the file now correctly reaches the OCR fallback.

**Verified** with three independent test cases: the original fully-scanned
14-page PDF (14/14 pages, unaffected by this second fix), a standalone
synthetic scanned image (unrelated content, proving the fix isn't
file-specific), and a purpose-built 2-page mixed PDF (real text + scanned
image) — all three now extract correctly end-to-end.

### 6c. Third Fix: SQL schema validator false-positives on recursive CTEs and schema-qualified names

Stress-testing `validate_sql_schema()` (added in §3.2) against SQL patterns
beyond the original test cases turned up two more false positives that
would have broken otherwise-valid, working queries:

- `WITH RECURSIVE nums AS (...)` — the CTE-detection regex only matched
  `WITH name AS (`, not `WITH RECURSIVE name AS (`, so a recursive CTE's own
  name was misidentified as an unknown table.
- `SELECT * FROM main.employees` — a schema-qualified reference. The
  original regex captured `main` as the table name (stopping at the `.`)
  instead of `employees`, incorrectly flagging a perfectly valid query.

**Fix:** the CTE regex now optionally matches `RECURSIVE`, and the
FROM/JOIN regex now optionally consumes a `schema.` prefix before capturing
the actual table name. Verified against 8 cases (plain valid, unknown table,
CTE, recursive CTE, schema-qualified valid, schema-qualified unknown,
quoted schema-qualified, multi-CTE) — all now resolve correctly.

## 7. Suggested Next Steps (not implemented, out of current scope)

- Populate `eval/test_cases.json` with real questions/expected answers for
  your actual document set and wire `eval/regression_eval.py` into CI.
- Consider persisting `document_id`/`content_hash` on ChromaDB collection
  metadata queries (currently written on ingest, not yet used as a query
  filter) if true multi-tenant isolation (not just per-filename) is needed.
- Column-level SQL validation (beyond table-level) would need a real SQL
  parser (e.g. `sqlglot`) rather than regex — flagged in code comments as a
  deliberate scope boundary for this pass.
