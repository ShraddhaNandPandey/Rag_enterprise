# PDF Table-Extraction Upgrade — Deliverables

Audit target: layout-aware PDF parsing + table extraction, without breaking any
existing feature (FastAPI APIs, frontend, CSV/XLSX ingestion, DuckDB, ChromaDB,
BM25, Ollama, OCR). All changes below are **additive** — nothing existing was
removed, renamed, or given different behaviour when it doesn't involve a PDF
table.

---

## 1. Architecture diagram

### Before
```
CSV/XLSX ─────────────────────────────────► DuckDB
Text Documents ─► Chunker ─► Embeddings ──► ChromaDB
PDF ─► pypdf.extract_text() (flat text, tables lost) ─► Chunker ─► ChromaDB
Retriever (tabular | semantic, binary) ─► LLM (Ollama)
```

### After
```
CSV/XLSX ──────────────────────────────────────────────────────► DuckDB
                                                                     ▲
PDF ─► pdfplumber layout parser ─┬─► paragraphs/headings/lists/captions
      (falls back to plain       │        │
       pypdf text if unavailable)│        ▼
                                  │   Chunker (UNCHANGED) ─► Embeddings ─► ChromaDB
                                  │                                          ▲
                                  └─► tables (rows preserved) ─► DuckDB ─────┘
                                          │                        table
                                          └─► semantic summary ────┘
                                              ("Table Name / Columns / Rows")
                                              (embedded, NOT the raw rows)

Query Router: tabular | semantic | hybrid (NEW 3rd route)
   hybrid ─► SQL result (DuckDB) + semantic context (ChromaDB)
             merged into ONE prompt ─► LLM (Ollama)
```

---

## 2. Files added

| File | Purpose |
|---|---|
| `loaders/pdf_layout_parser.py` | pdfplumber-based block classifier: heading / paragraph / list / caption / footer / table. Returns `None` (triggering fallback) if pdfplumber is missing or the PDF can't be opened. |
| `core/table_summarizer.py` | Converts extracted table rows → pandas DataFrame (with numeric coercion for SQL aggregation) and builds the short semantic summary text that gets embedded. |
| `PDF_TABLE_UPGRADE.md` | This document. |

## 3. Files modified

| File | Change |
|---|---|
| `loaders/file_loader.py` | `_load_pdf()` now tries `pdf_layout_parser` first, converts blocks into docs via new `_blocks_to_docs()`, and falls back to the original logic (renamed `_load_pdf_legacy()`, byte-for-byte unchanged) if layout parsing is unavailable/fails/empty. Added `PDF_TABLE_MARKER` constant (same pattern as the existing `TABULAR_MARKER`). |
| `services/ingestion_service.py` | Splits loaded docs into **three** buckets instead of two: `tabular_docs` (CSV/XLSX, unchanged), `pdf_table_docs` (new), `text_docs` (unchanged). New `_ingest_pdf_tables()` method registers each PDF table into DuckDB via the existing `DuckDBManager.register_table()` and produces a summary doc that is merged into `text_docs` before calling the **unmodified** `_ingest_semantic()`/chunker. Both `ingest()` and `ingest_with_control()` (the background-job path) were updated identically. Result dict gained one new key, `pdf_tables_extracted` — purely additive. |
| `tools/query_router.py` | `route()` can now return `query_type: "hybrid"` when a question has a genuine positive signal for **both** tabular and semantic content (filename hints or keyword heuristics on both sides, or the LLM fallback answering "both"). If a question only ever matches one side — the overwhelming majority of questions — routing is byte-identical to before. Controlled by `ENABLE_HYBRID_ROUTING` (default on). |
| `services/query_service.py` | Added `_answer_hybrid()`, reusing the already-hardened `_answer_tabular()` and `_answer_semantic()` internally, then merging their outputs into one LLM prompt (PART 8). `ask()` gained one new `elif query_type == "hybrid"` branch; the existing `"tabular"`/`"semantic"` branches are untouched. |
| `config/settings.py` | Added `ENABLE_PDF_LAYOUT_PARSING`, `PDF_TABLE_MIN_ROWS`, `ENABLE_HYBRID_ROUTING`. Extended `ROUTER_SYSTEM_PROMPT` with a third `"both"` category (additive text only). |
| `requirements.txt` | Added `pdfplumber>=0.11.0` (pure Python, no native binaries, fully offline — same offline guarantee as the rest of the stack). |

## 4. Why each change was required

- **Layout-aware parsing (Part 1)**: `pypdf.extract_text()` has no concept of
  a table — cells become disconnected lines. pdfplumber exposes real
  geometric table detection (`find_tables()`), so tables can be pulled out
  *before* the remaining text is extracted, and classified separately from
  headings/paragraphs/lists/captions.
- **Reusing the existing chunker (Part 2)**: paragraph/heading/list text from
  a PDF is emitted in exactly the same `{"text": ..., "metadata": ...}` shape
  the old loader produced, so it flows through `core/chunker.py` completely
  unmodified.
- **Row/column preservation (Part 3)**: `rows_to_dataframe()` keeps the
  header row and every data row exactly as extracted — it never flattens a
  table into "Employee\nSalary\nDepartment\nAmit\n50000\nIT" lines.
- **One DuckDB engine for everything (Part 4)**: PDF tables call the exact
  same `DuckDBManager.register_table()` CSV/XLSX ingestion already uses, so
  SQL generation, the SQL repair loop, chart generation, and the Knowledge
  Base panel all pick up PDF-derived tables automatically — no special-casing
  needed anywhere downstream.
- **Summary-only embedding (Part 5/9)**: only a ~5-line "Table Name / Source /
  Columns / Rows / description" block is ever embedded — never the row data —
  so a 5-row table and a 5,000-row table cost ChromaDB the same amount of
  work. Exact values still come from DuckDB via SQL.
- **Richer metadata (Part 6)**: PDF text/table/summary docs now carry
  `heading`, `section`, `parent_section`, `block_type`, and (for tables/
  summaries) `duckdb_table` — on top of the pre-existing `source`,
  `source_name`, `type`, `page` fields, which are still present and
  unchanged for backward compatibility.
- **3-way router + hybrid context builder (Part 7/8)**: the router now
  detects when a question needs both pipelines and merges the DuckDB SQL
  result (row-limited, never a full table dump) with the ChromaDB semantic
  context into one LLM prompt for a single combined answer.
- **Never breaking existing behaviour (Part 10)**: every new code path has an
  explicit fallback to the prior behaviour (missing pdfplumber → plain text;
  layout parser errors on a page → skipped, not fatal; empty layout-parse
  result → legacy loader; hybrid routing disabled → binary routing).

## 5. New dependency

- `pdfplumber>=0.11.0` — pure Python (built on `pdfminer.six`), no native
  binaries or network calls at runtime. Fully compatible with the offline/
  intranet requirement. If it can't be installed for any reason, the system
  keeps working exactly as it did before this change (plain-text PDF
  extraction, no PDF table support) — it does not fail startup or ingestion.

## 6. Updated ingestion flow

```
load_files(paths)
 ├─ CSV/XLSX      → TABULAR_MARKER doc          (unchanged)
 ├─ PDF           → layout_parse_pdf()
 │                   ├─ table blocks  → PDF_TABLE_MARKER docs (NEW)
 │                   └─ text blocks   → per-page text doc      (same shape as before)
 ├─ DOCX/PPTX/TXT/MD/images → text docs          (unchanged)
 ▼
ingestion_service.ingest()
 ├─ tabular_docs      → DuckDBManager.load_csv/load_excel      (unchanged)
 ├─ pdf_table_docs     → DuckDBManager.register_table (NEW)   ─┐
 │                        + build_table_summary()  (NEW)      ─┤ merged in
 └─ text_docs (+ pdf table summaries) → chunk_documents()      │ before chunking
                                        → VectorStore.add_chunks (unchanged)
```

## 7. Updated retrieval flow

```
QueryService.ask(question)
 └─ QueryRouter.route(question) → "tabular" | "semantic" | "hybrid" (NEW)
      "tabular"  → _answer_tabular()   (unchanged)
      "semantic" → _answer_semantic()  (unchanged)
      "hybrid"   → _answer_hybrid()    (NEW: runs both, merges into one prompt)
```

## 8. Updated router logic

- Filename hints: if the question names both a tabular-source file and a
  semantic-source file → `hybrid`.
- Keyword heuristics: if the question scores > 0 on both the tabular keyword
  list and the semantic keyword list → `hybrid`.
- LLM fallback: `ROUTER_SYSTEM_PROMPT` now offers a third `"both"` answer.
- Any question that only ever matches one side routes exactly as it did
  before this change (no behaviour change for the common case).

## 9. Migration notes

- **No data migration needed.** Existing ChromaDB collections and DuckDB
  tables are untouched; new tables/chunks are only created on the *next*
  ingestion of a PDF that contains a table.
- **Re-ingest existing PDFs** (delete + re-upload) if you want their tables
  extracted retroactively — previously-ingested PDFs keep working exactly as
  before (flat text) until re-ingested.
- **Feature flags** (all default to the improved/new behaviour, can be
  reverted without a code change via `.env`):
  - `ENABLE_PDF_LAYOUT_PARSING=false` → restore the exact pre-audit PDF
    ingestion behaviour.
  - `ENABLE_HYBRID_ROUTING=false` → restore strict binary tabular/semantic
    routing.
  - `PDF_TABLE_MIN_ROWS` (default `2`) → tune how many data rows a detected
    grid needs before it's treated as a real table vs. folded back into text.
- **Install** the one new dependency: `pip install pdfplumber` (already
  added to `requirements.txt`).
- **Known heuristic limitation**: heading/section detection is a lightweight
  regex/geometry heuristic, not a layout ML model — it works well for
  documents with clear heading formatting (short lines, no trailing
  punctuation, title case/ALL CAPS) but may miss unusually styled headings.
  This only affects the `heading`/`section` *metadata* fields, never table
  row/column data itself, and never causes content to be dropped (Part 10's
  "nothing silently lost" guarantee is enforced independently of heading
  detection quality).

## 10. Phase 2 — Improved heading/section detection

Phase 1's heading detection was text-only (line length, ending punctuation,
casing/regex) and force-ordered all text blocks before tables on a page
regardless of true position — noted as a known limitation in section 9.

Phase 2 (`loaders/pdf_layout_parser.py`) replaces this with a font-aware,
positionally-accurate approach:

- **Font-size baseline per page**: estimates the page's body-text font size
  (the size covering the most characters), via pdfplumber's character-level
  `size`/`fontname` data.
- **Two heading levels, detected by real typography**:
  - Level 1 ("section") — font size ≥ 1.35× body size (e.g. a page title).
  - Level 2 ("heading") — font size ≥ 1.12× body size, OR same-size-but-bold
    and short (e.g. a sub-heading like "Salary Structure").
- **True top-to-bottom ordering**: text lines and tables are now merged and
  sorted by actual vertical position on the page, instead of Phase 1's
  "all text before all tables" approximation — so a table's nearest
  preceding heading is a genuine position match.
- **Two-level metadata hierarchy**, matching PART 6's original example
  exactly (`"section": "Payroll", "heading": "Salary Structure"`):
  - `section` — nearest level-1 heading seen so far.
  - `heading` — nearest heading at *any* level (most specific).
  - `parent_section` — the enclosing level-1 section for a level-2 heading
    (empty for a level-1 heading itself).
- **Layered fallback, nothing lost**: the Phase 1 text-only heuristics
  (`_is_heading_line` / `_classify_text_block`) are kept as a second pass —
  used whenever a line has no usable font signal (e.g. numbered headings
  rendered at body size), and as the sole classifier on the rare page with
  no extractable character metadata at all. `build_table_summary()` was
  updated to surface both `heading` and `section` when they differ.

**Verified**: a synthetic multi-section PDF (20pt title → paragraph → 14pt
bold sub-heading → table → another 14pt bold sub-heading) was parsed with
100% correct level assignment and true positional ordering. Re-running the
Phase 1 test PDF (weaker/no blank-line separation between heading and body)
now *also* correctly detects "Salary Structure" as its own heading — a case
Phase 1 had documented as a known limitation. All existing regression tests
(fallback paths, ingestion pipeline, DuckDB SQL, CSV/XLSX coexistence) were
re-run and still pass.

## 11. Verification performed

All of the following were run directly against the modified code (see test
commands used during development):

- ✅ Full project `py_compile` across every `.py` file — no syntax errors.
- ✅ Full FastAPI app import (`api.app`) — all 8 routers mount, no breakage.
- ✅ Layout parser on a synthetic PDF with heading + paragraph + table: table
  rows/columns preserved exactly; heading correctly attached to the table as
  its section.
- ✅ Fallback path (pdfplumber import simulated as missing) reproduces the
  original plain-text extraction output shape exactly.
- ✅ `rows_to_dataframe()` + DuckDB `register_table()` + `execute_query()`:
  ran a real `GROUP BY`/`SUM` SQL query against a PDF-extracted table.
- ✅ Full `IngestionService.ingest()` run (with a stubbed embedding call, no
  live Ollama needed): produced the correct chunk count (paragraph + one
  table summary — never raw rows), correct DuckDB table, correct stats dict.
- ✅ CSV and PDF-with-table ingested together in the same call: both land in
  the same DuckDB instance under independent table names, no interference.
- ✅ `get_knowledge_base()` and `delete_document()` (pre-existing, unmodified
  methods) correctly report/clean up PDF-derived tables — because they were
  already engine-agnostic, zero changes were needed there.
- ✅ 3-way router: verified `hybrid` routing fires on genuine dual-signal
  questions and single-signal questions still route exactly as before.
