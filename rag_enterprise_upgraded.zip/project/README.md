# Enterprise RAG Agent v2.0

Fully offline, intranet-grade AI document assistant built on local LLMs (Ollama), ChromaDB, and DuckDB.

## Architecture

```
User Question
     │
     ▼
 Intent Router  ──── keyword heuristics + LLM classifier
     │
     ├── Semantic (PDF/DOCX/PPTX/TXT/Images)
     │       │
     │       ├── ChromaDB vector search
     │       ├── BM25 keyword search
     │       ├── RRF fusion
     │       ├── CrossEncoder reranker
     │       └── Ollama LLM → Answer
     │
     └── Tabular (CSV / Excel)
             │
             ├── DuckDB SQL generation
             ├── SQL validation (SELECT only)
             ├── Query execution
             └── Ollama LLM → Answer with exact numbers
```

## Directory Structure

```
rag_enterprise/
├── config/
│   └── settings.py          # All configuration (env-overridable)
├── api/
│   ├── app.py               # FastAPI application, middleware, routers
│   └── dependencies.py      # Singleton service instances
├── routers/
│   ├── ingest_router.py     # POST /ingest/upload, DELETE /ingest/source
│   ├── query_router_api.py  # POST /query/ask, POST /query/chat
│   ├── data_router.py       # GET /data/tables
│   └── memory_router.py     # GET/POST /memory/sessions
├── services/
│   ├── ingestion_service.py # Orchestrates text→ChromaDB / tabular→DuckDB
│   └── query_service.py     # Routes, retrieves, generates answers
├── database/
│   └── duckdb_manager.py    # CSV/Excel → DuckDB (accurate SQL math)
├── vectorstore/
│   └── chroma_store.py      # ChromaDB + BM25 + RRF + CrossEncoder reranker
├── ocr/
│   └── ocr_engine.py        # EasyOCR primary, Tesseract fallback
├── loaders/
│   └── file_loader.py       # Universal loader: PDF/DOCX/PPTX/TXT/CSV/Excel/Images
├── core/
│   └── chunker.py           # Recursive chunking (800 tokens, 100 overlap)
├── tools/
│   ├── query_router.py      # Intent classification (semantic vs tabular)
│   └── sql_generator.py     # NL → DuckDB SQL generation + validation
├── memory/
│   └── conversation_memory.py  # SQLite multi-session conversation history
├── models/
│   └── schemas.py           # Pydantic request/response models
├── utils/
│   └── logger.py            # RotatingFileHandler logging per subsystem
├── logs/                    # Auto-created log files (git-ignored)
├── data/                    # Auto-created DuckDB + SQLite databases (git-ignored)
├── chroma_db/               # Auto-created ChromaDB persistent storage (git-ignored)
├── uploads/, temp/          # Auto-created runtime scratch space (git-ignored)
├── .env.example             # Template — copy to .env and edit locally
├── requirements.txt
└── main.py                  # Entry point
```

> `logs/`, `data/`, `chroma_db/`, `uploads/`, and `temp/` are created
> automatically on first run (see `config/settings.py`) and are excluded
> from version control via `.gitignore` — they hold machine-local runtime
> state, not source code.

## Quick Start (fresh machine, no Docker)

### 1. Clone and configure environment
```bash
git clone <your-repo-url>
cd rag_enterprise
cp .env.example .env
# Edit .env if you need non-default ports, models, or storage paths.
# All values are optional — sensible defaults are used if a variable is unset.
```

### 2. System dependencies
```bash
# Ubuntu/Debian
sudo apt-get install -y tesseract-ocr poppler-utils libgl1 fonts-dejavu-core espeak-ng
```
`fonts-dejavu-core` gives the PDF export ("Download" button) full Unicode
text support — without it, PDF export still works but falls back to
Helvetica/Courier (Latin-1 only). `espeak-ng` is required by the Read Aloud
feature's pyttsx3 fallback engine on Linux (skip it if you're only using a
Piper voice model).

### 3. Install Ollama and pull models
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.2
ollama pull nomic-embed-text
# Optional: better SQL generation
ollama pull qwen
```

### 4. Python environment
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 5. Run
```bash
python main.py
# or
uvicorn main:app --host 0.0.0.0 --port 8000
```
On first startup the app automatically creates any runtime directories it
needs (`logs/`, `uploads/`, `temp/`, `data/`, `chroma_db/`) and initializes
the ChromaDB, DuckDB, and SQLite storage — nothing needs to be created
manually, and none of these runtime files are tracked in Git.

### 6. Open the web UI
Open: http://localhost:8000  (or `http://<server-ip>:8000` from any intranet
machine). This is the full enterprise UI — chat, knowledge base, data
sources, model management, sessions, and system health — served directly
by the FastAPI app, no separate UI process required.

### 7. API docs
Open: http://localhost:8000/docs

## Quick Start (Docker)

The project ships with a `Dockerfile` and `docker-compose.yml` that run the
app alongside an Ollama container.

```bash
git clone <your-repo-url>
cd rag_enterprise
cp .env.example .env   # optional — docker-compose sets its own defaults too

docker compose up --build -d

# Pull the models into the Ollama container once it's healthy
docker exec -it ollama ollama pull llama3.2
docker exec -it ollama ollama pull nomic-embed-text
```

Then open http://localhost:8000. Persistent data (`chroma_db`, DuckDB,
SQLite) is stored in the `rag_data` Docker volume and logs in `rag_logs`,
so nothing is lost across container restarts and nothing is written into
the repository itself.

To stop the stack: `docker compose down` (add `-v` to also remove the
persisted volumes and start fresh).

### Fully air-gapped / no-internet intranet

This app makes **no outbound calls to the public internet at runtime** —
the FastAPI app, the frontend, and Ollama all talk to each other over the
local machine or intranet network only. Internet access is only needed
once, to prepare the environment:

- **Docker image**: `docker compose up --build` needs internet the first
  time (to pull `python:3.11-slim`, `ollama/ollama:latest`, and pip/apt
  packages). On a fully air-gapped intranet, build the image (and
  `docker pull ollama/ollama:latest`) on a machine with internet access,
  then `docker save`/`docker load` (or push to an internal registry) to
  get it onto the intranet host.
- **Ollama models**: pull them on a machine with internet access
  (`ollama pull llama3.2`, `ollama pull nomic-embed-text`, etc.), then copy
  `~/.ollama` to the intranet host and run `ollama serve` there.
- **TrOCR (if used for OCR)**: copy `~/.cache/huggingface` from an
  internet-connected machine and set `TRANSFORMERS_OFFLINE=1`.

## Environment Variables (all optional)

Copy `.env.example` to `.env` and adjust as needed — every variable has a
built-in default, so the app runs even with an empty or missing `.env`.

| Variable          | Default               | Description                      |
|-------------------|-----------------------|----------------------------------|
| OLLAMA_BASE_URL   | http://localhost:11434 | Ollama server URL               |
| LLM_MODEL         | llama3.2              | Chat model                       |
| EMBED_MODEL       | nomic-embed-text      | Embedding model                  |
| CHROMA_PATH       | ./chroma_db           | ChromaDB storage path            |
| DUCKDB_PATH       | ./data/tabular.duckdb | DuckDB file path                 |
| SQLITE_PATH       | ./data/memory.db      | Conversation memory path         |
| CHUNK_SIZE        | 800                   | Tokens per chunk                 |
| CHUNK_OVERLAP     | 100                   | Overlap tokens                   |
| TOP_K             | 5                     | Retrieval top-K                  |
| CONFIDENCE_THRESHOLD | 0.5                | Min confidence before warning    |
| ORG_NAME          | Enterprise Organization | Org name shown in exported PDF header/footer |
| PDF_FONTS_DIR     | ./assets/fonts        | Bundled offline TTF fonts for PDF export (optional — auto-detects system fonts otherwise) |

**Note:** `.env` is git-ignored and must never be committed. `.env.example`
is the template that ships with the repo — copy it to `.env` and edit the
copy locally rather than editing `.env.example` directly.

## Key API Endpoints

### Ingest
```
POST /ingest/upload          Upload files (multipart)
GET  /ingest/stats           Ingestion statistics
DELETE /ingest/source/{name} Remove source from ChromaDB
DELETE /ingest/table/{name}  Remove table from DuckDB
POST /ingest/reset           ⚠️ Reset all data
```

### Query
```
POST /query/ask              Ask a question (auto-routes)
POST /query/chat             Multi-turn chat with session
POST /query/sql/preview      Preview generated SQL
POST /query/sql/execute      Execute raw SQL SELECT
```

### Data
```
GET /data/tables             List DuckDB tables
GET /data/tables/{name}      Table metadata
GET /data/tables/{name}/preview  Preview rows
GET /data/sources            List ChromaDB sources
```

### Memory
```
POST   /memory/sessions                  Create session
GET    /memory/sessions                  List sessions
GET    /memory/sessions/{id}/history     Get chat history
DELETE /memory/sessions/{id}             Delete session
POST   /memory/sessions/{id}/clear       Clear messages
```

### System
```
GET /health    System health check
GET /          API overview
```

### Export
```
POST /export/pdf             Render a Q&A turn as a downloadable PDF report (offline)
```

## Example Requests

### Upload files
```bash
curl -X POST http://localhost:8000/ingest/upload \
  -F "files=@employee_handbook.pdf" \
  -F "files=@salaries.xlsx"
```

### Ask a document question (semantic)
```bash
curl -X POST http://localhost:8000/query/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "What is the leave policy?"}'
```

### Ask a tabular question (DuckDB SQL)
```bash
curl -X POST http://localhost:8000/query/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "What is the total salary for the Engineering department?"}'
```

### Multi-turn chat
```bash
# First turn
curl -X POST http://localhost:8000/query/chat \
  -H "Content-Type: application/json" \
  -d '{"question": "Who is the highest paid employee?", "session_id": "sess_001"}'

# Follow-up
curl -X POST http://localhost:8000/query/chat \
  -H "Content-Type: application/json" \
  -d '{"question": "What department are they in?", "session_id": "sess_001"}'
```

## Supported File Types

| Type          | Extension           | Pipeline           |
|---------------|---------------------|--------------------|
| PDF (digital) | .pdf                | pypdf → ChromaDB   |
| PDF (scanned) | .pdf                | EasyOCR → ChromaDB |
| Word          | .docx               | python-docx → ChromaDB |
| PowerPoint    | .pptx               | python-pptx → ChromaDB |
| Text/Markdown | .txt, .md           | Direct → ChromaDB  |
| Images        | .jpg, .png, .tiff   | EasyOCR → ChromaDB |
| CSV           | .csv                | pandas → DuckDB    |
| Excel         | .xlsx, .xlsm        | pandas → DuckDB (per sheet) |

## Why This Architecture Prevents Hallucination

**Old (wrong) approach:**
```
Excel → convert to text → embed → ChromaDB → LLM "calculates" → WRONG NUMBERS
```

**New (correct) approach:**
```
Excel → DuckDB → SQL → exact numbers → LLM explains → CORRECT NUMBERS
```

Mathematical operations (SUM, AVG, COUNT, MAX, MIN, GROUP BY) are performed
by DuckDB's SQL engine — not estimated by the LLM — guaranteeing accuracy.

## Offline Token Counting (tiktoken)

Chunking uses tiktoken for exact token counts, but tiktoken ships no encoding
files — by default it fetches `cl100k_base.tiktoken` from the internet the
first time it runs, with no request timeout, which would hang indefinitely
on an air-gapped host. This app never lets that happen: `core/chunker.py`
checks whether the encoding is already present in `TIKTOKEN_CACHE_DIR`
*before* ever calling into tiktoken. If it's missing, chunking instantly
falls back to word-count-based sizing instead — no network call is ever
attempted, whether or not the cache has been set up.

To get exact token counts on an air-gapped host instead of the word-count
estimate, pre-download the encoding once on an internet-connected machine:
```
TIKTOKEN_CACHE_DIR=./data/tiktoken_cache python -c "import tiktoken; tiktoken.get_encoding('cl100k_base')"
```
then copy that `data/tiktoken_cache/` directory onto the intranet host and
set `TIKTOKEN_CACHE_DIR` to match (see `.env.example`).

## Read Aloud (Offline Text-to-Speech)

Every AI response in the chat UI has a speaker icon that reads it aloud —
fully offline, safe for a defence intranet with no internet access.

- **Engines**: [Piper](https://github.com/rhasspy/piper) (preferred, natural-sounding,
  requires a downloaded `.onnx` voice model) with automatic fallback to
  `pyttsx3` (system TTS — espeak-ng/SAPI5/NSSpeech), so Read Aloud works out
  of the box even before a Piper voice is installed. Set `TTS_ENGINE` in
  `.env` to force one or the other.
- **Setup**: `pip install -r requirements.txt` installs both. On Linux also
  `apt install espeak-ng` for the pyttsx3 fallback. For Piper, download a
  voice (e.g. `en_US-arctic-medium`) and point `PIPER_MODEL_PATH` at the
  `.onnx` file (its matching `.onnx.json` must sit alongside it).
- **API**: `POST /api/tts` (`{"text": "..."}` → WAV audio), `GET /api/tts/status`,
  `DELETE /api/tts/cache`. New and additive — no existing endpoint changed.
- **Behavior**: only one message plays at a time; long responses are chunked
  sentence-by-sentence server-side and merged into one continuous WAV;
  identical text reuses cached audio (both a local disk cache and an
  in-browser cache) instead of regenerating it; playback speed (0.75×–1.5×),
  volume, scrubbing, pause/resume/stop/replay are all available from the
  player bar. Nothing here touches the RAG pipeline, Ollama, ChromaDB,
  DuckDB, sessions, or any existing API/JS/business logic — see
  `services/tts_service.py`, `routers/tts_router.py`, `static/js/tts.js`,
  and `static/css/tts.css`.
