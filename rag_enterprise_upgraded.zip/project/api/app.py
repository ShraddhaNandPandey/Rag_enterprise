"""api/app.py — FastAPI Application"""

import asyncio
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Callable

# Block internet calls at app level
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("ANONYMIZED_TELEMETRY", "False")
os.environ.setdefault("CHROMA_TELEMETRY", "False")

from pathlib import Path as _Path

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from config.settings import API_TITLE, API_VERSION, ALLOWED_ORIGINS
from utils.logger import setup_logging, get_logger

setup_logging()
logger = get_logger("api")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Starting {API_TITLE} v{API_VERSION}")
    try:
        from api.dependencies import (
            get_vector_store, get_duckdb_manager,
            get_ingestion_service, get_query_service,
            get_memory, get_model_service, get_tts_service,
        )
        get_vector_store()
        get_duckdb_manager()
        get_ingestion_service()
        get_query_service()
        get_memory()
        get_model_service()
        try:
            tts = get_tts_service()
            logger.info(f"TTS (Read Aloud) engine: {tts.engine_name} (available={tts.is_available})")
        except Exception as e:
            # Read Aloud is a non-critical add-on; never let it block startup
            # or the rest of the RAG platform.
            logger.warning(f"TTS service could not initialize (Read Aloud disabled): {e}")
        logger.info("All services initialized successfully")
    except Exception as e:
        logger.error(f"Startup initialization error: {e}", exc_info=True)
    yield
    logger.info("Shutting down")
    try:
        from api.dependencies import _duckdb_manager
        if _duckdb_manager:
            _duckdb_manager.close()
    except Exception:
        pass


app = FastAPI(
    title=API_TITLE,
    version=API_VERSION,
    description="Enterprise RAG Agent — Fully Offline / Intranet",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS: the UI is served from this same app by default, so no cross-origin
# access is needed and the middleware is skipped entirely in that case.
# If ALLOWED_ORIGINS is set (see config/settings.py), only those exact
# intranet origins are permitted — never a "*" wildcard, since that combined
# with credentials is both rejected by browsers and unsafe on an internal network.
if ALLOWED_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )


@app.middleware("http")
async def log_requests(request: Request, call_next: Callable) -> Response:
    rid   = str(uuid.uuid4())[:8]
    start = time.time()
    logger.info(f"[{rid}] {request.method} {request.url.path}")
    try:
        response = await call_next(request)
    except Exception as e:
        logger.error(f"[{rid}] Error: {e}", exc_info=True)
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})
    elapsed = round((time.time() - start) * 1000, 1)
    logger.info(f"[{rid}] {response.status_code} ({elapsed}ms)")
    response.headers["X-Request-ID"] = rid
    return response


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled: {exc}", exc_info=True)
    return JSONResponse(status_code=500, content={"detail": str(exc)})


# Routers
from routers.ingest_router import router as ingest_router
from routers.query_router_api import router as query_router
from routers.data_router import router as data_router
from routers.memory_router import router as memory_router
from routers.model_router import router as model_router
from routers.tts_router import router as tts_router
from routers.export_router import router as export_router
from routers.preview_router import router as preview_router  # NEW: Document Preview (read-only, additive)

app.include_router(ingest_router)
app.include_router(query_router)
app.include_router(data_router)
app.include_router(memory_router)
app.include_router(model_router)
app.include_router(tts_router)
app.include_router(export_router)
app.include_router(preview_router)


@app.get("/health", tags=["System"])
async def health_check():
    from api.dependencies import get_query_service, get_vector_store, get_duckdb_manager
    try:
        service   = get_query_service()
        vs        = get_vector_store()
        db        = get_duckdb_manager()
        # check_ollama() does a blocking network call (urllib, up to a 5s
        # timeout) — run it in a worker thread so a slow/unreachable Ollama
        # doesn't stall every other request (chat, polling, etc.) for the
        # duration of the check.
        ollama_ok = await asyncio.get_running_loop().run_in_executor(None, service.check_ollama)
        vs_count  = vs.collection.count()
        tables    = len(db.list_tables())
    except Exception as e:
        return {"status": "error", "error": str(e), "ollama": False,
                "vector_store_docs": 0, "tabular_tables": 0, "version": API_VERSION}
    return {
        "status":            "healthy" if ollama_ok else "degraded",
        "ollama":            ollama_ok,
        "vector_store_docs": vs_count,
        "tabular_tables":    tables,
        "version":           API_VERSION,
    }


@app.get("/api/info", tags=["System"])
async def api_info():
    return {
        "name": API_TITLE, "version": API_VERSION,
        "docs": "/docs", "health": "/health",
        "endpoints": {
            "upload": "POST /ingest/upload",
            "ask":    "POST /query/ask",
            "chat":   "POST /query/chat",
            "tables": "GET  /data/tables",
            "stats":  "GET  /ingest/stats",
            "tts":    "POST /api/tts",
            "tts_status": "GET /api/tts/status",
            "export_pdf": "POST /export/pdf",
            "preview_meta": "GET /preview/{doc_name}/meta",
        }
    }


# ─── Web UI ────────────────────────────────────────────────────────────────
# Serves the enterprise intranet UI (static/index.html, css, js) at "/".
# Mounted LAST so it never shadows the API routes registered above —
# Starlette matches routes in registration order, and the explicit
# /health, /docs, /ingest/*, /query/*, /data/*, /memory/*, /models/*
# routes are already registered by the time this catch-all mount is added.
_STATIC_DIR = _Path(__file__).resolve().parent.parent / "static"
if _STATIC_DIR.exists():
    app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="ui")
else:
    @app.get("/", tags=["System"])
    async def root():
        return {"message": "Static UI not found. See /docs for the API.", "docs": "/docs"}
