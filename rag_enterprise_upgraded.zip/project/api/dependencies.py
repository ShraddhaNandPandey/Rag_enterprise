"""api/dependencies.py — Singleton service instances"""

from pathlib import Path

_vector_store      = None
_duckdb_manager    = None
_ingestion_service = None
_query_service     = None
_memory            = None
_model_service     = None
_tts_service       = None


def get_vector_store():
    global _vector_store
    if _vector_store is None:
        from vectorstore.chroma_store import VectorStore
        _vector_store = VectorStore()
    return _vector_store


def get_duckdb_manager():
    global _duckdb_manager
    if _duckdb_manager is None:
        from database.duckdb_manager import DuckDBManager
        _duckdb_manager = DuckDBManager()
    return _duckdb_manager


def get_ingestion_service():
    global _ingestion_service
    if _ingestion_service is None:
        from services.ingestion_service import IngestionService
        _ingestion_service = IngestionService(
            vector_store=get_vector_store(),
            duckdb_manager=get_duckdb_manager(),
        )
    return _ingestion_service


def get_query_service():
    global _query_service
    if _query_service is None:
        from services.query_service import QueryService
        _query_service = QueryService(
            vector_store=get_vector_store(),
            duckdb_manager=get_duckdb_manager(),
        )
    return _query_service


def get_model_service():
    """
    Singleton ModelService.
    Shares current_llm state with the QueryService instance so that
    switch_model() mutates both in one call.
    """
    global _model_service
    if _model_service is None:
        from services.model_service import ModelService
        from config.settings import OLLAMA_BASE_URL, LLM_MODEL, EMBED_MODEL
        _model_service = ModelService(
            ollama_url=OLLAMA_BASE_URL,
            current_llm=LLM_MODEL,
            current_embed=EMBED_MODEL,
        )
    return _model_service


def get_memory():
    global _memory
    if _memory is None:
        from memory.conversation_memory import ConversationMemory
        _memory = ConversationMemory()
    return _memory


def get_tts_service():
    """
    Singleton TTSService (Read Aloud). Fully independent of the RAG pipeline —
    if engine initialization fails (no Piper model / no pyttsx3 voices), the
    service still returns, just with is_available == False, so the rest of
    the app (and the health check) never crashes because of it.
    """
    global _tts_service
    if _tts_service is None:
        from services.tts_service import TTSService
        from config.settings import (
            TTS_ENGINE, PIPER_MODEL_PATH, PIPER_CONFIG_PATH, PIPER_USE_CUDA,
            PYTTSX3_VOICE_ID, PYTTSX3_RATE, TTS_MAX_CHARS_PER_CHUNK,
            TTS_MAX_INPUT_CHARS, TTS_CACHE_DIR, TTS_CACHE_ENABLED,
            TTS_CACHE_MAX_MB, TTS_CACHE_TTL_HOURS, TEMP_DIR,
        )
        _tts_service = TTSService(
            engine_mode=TTS_ENGINE,
            piper_model_path=PIPER_MODEL_PATH,
            piper_config_path=PIPER_CONFIG_PATH,
            piper_use_cuda=PIPER_USE_CUDA,
            pyttsx3_voice_id=PYTTSX3_VOICE_ID,
            pyttsx3_rate=PYTTSX3_RATE,
            max_chars_per_chunk=TTS_MAX_CHARS_PER_CHUNK,
            max_input_chars=TTS_MAX_INPUT_CHARS,
            cache_dir=TTS_CACHE_DIR,
            cache_enabled=TTS_CACHE_ENABLED,
            cache_max_mb=TTS_CACHE_MAX_MB,
            cache_ttl_hours=TTS_CACHE_TTL_HOURS,
            temp_dir=str(Path(TEMP_DIR) / "tts_work"),
        )
    return _tts_service
