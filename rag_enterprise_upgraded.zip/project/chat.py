"""
chat.py — Interactive CLI chat client for the RAG Agent API

Usage:
    python chat.py                          # connects to http://localhost:8000
    python chat.py --url http://host:8000
    python chat.py --session my-session-1
"""

import argparse
import json
import sys
import urllib.request
import urllib.error
import uuid

DEFAULT_URL = "http://localhost:8000"


def print_banner(url: str, session_id: str):
    print("\n" + "="*60)
    print("  Enterprise RAG Agent — Interactive Chat")
    print("="*60)
    print(f"  API:     {url}")
    print(f"  Session: {session_id}")
    print("  Commands: 'quit' to exit | 'clear' to reset session")
    print("            'history' to show chat history")
    print("            'tables' to list loaded tabular data")
    print("            'sources' to list loaded documents")
    print("="*60 + "\n")


def api_call(url: str, path: str, payload: dict) -> dict:
    data = json.dumps(payload).encode()
    req  = urllib.request.Request(
        f"{url}{path}",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read())


def api_get(url: str, path: str) -> dict:
    req = urllib.request.Request(f"{url}{path}", method="GET")
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def check_health(url: str) -> bool:
    try:
        result = api_get(url, "/health")
        ollama_ok = result.get("ollama", False)
        docs      = result.get("vector_store_docs", 0)
        tables    = result.get("tabular_tables", 0)
        status    = result.get("status", "unknown")
        print(f"[Health] status={status} | ollama={ollama_ok} | docs={docs} | tables={tables}")
        if not ollama_ok:
            print("[WARN] Ollama is not running. Start it with: ollama serve")
        return True
    except Exception as e:
        print(f"[ERROR] Cannot connect to RAG Agent at {url}: {e}")
        print("        Make sure the server is running: python main.py")
        return False


def show_history(url: str, session_id: str):
    try:
        result = api_get(url, f"/memory/sessions/{session_id}/history")
        messages = result.get("messages", [])
        if not messages:
            print("[No history yet]")
            return
        print(f"\n--- History ({len(messages)} messages) ---")
        for msg in messages:
            role = msg["role"].upper()
            content = msg["content"][:200] + "..." if len(msg["content"]) > 200 else msg["content"]
            print(f"[{role}] {content}")
        print("---\n")
    except Exception as e:
        print(f"[ERROR] Could not fetch history: {e}")


def show_tables(url: str):
    try:
        result = api_get(url, "/data/tables")
        tables = result.get("tables", [])
        if not tables:
            print("[No tabular data loaded. Upload CSV or Excel files.]")
        else:
            print(f"\n--- Tabular Tables ({len(tables)}) ---")
            for t in tables:
                print(f"  • {t}")
            print()
    except Exception as e:
        print(f"[ERROR] Could not fetch tables: {e}")


def show_sources(url: str):
    try:
        result = api_get(url, "/data/sources")
        sources = result.get("sources", [])
        if not sources:
            print("[No documents loaded. Upload PDF/DOCX/TXT files.]")
        else:
            print(f"\n--- Document Sources ({len(sources)}) ---")
            for s in sources:
                print(f"  • {s}")
            print()
    except Exception as e:
        print(f"[ERROR] Could not fetch sources: {e}")


def clear_session(url: str, session_id: str):
    try:
        req = urllib.request.Request(
            f"{url}/memory/sessions/{session_id}/clear",
            data=b"{}",
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
        print(f"[Session cleared: {result.get('cleared', 0)} messages removed]\n")
    except Exception as e:
        print(f"[ERROR] Could not clear session: {e}")


def ask(url: str, session_id: str, question: str) -> None:
    try:
        result = api_call(url, "/query/chat", {
            "question": question,
            "session_id": session_id,
        })

        answer      = result.get("answer", "No answer")
        query_type  = result.get("query_type", "?")
        confidence  = result.get("confidence", 0.0)
        sources     = result.get("sources", [])
        sql         = result.get("sql")
        low_conf    = result.get("low_confidence_warning", False)

        # Print answer
        print(f"\n[{query_type.upper()} | confidence: {confidence:.2f}]")
        if low_conf:
            print("[⚠ Low confidence — answer may be incomplete]")
        print(f"\n{answer}\n")

        # Show SQL if tabular
        if sql:
            print(f"[SQL] {sql}")

        # Show sources
        if sources:
            print(f"[Sources] {' | '.join(sources)}")

        print()

    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"[ERROR {e.code}] {body}\n")
    except urllib.error.URLError as e:
        print(f"[ERROR] Cannot reach server: {e}\n")
    except Exception as e:
        print(f"[ERROR] {e}\n")


def main():
    parser = argparse.ArgumentParser(description="RAG Agent CLI Chat")
    parser.add_argument("--url",     default=DEFAULT_URL, help="API base URL")
    parser.add_argument("--session", default=None,        help="Session ID (auto-generated if not set)")
    args = parser.parse_args()

    url        = args.url.rstrip("/")
    session_id = args.session or f"cli-{uuid.uuid4().hex[:8]}"

    print_banner(url, session_id)

    if not check_health(url):
        sys.exit(1)

    print("Type your question and press Enter. Type 'quit' to exit.\n")

    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[Goodbye]")
            break

        if not question:
            continue

        cmd = question.lower()
        if cmd in ("quit", "exit", "q"):
            print("[Goodbye]")
            break
        elif cmd == "clear":
            clear_session(url, session_id)
        elif cmd == "history":
            show_history(url, session_id)
        elif cmd == "tables":
            show_tables(url)
        elif cmd == "sources":
            show_sources(url)
        elif cmd.startswith("help"):
            print("\nCommands:")
            print("  quit/exit  — exit the chat")
            print("  clear      — clear conversation history")
            print("  history    — show chat history")
            print("  tables     — list loaded CSV/Excel tables")
            print("  sources    — list loaded document sources\n")
        else:
            ask(url, session_id, question)


if __name__ == "__main__":
    main()
