"""
config/settings.py — Enterprise RAG Agent Central Configuration
All values overridable via environment variables or .env file
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from project root
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _safe_int(key: str, default: str) -> int:
    """Parse an env var as int. On malformed value, warn to stderr and use the default
    rather than crashing the whole app at import time (logging isn't set up yet here)."""
    raw = os.getenv(key, default)
    try:
        return int(raw)
    except (TypeError, ValueError):
        print(f"[config] WARNING: {key}='{raw}' is not a valid integer, using default '{default}'", file=sys.stderr)
        return int(default)


def _safe_float(key: str, default: str) -> float:
    """Parse an env var as float. On malformed value, warn to stderr and use the default."""
    raw = os.getenv(key, default)
    try:
        return float(raw)
    except (TypeError, ValueError):
        print(f"[config] WARNING: {key}='{raw}' is not a valid float, using default '{default}'", file=sys.stderr)
        return float(default)


# ─── Paths ───────────────────────────────────────────────────────────────────
LOGS_DIR = BASE_DIR / "logs"
DATA_DIR = BASE_DIR / "data"
try:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
except OSError as e:
    print(f"[config] WARNING: could not create logs/data directories: {e}", file=sys.stderr)

# ─── Ollama ──────────────────────────────────────────────────────────────────
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
LLM_MODEL       = os.getenv("LLM_MODEL",       "llama3.2")
EMBED_MODEL     = os.getenv("EMBED_MODEL",      "nomic-embed-text")
LLM_TEMPERATURE = _safe_float("LLM_TEMPERATURE", "0.1")
LLM_MAX_TOKENS  = _safe_int("LLM_MAX_TOKENS",    "2048")
LLM_TIMEOUT     = _safe_int("LLM_TIMEOUT",        "300")  # was 120 — too short for slow models

# ─── ChromaDB ────────────────────────────────────────────────────────────────
CHROMA_PATH       = os.getenv("CHROMA_PATH",       str(BASE_DIR / "chroma_db"))
CHROMA_COLLECTION = os.getenv("CHROMA_COLLECTION", "rag_documents")

# ─── Runtime directories ────────────────────────────────────────────────────
# Ensure all directories the app writes to at runtime exist on first startup,
# regardless of whether this is a fresh checkout or a fresh container.
UPLOADS_DIR = BASE_DIR / "uploads"
TEMP_DIR    = BASE_DIR / "temp"
try:
    Path(CHROMA_PATH).mkdir(parents=True, exist_ok=True)
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
except OSError as e:
    print(f"[config] WARNING: could not create runtime directories: {e}", file=sys.stderr)

# ─── CORS (intranet) ─────────────────────────────────────────────────────────
# The UI is served by this same FastAPI app (StaticFiles), so cross-origin
# access should not be needed by default. If the UI is ever hosted on a
# different intranet hostname/port, set ALLOWED_ORIGINS to a comma-separated
# list of exact origins (e.g. "http://rag.intranet.local,http://10.0.4.12:8080").
# A wildcard ("*") is intentionally NOT supported here: combined with
# allow_credentials=True it is rejected by browsers anyway, and on an internal
# defence network CORS should be an explicit allow-list, not "everything".
_allowed_origins_raw = os.getenv("ALLOWED_ORIGINS", "")
ALLOWED_ORIGINS = [o.strip() for o in _allowed_origins_raw.split(",") if o.strip()]

# ─── DuckDB ──────────────────────────────────────────────────────────────────
DUCKDB_PATH = os.getenv("DUCKDB_PATH", str(BASE_DIR / "data" / "tabular.duckdb"))

# ─── SQLite ──────────────────────────────────────────────────────────────────
SQLITE_PATH = os.getenv("SQLITE_PATH", str(BASE_DIR / "data" / "memory.db"))

# ─── Chunking ────────────────────────────────────────────────────────────────
CHUNK_SIZE     = _safe_int("CHUNK_SIZE",     "800")
CHUNK_OVERLAP  = _safe_int("CHUNK_OVERLAP",  "100")
MIN_CHUNK_SIZE = _safe_int("MIN_CHUNK_SIZE", "50")
MAX_CHUNK_SIZE = _safe_int("MAX_CHUNK_SIZE", "1200")

# tiktoken (accurate token counting for chunking) ships NO encoding files —
# by default it downloads "cl100k_base.tiktoken" from openaipublic.blob.core.windows.net
# the first time it's used, with no request timeout. On an air-gapped intranet where
# outbound traffic is silently dropped (not actively refused) by the firewall, that
# call can hang for minutes on every ingestion instead of failing fast.
# Fix: point tiktoken at a local, persistent cache dir. Pre-populate it once on an
# internet-connected machine (`python -c "import tiktoken; tiktoken.get_encoding('cl100k_base')"`
# with TIKTOKEN_CACHE_DIR set the same way), then copy that directory onto the intranet
# host. core/chunker.py checks for the cached file before ever calling into tiktoken,
# so if it's missing this falls back instantly to word-count estimation — no network
# call is ever attempted, regardless of whether the cache has been pre-populated.
TIKTOKEN_CACHE_DIR = os.getenv("TIKTOKEN_CACHE_DIR", str(BASE_DIR / "data" / "tiktoken_cache"))
os.environ.setdefault("TIKTOKEN_CACHE_DIR", TIKTOKEN_CACHE_DIR)
try:
    Path(TIKTOKEN_CACHE_DIR).mkdir(parents=True, exist_ok=True)
except OSError as e:
    print(f"[config] WARNING: could not create TIKTOKEN_CACHE_DIR: {e}", file=sys.stderr)

# ─── Retrieval ───────────────────────────────────────────────────────────────
TOP_K                = _safe_int("TOP_K",                 "5")
MMR_FETCH_K          = _safe_int("MMR_FETCH_K",           "20")
MMR_LAMBDA           = _safe_float("MMR_LAMBDA",          "0.5")
SCORE_THRESHOLD      = _safe_float("SCORE_THRESHOLD",     "0.3")
RERANKER_TOP_N       = _safe_int("RERANKER_TOP_N",        "5")
RERANKER_FETCH_N     = _safe_int("RERANKER_FETCH_N",      "20")
CONFIDENCE_THRESHOLD = _safe_float("CONFIDENCE_THRESHOLD","0.5")
BM25_WEIGHT          = _safe_float("BM25_WEIGHT",         "0.3")
VECTOR_WEIGHT        = _safe_float("VECTOR_WEIGHT",       "0.7")
EMBED_BATCH_SIZE     = _safe_int("EMBED_BATCH_SIZE",      "32")

# ─── OCR ─────────────────────────────────────────────────────────────────────
# OCR_ENGINE options (intranet-safe, all run fully offline once installed):
#   tesseract  → Tesseract only (baseline, needs apt install tesseract-ocr)
#   easyocr    → EasyOCR (RECOMMENDED offline engine — handles diagrams, labels, low-DPI)
#   llava      → LLaVA via Ollama → EasyOCR → Tesseract  [BEST overall for images/diagrams]
#   paddle     → PaddleOCR → EasyOCR → Tesseract
#   trocr      → TrOCR (HuggingFace, TRANSFORMERS_OFFLINE=1) → EasyOCR → Tesseract
#   auto       → LLaVA → EasyOCR → PaddleOCR → TrOCR → Tesseract (full cascade)
OCR_ENGINE       = os.getenv("OCR_ENGINE",  "easyocr")
OCR_LANGUAGE     = os.getenv("OCR_LANGUAGE","en")
OCR_DPI          = _safe_int("OCR_DPI", "300")
OCR_USE_GPU      = os.getenv("OCR_USE_GPU", "false").lower() == "true"

# EasyOCR model directory (intranet: copy ~/.EasyOCR/ here after first download)
# Leave blank to use default ~/.EasyOCR/  |  Set to local path on air-gapped machines
EASYOCR_MODEL_DIR = os.getenv("EASYOCR_MODEL_DIR", "")  # e.g. "/opt/models/easyocr"

# TrOCR model (only used when OCR_ENGINE=trocr or auto)
# Intranet: copy ~/.cache/huggingface to machine, set TRANSFORMERS_OFFLINE=1
TROCR_MODEL      = os.getenv("TROCR_MODEL", "microsoft/trocr-base-printed")
TRANSFORMERS_OFFLINE = os.getenv("TRANSFORMERS_OFFLINE", "0")  # "1" = fully offline

# LLaVA model (only used when OCR_ENGINE=llava or auto)
# Intranet: ollama pull llava on internet machine, copy ~/.ollama, run: ollama serve
LLAVA_MODEL      = os.getenv("LLAVA_MODEL", "llava")
PDF_TEXT_MIN_LEN = _safe_int("PDF_TEXT_MIN_LEN", "50")

# ─── PDF layout-aware parsing (tables) ────────────────────────────────────────
# Enables the pdfplumber-based layout parser (loaders/pdf_layout_parser.py)
# that separates PDF tables from paragraph/heading/list text instead of
# flattening a whole page into one blob of plain text. If pdfplumber is not
# installed, or parsing a given PDF fails for any reason, ingestion
# automatically falls back to the original plain pypdf extract_text() path —
# this flag can only ever improve PDF ingestion, never break it.
ENABLE_PDF_LAYOUT_PARSING = os.getenv("ENABLE_PDF_LAYOUT_PARSING", "true").lower() == "true"

# A detected PDF table with fewer than this many DATA rows (i.e. excluding
# its header row) is treated as too small to be worth its own DuckDB table +
# semantic summary; it's folded back into the surrounding paragraph text
# instead (as simple "cell | cell | cell" lines) so nothing is silently lost.
PDF_TABLE_MIN_ROWS = _safe_int("PDF_TABLE_MIN_ROWS", "2")

# ─── Hybrid (TEXT + TABLE) query routing ──────────────────────────────────────
# When True, tools/query_router.py can classify a question as needing BOTH
# DuckDB (tables) and ChromaDB (semantic text) in one answer — e.g. "Explain
# the overtime policy and list employees eligible for it." The response's
# query_type is then "hybrid". Existing "tabular"-only / "semantic"-only
# classification and answers are completely unaffected when a question only
# needs one side (see tools/query_router.py and services/query_service.py).
ENABLE_HYBRID_ROUTING = os.getenv("ENABLE_HYBRID_ROUTING", "true").lower() == "true"

# ─── Reranker ────────────────────────────────────────────────────────────────
RERANKER_MODEL  = os.getenv("RERANKER_MODEL",  "BAAI/bge-reranker-base")
RERANKER_DEVICE = os.getenv("RERANKER_DEVICE", "cpu")

# ─── File types ──────────────────────────────────────────────────────────────
SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".doc", ".pptx", ".txt", ".md",
    ".xlsx", ".xlsm", ".xls", ".csv", ".tsv",
    ".jpg", ".jpeg", ".png", ".tiff", ".bmp", ".webp",
}
TABULAR_EXTENSIONS = {".xlsx", ".xlsm", ".xls", ".csv", ".tsv"}
IMAGE_EXTENSIONS   = {".jpg", ".jpeg", ".png", ".tiff", ".bmp", ".webp"}

# ─── SQL Safety ──────────────────────────────────────────────────────────────
SQL_FORBIDDEN_PATTERNS = [
    # DDL / DML — never allowed in read-only query mode
    r"\bDROP\b", r"\bDELETE\b", r"\bUPDATE\b", r"\bINSERT\b",
    r"\bALTER\b", r"\bTRUNCATE\b",
    # "CREATE TABLE" / "CREATE VIEW" — block CREATE + noun combos; allow WITH CTEs
    r"\bCREATE\s+(TABLE|VIEW|INDEX|SCHEMA|DATABASE|SEQUENCE|FUNCTION)\b",
    # Execution / system commands
    r"\bEXEC\b", r"\bEXECUTE\b",
    # Inline comment injection (but allow -- in string literals is rare in auto-SQL)
    r"(?<!')--",
    # Multiple statement injection (two semicolons = two statements)
    r";[^'\"]*;",
]

# ─── API ─────────────────────────────────────────────────────────────────────
API_HOST    = os.getenv("API_HOST",    "0.0.0.0")
API_PORT    = _safe_int("API_PORT","8000")
API_TITLE   = "Enterprise RAG Agent"
API_VERSION = "2.0.0"

# ─── PDF Export (offline / intranet) ─────────────────────────────────────────
# Organization name shown in the exported PDF report header/footer.
# Configurable per deployment without touching code.
ORG_NAME = os.getenv("ORG_NAME", "Enterprise Organization")

# Optional directory for bundled offline PDF fonts (Noto Sans / DejaVu Sans /
# Liberation Sans TTFs). If populated, these take priority over system fonts
# so PDF rendering is identical across every intranet host regardless of what
# fonts happen to be installed on it. Safe to leave empty — pdf_export_service
# falls back to searching common system font directories, then to reportlab's
# built-in Helvetica/Courier if no TTF is found anywhere.
PDF_FONTS_DIR = os.getenv("PDF_FONTS_DIR", str(BASE_DIR / "assets" / "fonts"))

# ─── Logging ─────────────────────────────────────────────────────────────────
LOG_LEVEL        = os.getenv("LOG_LEVEL",        "INFO")
LOG_MAX_BYTES    = _safe_int("LOG_MAX_BYTES", str(10 * 1024 * 1024))
LOG_BACKUP_COUNT = _safe_int("LOG_BACKUP_COUNT", "5")

# ─── Text-to-Speech (Read Aloud) ─────────────────────────────────────────────
# 100% offline. No cloud TTS (Google/Azure/Polly/ElevenLabs/OpenAI) is ever used.
#
# TTS_ENGINE options:
#   auto     -> try Piper first, fall back to pyttsx3 (system/offline) if Piper's
#               model files aren't installed yet - read aloud still works out of
#               the box, just with a lower-quality voice, until Piper is set up.
#   piper    -> Piper only (best quality; requires a downloaded .onnx voice model)
#   pyttsx3  -> system offline TTS only (espeak-ng on Linux, SAPI5 on Windows)
TTS_ENGINE = os.getenv("TTS_ENGINE", "auto")

# Piper voice model - download once (e.g. on an internet-connected machine) and
# copy the .onnx + .onnx.json pair onto the intranet host. Piper itself makes
# no network calls at inference time; the model is just a local file.
PIPER_MODEL_PATH  = os.getenv("PIPER_MODEL_PATH",  str(BASE_DIR / "models" / "tts" / "en_US-arctic-medium.onnx"))
PIPER_CONFIG_PATH = os.getenv("PIPER_CONFIG_PATH", "")  # blank = "<model>.json"
PIPER_USE_CUDA    = os.getenv("PIPER_USE_CUDA", "false").lower() == "true"

# pyttsx3 (fallback engine) - optional overrides; blank = engine default voice/rate
PYTTSX3_VOICE_ID = os.getenv("PYTTSX3_VOICE_ID", "")
PYTTSX3_RATE     = _safe_int("PYTTSX3_RATE", "175")

# Long-response handling: text is synthesized in sentence-grouped chunks (never
# mid-sentence) and merged into a single continuous WAV file server-side, so
# playback in the browser is one seamless audio stream.
TTS_MAX_CHARS_PER_CHUNK = _safe_int("TTS_MAX_CHARS_PER_CHUNK", "900")
TTS_MAX_INPUT_CHARS     = _safe_int("TTS_MAX_INPUT_CHARS", "20000")

# Local disk cache of generated audio, keyed by a hash of the response text.
# Never leaves the machine. Auto-evicted (oldest first) once the cache exceeds
# TTS_CACHE_MAX_MB, and entries older than TTS_CACHE_TTL_HOURS are purged too.
TTS_CACHE_DIR        = os.getenv("TTS_CACHE_DIR", str(BASE_DIR / "temp" / "tts_cache"))
TTS_CACHE_ENABLED    = os.getenv("TTS_CACHE_ENABLED", "true").lower() == "true"
TTS_CACHE_MAX_MB     = _safe_int("TTS_CACHE_MAX_MB", "200")
TTS_CACHE_TTL_HOURS  = _safe_int("TTS_CACHE_TTL_HOURS", "72")

try:
    Path(TTS_CACHE_DIR).mkdir(parents=True, exist_ok=True)
except OSError as e:
    print(f"[config] WARNING: could not create TTS cache directory: {e}", file=sys.stderr)

# ─── Prompts ─────────────────────────────────────────────────────────────────
RAG_SYSTEM_PROMPT = """You are an enterprise AI assistant. Answer ONLY from the provided context.

RULES:
1. Answer only from the context below. Never use outside knowledge.
2. If the context contains NO information relevant to the question at all, say:
   "I do not have enough information in the uploaded documents." (See rule 12 for questions
   that are only partially answerable — do not refuse those entirely.)
3. Always cite the source file, and the page/section when that metadata is available
   (see rule 14 for what to do when it is not).
4. Be precise and factual.
5. If the question involves dates, durations, or calculations (e.g. "how many years between X and Y"),
   work it out step by step from the raw values in the context before stating the final number.
   Double-check your arithmetic. Do not state a duration without showing it follows from the dates given.
6. If a later message in the conversation disputes your previous answer, do NOT simply agree with the
   user's correction. Independently re-derive the answer from the context, re-verify it is grounded
   (per rule 9), and state the result — even if it confirms your earlier answer was right, confirms
   the user is right, or shows both are wrong. Never agree with a claim just because the user
   asserted it; verify it against the context first.
7. Format your answer for readability based on its content, using Markdown:
   - Use a Markdown table when comparing multiple items across two or more attributes
     (e.g. comparing dates, scores, or properties of several entities side by side).
   - Use a numbered list when presenting sequential steps, a ranked order, or a fixed
     set of items where order or count matters (e.g. "list the steps", "top 3 reasons").
   - Use bullet points when listing multiple distinct facts, items, or features that have
     no inherent order or ranking (e.g. skills, responsibilities, features).
   - Use plain prose (no lists or tables) for short, single-fact answers, yes/no answers,
     or explanations that read naturally as a sentence or two.
   - Never force a table, list, or bullets onto an answer that is naturally a single fact
     or short sentence — only structure the answer when it genuinely improves clarity.
   - Bold key terms, numbers, or names within your answer when it aids scanability,
     but do not over-format simple answers.
8. Never fabricate or guess any fact, name, number, date, or detail that is not explicitly present
   in the context above. Do not fill gaps with plausible-sounding information, do not infer facts
   that are not stated, and do not extrapolate beyond what the context literally says.
9. Before finalizing your answer, verify every fact, number, name, and date you are about to state
   actually appears in the context. If you cannot point to where in the context a specific detail
   comes from, remove it or state that it is not available rather than guessing.
10. For any detail you cannot ground in the context, omit it or state it is not available rather
    than guessing — even if this means part of your answer is incomplete.
11. If different parts of the context appear to contradict each other, do not silently pick one.
    State the contradiction explicitly and quote what each source says, rather than presenting
    one version as the single truth.
12. If the question has multiple parts and the context only answers some of them, answer the
    parts you can support from the context, and explicitly state which part(s) you cannot
    answer due to missing information. This rule takes precedence over rule 2 for questions
    that are partially — but not entirely — answerable from the context.
13. Report numbers, percentages, and dates exactly as they appear in the context. Do not round,
    approximate, or simplify them unless the user explicitly asks for an approximation.
14. If a source citation (file name, page, section) is not available in the provided context
    metadata, state the source file name only and do not invent a page or section number.
15. If a source is tagged "(image, OCR-extracted)", the context text was machine-extracted from
    a picture or scanned image — it may be fragmented, out of reading order, or contain garbled
    words. Never say you "don't have an image to analyze" or that you lack visual access — you
    are given the extracted text, and that IS the evidence available for that source. Use whatever
    legible words, numbers, or labels appear to answer as best you can, and explicitly note that
    the source text is fragmented/unclear if it affects your confidence in the answer. Only fall
    back to rule 2's "not enough information" wording if the extracted text is truly empty or
    contains no words relevant to the question at all.

Context:
{context}

Question: {question}

Answer:"""

SQL_SYSTEM_PROMPT = """You are a SQL expert for DuckDB.
Generate ONE valid DuckDB SELECT query from the question.

Tables and Schema:
{table_schema}

IMPORTANT: The schema above is the ONLY source of truth for table and column names — it changes
with every dataset the user uploads. Every rule below describes a general SQL PATTERN to apply,
not specific tables/columns to look for. Any named tables or columns appearing in examples below
(e.g. "students", "gender", "salary") are illustrations only — substitute the actual table and
column names from the schema above. Never assume a specific dataset's structure; adapt every
rule to whatever schema is provided for this query.

STRICT RULES:

1. OUTPUT FORMAT
- Output ONLY raw SQL with NO explanation, NO markdown, NO backticks, NO preamble.
- Your entire response must be a single SQL SELECT statement.
- Use only SELECT or WITH...SELECT statements (read-only). Never DROP, DELETE, UPDATE, INSERT,
  ALTER, or any write/DDL operation.

2. NAMING ACCURACY
- Column names must match the schema EXACTLY (case-sensitive, use underscores as shown).
- Table names must be quoted with double-quotes exactly as shown in the schema.
- If unsure of the column name, use the closest matching column from the schema — never invent
  a column or table name that doesn't appear in the schema.
- For string comparisons use ILIKE for case-insensitive matching.

3. PLAIN AVERAGES VS PERCENTAGES — DO NOT CONFLATE THEM
- For a plain "average X" or "mean X" question, use AVG(column) directly. Do NOT multiply by 100
  unless the question explicitly asks for a percentage, share, proportion, or rate (e.g. "what
  percent of rows...", "what proportion...", "pass rate", "X% of total").
- Only when the question explicitly asks for a percentage/proportion/rate of one group out of a
  total, use: ROUND(100.0 * numerator / NULLIF(denominator, 0), 2). Never apply this pattern to a
  simple average, sum, min, or max question — those should use AVG(), SUM(), MIN(), MAX() as-is.
- Before finalizing, re-read the question: does it ask for an average/sum/count of a single
  column, or a percentage/share of one subset relative to a total? Use the matching pattern only.

4. HIGHEST/LOWEST/TOP/BOTTOM SINGLE-ENTITY QUESTIONS
- For "highest/lowest/top/bottom/best/worst <entity> by <metric>" questions (e.g. "highest-paid
  employee", "lowest-scoring item", "which product sells the most"), the question wants the
  actual metric VALUE for that entity, not a percentage or ratio. Use ORDER BY <metric> DESC/ASC
  LIMIT 1 and SELECT the identifying column(s) plus the raw metric itself — never wrap the metric
  in a percentage-of-max/percentage-of-total calculation, since that always produces a meaningless
  100.0 (or near-0) for the top/bottom row and discards the actual number the user asked for.
  Pattern:
  WRONG:   SELECT name, ROUND(100.0 * metric / (SELECT MAX(metric) FROM table), 2) AS percent
           FROM table ORDER BY percent DESC LIMIT 1
  CORRECT: SELECT name, metric FROM table ORDER BY metric DESC LIMIT 1
- For top-N: add ORDER BY ... DESC LIMIT N, and always include the ranking metric itself in the
  SELECT list (see rule 6) — never just the identifying column.

5. PER-ROW ARITHMETIC VS AGGREGATES — DO NOT CONFLATE THEM
- When ranking or sorting individual rows by a computed value derived from multiple columns in
  that same row (e.g. "top N rows by average of three columns"), the computation is PER-ROW
  arithmetic, not an aggregate — do NOT wrap it in AVG(), SUM(), or any aggregate function. Use
  plain arithmetic directly, e.g.: ORDER BY (col1 + col2 + col3) / 3.0 DESC LIMIT N
  Aggregate functions (AVG, SUM, COUNT, MIN, MAX) are only valid when the query has a GROUP BY,
  or when collapsing the whole table to one summary row. If your ORDER BY or SELECT list mixes
  a non-aggregated column (like a name) with an aggregate function, the query is invalid unless
  you add a GROUP BY for every non-aggregated column — prefer rewriting as per-row arithmetic
  instead, since that is what "top N rows by X" questions actually mean.

6. ALWAYS SELECT WHAT THE QUESTION ASKS FOR
- CRITICAL: Always SELECT every value the question asks about or ranks by — never put a computed
  value (sum, average, count, ratio, etc.) ONLY in ORDER BY without also including it in the
  SELECT list with a clear alias. The query's output is shown directly to the user, so it must
  contain the numbers being asked for, not just the rows that satisfy them.
  WRONG:   SELECT name FROM table ORDER BY (col1+col2)/2.0 DESC LIMIT 5
  CORRECT: SELECT name, ROUND((col1+col2)/2.0, 2) AS computed_value
           FROM table ORDER BY computed_value DESC LIMIT 5

7. COMPARISONS AND BREAKDOWNS — GROUP BY, NEVER FILTER TO ONE CATEGORY
- CRITICAL: If the question asks to compare two or more categories, or asks for a breakdown,
  split, or distribution across a categorical column — regardless of what that column or domain
  is — you must return counts/values for ALL categories using GROUP BY on that column. Never
  filter down to just one category with WHERE when the question implies comparing categories.
  A WHERE clause that picks a single value silently drops every other category and answers only
  part of the question, which is wrong even if the query runs without error.
  This applies to ANY categorical column in ANY dataset — not just the illustrations below.
  Signal phrases include: "X vs Y", "by <column>", "breakdown of/by", "distribution of",
  "split by", "how many of each", "compare ... across", "for each <category>".
  Pattern (illustrative only — substitute real table/column names from the schema):
    WRONG:   SELECT COUNT(*) FROM table WHERE category_col = 'SomeValue'
    CORRECT: SELECT category_col, COUNT(*) AS row_count FROM table GROUP BY category_col
  A WHERE filter to one category is only correct when the question explicitly asks about that
  single category alone (e.g. "how many rows are SomeValue?" with no comparison implied).

8. NEVER USE SELECT * WHEN LISTING OR FILTERING ROWS
- Never use SELECT * when listing or filtering rows (e.g. "which rows have X", "list items where
  Y"). SELECT * pulls in every column in the table, most of which are irrelevant to the question
  and make the result hard to read. Instead SELECT only: (a) an identifying column (e.g. id,
  name) so each row can be told apart, and (b) the specific column(s) the question is actually
  about.
  WRONG:   SELECT * FROM table WHERE some_column < threshold
  CORRECT: SELECT id_column, name_column, some_column FROM table WHERE some_column < threshold

9. NUMERIC FUNCTION SAFETY
- To round a numeric value, use ROUND(value, decimals) only. Never use RIGHT(), LEFT(), or any
  string-truncation function on a numeric column — those operate on text and will fail or produce
  garbage on numbers. If unsure a function name is correct, prefer simpler, well-known functions:
  ROUND, CAST, AVG, SUM, COUNT, MIN, MAX.

10. PREFER THE SINGLE TABLE THAT ALREADY HAS THE ANSWER — DO NOT INVENT JOINS
- Before writing a JOIN, check whether ONE table in the schema already contains every column the
  question needs (the metric, the identifying name, and the grouping/category column). If it
  does, query that single table only. Do NOT join in another table "to be safe" or because it
  sounds related — an unnecessary join can silently filter out rows (via INNER JOIN) or attach
  the wrong category to a row, producing a confidently wrong answer instead of a clean one.
- Only join when a column the question explicitly needs is missing from every table on its own,
  AND the schema shows an actual shared key (matching column name/type, e.g. an _id-style column
  on both sides) connecting the tables that have those columns. Never join two tables on a guessed
  or loosely-named relationship (e.g. matching a person's name in one table to an unrelated label
  in another) — if no real shared key exists in the schema, do not join; instead answer from
  whichever single table actually has the needed columns, or say the data isn't linkable.

11. "TOP / HIGHEST / BEST ... PER <GROUP>" — USE A WINDOW FUNCTION ON ONE TABLE
- For "top/highest/lowest/best/worst <entity> per/by/for each <category>" questions (e.g.
  "top-paid teacher per subject", "highest scorer per class"), this means: within each distinct
  value of the category column, find the single best row by the metric. This is a PARTITION, not
  a join. If the category and metric both already live in the same table, do it entirely within
  that one table using a window function:
  WITH ranked AS (
    SELECT category_col, name_col, metric_col,
           ROW_NUMBER() OVER (PARTITION BY category_col ORDER BY metric_col DESC) AS rn
    FROM table
  )
  SELECT category_col, name_col, metric_col FROM ranked WHERE rn = 1 ORDER BY category_col
  Never reach for a second table's column as a stand-in for the category unless the first table
  truly lacks that category column (see rule 10).

WORKED EXAMPLE (apply this exact reasoning, substituting the real table/column names from the
schema above — do not literally copy these table names if they don't appear in your schema):
  Schema has:
    Table "employees": id, name, department, salary
    Table "office_locations": building, floor, manager_name
  Question: "Top-paid employee per department?"
  Reasoning: "department" and "salary" and "name" are ALL already in "employees". There is no
  shared key between "employees" and "office_locations" (no manager_id/employee_id linking them),
  and "office_locations" has no "department" or "salary" column anyway — it is irrelevant to this
  question. Do not touch it.
  WRONG:   SELECT E.name, E.salary FROM employees AS E INNER JOIN office_locations AS O
           ON E.name = O.manager_name WHERE E.department = O.floor ORDER BY E.salary DESC LIMIT 1
  CORRECT: WITH ranked AS (
             SELECT department, name, salary,
                    ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) AS rn
             FROM employees
           )
           SELECT department, name, salary FROM ranked WHERE rn = 1 ORDER BY department

Question: {question}

SQL:"""
ROUTER_SYSTEM_PROMPT = """Classify this question. Reply with exactly one word.

"tabular" — questions about:
  - Numbers, calculations, aggregations (total, sum, average, count, max, min)
  - Rankings, comparisons, percentages, growth rates
  - Data from spreadsheets, CSV files, or tables
  - "how many", "how much", "which is highest/lowest", "list the top N"
  - Questions about specific rows, values, or metrics in data

"semantic" — questions about:
  - Policies, procedures, explanations, summaries
  - Definitions, meanings, descriptions
  - Process steps, guidelines, rules
  - "what is", "explain", "describe", "why", "how to"

"both" — questions that need BOTH of the above in one answer, e.g. asking to
  explain a policy AND list/calculate matching data records in the same
  question ("Explain overtime policy and list employees eligible for it").

When in doubt and the question involves numbers or data — choose "tabular".

Question: {question}

Answer:"""