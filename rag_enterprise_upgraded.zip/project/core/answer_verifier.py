"""
core/answer_verifier.py — PROBLEM 10 (Answer Verification): after the LLM
generates an answer, check that its claims are actually grounded in the
retrieved evidence (semantic chunks and/or SQL result text) before the
answer is returned to the user.

Design goals:
  - No extra LLM call by default (cheap, deterministic, always runs) —
    lexical/entity grounding: does each sentence in the answer share
    meaningful vocabulary with the evidence it's supposedly drawn from?
  - Never blocks a good answer: this only ever *appends* a visible caveat,
    it never silently rewrites or discards the model's answer.
  - Generic: no hardcoded topics/keywords — grounding is computed purely
    from token overlap between the answer and whatever evidence text was
    actually retrieved for this question, so it works for any document.
"""

import re
from typing import Any, Dict, List, Tuple

_STOPWORDS = {
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "of", "to", "in", "on", "for", "with", "as", "by", "at", "from", "this",
    "that", "these", "those", "it", "its", "and", "or", "but", "if", "not",
    "no", "yes", "do", "does", "did", "has", "have", "had", "will", "would",
    "can", "could", "should", "may", "might", "you", "your", "i", "we",
    "they", "he", "she", "them", "his", "her", "their", "there", "here",
    "which", "who", "whom", "what", "when", "where", "why", "how", "than",
    "then", "so", "such", "also", "into", "about", "based", "provided",
    "document", "documents", "data", "according",
}

# Sentences below this length are usually connective/summary framing
# ("Here is a summary of the key points:") rather than a factual claim, and
# are skipped so they don't get flagged as "unsupported" noise.
_MIN_SENTENCE_TOKENS = 6

# A sentence needs at least this fraction of its non-stopword tokens to
# appear in the evidence to be considered grounded.
_GROUNDING_THRESHOLD = 0.25


def _tokenize(text: str) -> List[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in _STOPWORDS and len(t) > 1]


def _split_sentences(text: str) -> List[str]:
    # Simple, dependency-free sentence splitter — good enough for a coarse
    # grounding check; doesn't need to be linguistically perfect.
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [p.strip() for p in parts if p.strip()]


def verify_answer(answer: str, evidence_text: str) -> Dict[str, Any]:
    """
    Return {
      "is_grounded": bool,
      "grounded_ratio": float,      # fraction of checkable sentences that were grounded
      "unsupported_sentences": [str, ...],
      "checked_sentences": int,
    }
    """
    if not answer or not answer.strip():
        return {"is_grounded": True, "grounded_ratio": 1.0, "unsupported_sentences": [], "checked_sentences": 0}

    evidence_tokens = set(_tokenize(evidence_text or ""))
    if not evidence_tokens:
        # No evidence at all was retrieved — can't verify grounding either way;
        # don't flag, since an empty-evidence case is already handled upstream
        # (confidence==0.0 -> "not enough information" response).
        return {"is_grounded": True, "grounded_ratio": 1.0, "unsupported_sentences": [], "checked_sentences": 0}

    sentences = _split_sentences(answer)
    unsupported: List[str] = []
    checked = 0

    for sent in sentences:
        toks = _tokenize(sent)
        if len(toks) < _MIN_SENTENCE_TOKENS:
            continue
        checked += 1
        overlap = sum(1 for t in toks if t in evidence_tokens)
        ratio = overlap / len(toks)
        if ratio < _GROUNDING_THRESHOLD:
            unsupported.append(sent)

    if checked == 0:
        return {"is_grounded": True, "grounded_ratio": 1.0, "unsupported_sentences": [], "checked_sentences": 0}

    grounded_ratio = 1.0 - (len(unsupported) / checked)
    # Tolerate a minority of ungrounded sentences (transitions, reasoning,
    # legitimate synthesis across multiple chunks can look locally sparse) —
    # only flag when a clear majority of substantive sentences don't match
    # any retrieved evidence at all.
    is_grounded = grounded_ratio >= 0.5

    return {
        "is_grounded": is_grounded,
        "grounded_ratio": round(grounded_ratio, 3),
        "unsupported_sentences": unsupported,
        "checked_sentences": checked,
    }


def apply_verification(answer: str, evidence_text: str) -> Tuple[str, Dict[str, Any]]:
    """
    Run verify_answer() and, if grounding is weak, append a visible caveat to
    the answer (never remove or rewrite content — PROBLEM 10 says "never
    hallucinate", not "never speak" — the honest move is to flag uncertainty,
    not to suppress an answer the user may still find useful).
    """
    result = verify_answer(answer, evidence_text)
    if not result["is_grounded"]:
        caveat = (
            "\n\n*Note: parts of this answer could not be fully verified against "
            "the uploaded document content. Please cross-check the details above "
            "against the source material.*"
        )
        answer = answer.rstrip() + caveat
    return answer, result
