"""
core/chunker.py — Text chunking with token-aware overlap.

Splits documents into fixed-size chunks with overlap using tiktoken for accurate
token counting. Supports min/max chunk size filtering.
"""

import hashlib
import os
import re
from pathlib import Path
from typing import Any, Dict, List

from utils.logger import get_logger

logger = get_logger("chunker")

# tiktoken has no bundled encoding files — by default it fetches cl100k_base.tiktoken
# from the internet (openaipublic.blob.core.windows.net) on first use, with no request
# timeout. On a fully air-gapped intranet that call can hang instead of failing fast.
# So: only ever call into tiktoken if the encoding file is ALREADY present in
# TIKTOKEN_CACHE_DIR (see config/settings.py) — otherwise skip straight to the
# word-count fallback below. This guarantees chunk_documents() never makes a network
# call, whether or not the cache has been pre-populated.
_CL100K_URL = "https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken"
_TIKTOKEN_WARNED = False


def _cl100k_cached_locally() -> bool:
    """Check whether cl100k_base's encoding file is already in the tiktoken cache,
    without ever letting tiktoken itself attempt a network fetch."""
    cache_dir = os.environ.get("TIKTOKEN_CACHE_DIR", "")
    if not cache_dir:
        return False
    cache_key = hashlib.sha1(_CL100K_URL.encode()).hexdigest()
    return (Path(cache_dir) / cache_key).exists()


def _get_tokenizer():
    """Return tiktoken encoder if it's usable fully offline, else None (word-count fallback)."""
    global _TIKTOKEN_WARNED
    if not _cl100k_cached_locally():
        if not _TIKTOKEN_WARNED:
            logger.warning(
                "tiktoken's cl100k_base encoding is not cached locally in "
                f"TIKTOKEN_CACHE_DIR ({os.environ.get('TIKTOKEN_CACHE_DIR')}) — skipping it "
                "to avoid a network call on this intranet host. Falling back to word-count "
                "based chunk sizing (chunks will still be produced correctly, just sized by "
                "word count instead of exact token count). To enable exact token counting, "
                "pre-download the encoding on an internet-connected machine and copy the "
                "TIKTOKEN_CACHE_DIR directory onto this host — see README.md."
            )
            _TIKTOKEN_WARNED = True
        return None
    try:
        import tiktoken
        return tiktoken.get_encoding("cl100k_base")
    except Exception as e:
        if not _TIKTOKEN_WARNED:
            logger.warning(f"tiktoken failed to load from local cache, using word-count fallback: {e}")
            _TIKTOKEN_WARNED = True
        return None


def _token_count(text: str, tokenizer=None) -> int:
    """Count tokens in text. Falls back to word-based estimate."""
    if tokenizer is not None:
        try:
            return len(tokenizer.encode(text))
        except Exception:
            pass
    return len(text.split())


def _split_text(
    text: str,
    chunk_size: int,
    chunk_overlap: int,
    tokenizer=None,
) -> List[str]:
    """
    Split text into overlapping chunks of approximately chunk_size tokens.
    Uses sentence boundaries when possible to avoid mid-sentence splits.
    """
    # Split into sentences first for natural boundaries
    sentence_endings = re.compile(r"(?<=[.!?])\s+")
    sentences = sentence_endings.split(text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]

    if not sentences:
        return []

    chunks = []
    current_tokens = []
    current_size = 0

    for sentence in sentences:
        sent_tokens = sentence.split()  # approximate
        sent_size = _token_count(sentence, tokenizer)

        # If a single sentence exceeds chunk_size, hard-split it by words
        if sent_size > chunk_size:
            words = sentence.split()
            sub_chunk: List[str] = []
            sub_size = 0
            for word in words:
                word_size = _token_count(word, tokenizer)
                if sub_size + word_size > chunk_size and sub_chunk:
                    chunks.append(" ".join(sub_chunk))
                    # Keep overlap
                    overlap_words = sub_chunk[-max(1, chunk_overlap // 10):]
                    sub_chunk = overlap_words + [word]
                    sub_size = sum(_token_count(w, tokenizer) for w in sub_chunk)
                else:
                    sub_chunk.append(word)
                    sub_size += word_size
            if sub_chunk:
                current_tokens = sub_chunk
                current_size = sub_size
            continue

        # If adding this sentence would overflow, flush current chunk
        if current_size + sent_size > chunk_size and current_tokens:
            chunks.append(" ".join(current_tokens))
            # Keep overlap: retain tail of current chunk
            overlap_size = 0
            overlap_tokens = []
            for token in reversed(current_tokens):
                token_size = _token_count(token, tokenizer)
                if overlap_size + token_size > chunk_overlap:
                    break
                overlap_tokens.insert(0, token)
                overlap_size += token_size
            current_tokens = overlap_tokens
            current_size = overlap_size

        current_tokens.extend(sent_tokens)
        current_size += sent_size

    if current_tokens:
        chunks.append(" ".join(current_tokens))

    return chunks


def chunk_documents(
    documents: List[Dict[str, Any]],
    chunk_size: int = 800,
    chunk_overlap: int = 100,
    min_chunk_size: int = 50,
    max_chunk_size: int = 1200,
) -> List[Dict[str, Any]]:
    """
    Split a list of document dicts into chunks.

    Each document dict must have:
      - "text": str — the document text
      - "metadata": dict — source metadata (source_name, source, type, page/slide, etc.)

    Returns a list of chunk dicts with the same metadata schema plus "chunk_index".
    """
    tokenizer = _get_tokenizer()
    all_chunks: List[Dict[str, Any]] = []

    for doc in documents:
        text = doc.get("text", "").strip()
        metadata = dict(doc.get("metadata", {}))

        if not text:
            continue

        raw_chunks = _split_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap, tokenizer=tokenizer)
        if not raw_chunks:
            continue

        kept_any = False

        for idx, chunk_text in enumerate(raw_chunks):
            chunk_text = chunk_text.strip()
            if not chunk_text:
                continue
            token_len = _token_count(chunk_text, tokenizer)

            # min_chunk_size exists to drop tiny leftover fragments (e.g. a
            # one-word overlap remainder) when a document produced MULTIPLE
            # chunks. It should never cause a document's ONLY chunk to be
            # dropped — that discards the entire document instead of just
            # trimming a fragment. This matters a lot for OCR'd images:
            # receipts, signs, labels, and screenshots routinely extract to
            # well under 50 words of text, so without this guard every such
            # image was silently ingested as zero chunks.
            if token_len < min_chunk_size and len(raw_chunks) > 1:
                continue
            if token_len > max_chunk_size:
                # Re-split this oversized chunk
                sub_chunks = _split_text(
                    chunk_text,
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                    tokenizer=tokenizer,
                )
                for sub_idx, sub_text in enumerate(sub_chunks):
                    sub_text = sub_text.strip()
                    if not sub_text:
                        continue
                    if _token_count(sub_text, tokenizer) >= min_chunk_size or len(sub_chunks) == 1:
                        chunk_meta = dict(metadata)
                        chunk_meta["chunk_index"] = len(all_chunks)
                        chunk_meta["token_count"] = _token_count(sub_text, tokenizer)
                        all_chunks.append({"text": sub_text, "metadata": chunk_meta})
                        kept_any = True
                continue

            chunk_meta = dict(metadata)
            chunk_meta["chunk_index"] = len(all_chunks)
            chunk_meta["token_count"] = token_len
            all_chunks.append({"text": chunk_text, "metadata": chunk_meta})
            kept_any = True

        # Safety net: if every fragment of a multi-chunk split still ended up
        # under min_chunk_size (e.g. a short doc that just barely split into
        # two slivers), keep the single largest fragment rather than losing
        # the document's content entirely.
        if not kept_any:
            fallback = max((c.strip() for c in raw_chunks if c.strip()),
                           key=lambda c: _token_count(c, tokenizer), default="")
            if fallback:
                chunk_meta = dict(metadata)
                chunk_meta["chunk_index"] = len(all_chunks)
                chunk_meta["token_count"] = _token_count(fallback, tokenizer)
                all_chunks.append({"text": fallback, "metadata": chunk_meta})

    logger.info(f"Chunked {len(documents)} docs → {len(all_chunks)} chunks")
    return all_chunks


def chunk_stats(chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Return summary statistics about a list of chunks."""
    if not chunks:
        return {"total_chunks": 0, "avg_tokens": 0, "min_tokens": 0, "max_tokens": 0}

    token_counts = [c.get("metadata", {}).get("token_count", len(c["text"].split())) for c in chunks]

    return {
        "total_chunks": len(chunks),
        "avg_tokens": round(sum(token_counts) / len(token_counts), 1),
        "min_tokens": min(token_counts),
        "max_tokens": max(token_counts),
    }
