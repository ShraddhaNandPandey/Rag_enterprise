"""
core/table_summarizer.py — Turn an extracted PDF table into (a) a DuckDB-ready
DataFrame and (b) a short semantic summary for embedding.

PART 3 — preserve row/column structure (never flatten a table into standalone
          lines of "Employee\nSalary\nDepartment\n...").
PART 5 — create ONE short semantic summary per table ("Table Name / Columns /
          description") and embed ONLY that summary — never the raw rows.
PART 6 — the summary text itself references the metadata fields (table name,
          columns, section/heading) that ingestion_service.py also attaches
          to the summary chunk's metadata for retrieval/citation.
PART 9 — this is the only place PDF table content is ever turned into text
          for embedding, and it is always short (a handful of lines), so a
          1000-row PDF table costs the same embedding effort as a 5-row one.
"""

import re
from typing import Dict, List

import pandas as pd

from utils.logger import get_logger

logger = get_logger("table_summarizer")


def _clean_header(cell: str, idx: int) -> str:
    """Turn a raw table header cell into a safe DuckDB/DataFrame column name."""
    cell = (cell or "").strip()
    cell = re.sub(r"\s+", "_", cell)
    cell = re.sub(r"[^\w]", "", cell)
    return cell or f"column_{idx}"


def rows_to_dataframe(rows: List[List[str]]) -> pd.DataFrame:
    """
    Convert extracted table rows (first row = header) into a DataFrame,
    preserving the original row/column relationships exactly as extracted.

    Ragged rows (a common artifact of PDF table extraction, e.g. a merged
    cell) are padded/truncated to the header width rather than raising, so a
    single malformed row never fails the whole table.
    """
    if not rows or len(rows) < 2:
        return pd.DataFrame()

    header = [_clean_header(c, i) for i, c in enumerate(rows[0])]

    # De-duplicate repeated column names (e.g. two blank header cells both
    # becoming "column_2") the same way database_manager._clean_dataframe does
    # for CSV/XLSX, so downstream behaviour is consistent across all sources.
    seen: Dict[str, int] = {}
    unique_header = []
    for h in header:
        if h in seen:
            seen[h] += 1
            unique_header.append(f"{h}_{seen[h]}")
        else:
            seen[h] = 0
            unique_header.append(h)

    body = []
    width = len(unique_header)
    for r in rows[1:]:
        if len(r) < width:
            r = r + [""] * (width - len(r))
        elif len(r) > width:
            r = r[:width]
        body.append(r)

    df = pd.DataFrame(body, columns=unique_header)

    # Best-effort numeric coercion so SQL aggregation (SUM/AVG/etc.) works on
    # PDF-extracted tables the same way it already does for CSV/XLSX. Only
    # coerce a column if the vast majority of its values parse as numbers —
    # otherwise leave it as text (e.g. a mixed "Notes" column).
    for col in df.columns:
        cleaned = df[col].astype(str).str.replace(",", "", regex=False).str.strip()
        coerced = pd.to_numeric(cleaned, errors="coerce")
        non_empty = cleaned.replace("", pd.NA).notna()
        if non_empty.sum() > 0 and (coerced.notna().sum() / non_empty.sum()) >= 0.8:
            df[col] = coerced

    return df


def build_table_summary(
    table_name: str,
    df: pd.DataFrame,
    source_name: str,
    page: int,
    heading: str = "",
    section: str = "",
) -> str:
    """
    Build the short natural-language summary that gets embedded in ChromaDB
    for this table (PART 5). Deliberately short — a handful of lines — no
    matter how many rows the underlying table has.

    PHASE 2: `heading` (the nearest, most specific heading — e.g. "Salary
    Structure") and `section` (the enclosing top-level section — e.g.
    "Payroll") are now tracked separately (see loaders/file_loader.py's
    two-level hierarchy). When they differ, both are surfaced so retrieval
    can match on either the specific table title or its broader section.
    """
    columns = list(df.columns)
    location_bits = [f"Source: {source_name}, page {page}"]
    if heading:
        location_bits.append(f"heading '{heading}'")
    if section and section != heading:
        location_bits.append(f"section '{section}'")
    lines = [
        f"Table Name: {table_name}",
        ", ".join(location_bits),
        f"Columns: {', '.join(columns)}",
        f"Rows: {len(df)}",
        (
            f"This table contains {len(df)} row(s) with columns: {', '.join(columns)}. "
            f"For exact values, totals, filtering, or calculations, query DuckDB table "
            f"\"{table_name}\"."
        ),
    ]
    return "\n".join(lines)
