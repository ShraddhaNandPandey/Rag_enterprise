"""
database/duckdb_manager.py — Enterprise DuckDB Tabular Data Layer

Handles all CSV and Excel files with accurate SQL-based calculations.
Never uses embeddings for numerical data — prevents hallucination.
"""

import re
import json
import duckdb
import pandas as pd
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

from config.settings import DUCKDB_PATH, SQL_FORBIDDEN_PATTERNS
from utils.logger import get_logger

logger = get_logger("sql")


class DuckDBManager:
    """Manages tabular data ingestion and SQL query execution via DuckDB."""

    def __init__(self, db_path: str = DUCKDB_PATH):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[duckdb.DuckDBPyConnection] = None
        self._connect()
        logger.info(f"DuckDB initialized at: {db_path}")

    def _connect(self) -> None:
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass

        try:
            self._conn = duckdb.connect(database=self.db_path, read_only=False)
            return
        except duckdb.CatalogException as e:
            # A WAL (write-ahead log) file left over from an unclean shutdown (Ctrl+C,
            # crash, killed process mid-write) can conflict with what's already
            # committed in the main .duckdb file — DuckDB then refuses to even open
            # the database. The WAL only ever contains the *uncommitted* tail of the
            # last session, so it's always safe to drop it and reopen; at worst you
            # lose the last incomplete write, never previously-committed data.
            wal_path = Path(f"{self.db_path}.wal")
            if "already exists" in str(e) and wal_path.exists():
                logger.warning(
                    f"DuckDB WAL replay conflict on connect ({e}). This usually means the "
                    f"server was stopped uncleanly last time. Removing stale WAL file "
                    f"'{wal_path}' and retrying — any not-yet-committed writes from the "
                    f"last session are discarded, but previously saved tables are kept."
                )
                try:
                    wal_path.unlink()
                except Exception as unlink_err:
                    logger.error(f"Could not remove stale WAL file '{wal_path}': {unlink_err}")
                    raise
                self._conn = duckdb.connect(database=self.db_path, read_only=False)
                logger.info("DuckDB reconnected successfully after WAL recovery.")
                return
            raise

    @property
    def conn(self) -> duckdb.DuckDBPyConnection:
        try:
            self._conn.execute("SELECT 1")
        except Exception:
            logger.warning("DuckDB connection lost, reconnecting...")
            self._connect()
        return self._conn

    def _sanitize_table_name(self, name: str) -> str:
        name = Path(name).stem
        name = re.sub(r"[^a-zA-Z0-9_]", "_", name)
        name = re.sub(r"_+", "_", name).strip("_").lower()
        if name and name[0].isdigit():
            name = "t_" + name
        return name or "table_unnamed"

    def _ensure_unique_table_name(self, base_name: str) -> str:
        existing = {t.lower() for t in self.list_tables()}
        name = base_name
        counter = 1
        while name.lower() in existing:
            name = f"{base_name}_{counter}"
            counter += 1
        return name

    def _clean_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        df.columns = [
            re.sub(r"[^a-zA-Z0-9_]", "_", str(c)).strip("_").lower() or f"col_{i}"
            for i, c in enumerate(df.columns)
        ]
        seen: Dict[str, int] = {}
        new_cols = []
        for col in df.columns:
            if col in seen:
                seen[col] += 1
                new_cols.append(f"{col}_{seen[col]}")
            else:
                seen[col] = 0
                new_cols.append(col)
        df.columns = new_cols
        return df

    def _init_registry(self) -> None:
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS _rag_table_registry (
                table_name   VARCHAR PRIMARY KEY,
                source_file  VARCHAR,
                sheet_name   VARCHAR,
                row_count    INTEGER,
                col_count    INTEGER,
                columns_json VARCHAR,
                loaded_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # PROBLEM 5 (Document Isolation): document_id/content_hash/doc_version
        # let queries and cleanup routines tie a DuckDB table back to the exact
        # ingested file version it came from, not just a filename. Added via
        # ALTER TABLE ... IF NOT EXISTS so existing databases created before
        # this upgrade keep working without any manual migration — old rows
        # simply have NULL for these columns until the file is re-ingested.
        for col, coltype in (
            ("document_id", "VARCHAR"),
            ("content_hash", "VARCHAR"),
            ("doc_version", "INTEGER"),
        ):
            try:
                self.conn.execute(f'ALTER TABLE _rag_table_registry ADD COLUMN IF NOT EXISTS {col} {coltype}')
            except Exception as e:
                logger.debug(f"Registry column '{col}' migration skipped: {e}")

    def _register_metadata(self, table_name, source_file, sheet_name, row_count, col_count, columns,
                            document_id=None, content_hash=None, doc_version=None):
        self._init_registry()
        self.conn.execute("""
            INSERT OR REPLACE INTO _rag_table_registry
            (table_name, source_file, sheet_name, row_count, col_count, columns_json,
             document_id, content_hash, doc_version)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [table_name, source_file, sheet_name, row_count, col_count, json.dumps(columns),
              document_id, content_hash, doc_version])

    # ─── Public: Data Loading ─────────────────────────────────────────────

    def _read_csv_robust(self, file_path: str, encoding: str, sep: Optional[str], engine: str) -> pd.DataFrame:
        """pd.read_csv with an automatic latin-1 fallback if the given encoding fails."""
        try:
            return pd.read_csv(file_path, encoding=encoding, encoding_errors="replace", sep=sep, engine=engine)
        except UnicodeDecodeError:
            return pd.read_csv(file_path, encoding="latin-1", encoding_errors="replace", sep=sep, engine=engine)

    def load_csv(self, file_path: str, table_name: Optional[str] = None, encoding: str = "utf-8",
                 document_id: Optional[str] = None, content_hash: Optional[str] = None,
                 doc_version: Optional[int] = None) -> Dict[str, Any]:
        """Load a CSV or TSV file into a DuckDB table."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"CSV not found: {file_path}")

        if path.suffix.lower() == ".tsv":
            df = self._read_csv_robust(file_path, encoding, sep="\t", engine="c")
        else:
            # FIX: previously always used sep=None + engine="python" (delimiter
            # sniffing) for every .csv file, even perfectly standard comma-separated
            # ones. The Python engine's sniffing mode is 10-50x slower than the C
            # engine — on a 1M-row/80MB file this alone took ~27s. Try the fast path
            # (comma, C engine) first, and only fall back to slow auto-detection if
            # that produces a single column (the signal that ',' isn't the real
            # delimiter, e.g. ';'- or '|'-separated exports).
            df = self._read_csv_robust(file_path, encoding, sep=",", engine="c")
            if df.shape[1] == 1:
                logger.info(
                    f"'{path.name}' parsed as a single column with ',' — "
                    f"re-parsing with delimiter auto-detection."
                )
                df = self._read_csv_robust(file_path, encoding, sep=None, engine="python")

        df = self._clean_dataframe(df)
        tname = table_name or self._ensure_unique_table_name(self._sanitize_table_name(path.name))
        self.conn.execute(f'DROP TABLE IF EXISTS "{tname}"')
        self.conn.execute(f'CREATE TABLE "{tname}" AS SELECT * FROM df')
        self._register_metadata(tname, str(path), "", len(df), len(df.columns), list(df.columns),
                                 document_id=document_id, content_hash=content_hash, doc_version=doc_version)
        logger.info(f"Loaded CSV '{path.name}' -> table '{tname}' ({len(df)} rows)")
        return {"table_name": tname, "source_file": str(path), "sheet_name": None,
                "row_count": len(df), "col_count": len(df.columns), "columns": list(df.columns)}

    def load_excel(self, file_path: str, sheet_names: Optional[List[str]] = None,
                    document_id: Optional[str] = None, content_hash: Optional[str] = None,
                    doc_version: Optional[int] = None) -> List[Dict[str, Any]]:
        """Load Excel file — each sheet becomes a separate DuckDB table."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Excel not found: {file_path}")
        xl = pd.ExcelFile(file_path)
        sheets = sheet_names or xl.sheet_names
        results = []
        for sheet in sheets:
            try:
                df = xl.parse(sheet)
                df = self._clean_dataframe(df)
                base = self._sanitize_table_name(f"{path.stem}_{sheet}")
                tname = self._ensure_unique_table_name(base)
                self.conn.execute(f'DROP TABLE IF EXISTS "{tname}"')
                self.conn.execute(f'CREATE TABLE "{tname}" AS SELECT * FROM df')
                self._register_metadata(tname, str(path), sheet, len(df), len(df.columns), list(df.columns),
                                         document_id=document_id, content_hash=content_hash, doc_version=doc_version)
                logger.info(f"Loaded Excel '{path.name}' sheet '{sheet}' -> table '{tname}' ({len(df)} rows)")
                results.append({"table_name": tname, "source_file": str(path), "sheet_name": sheet,
                                "row_count": len(df), "col_count": len(df.columns), "columns": list(df.columns)})
            except Exception as e:
                logger.error(f"Failed to load sheet '{sheet}' from '{path.name}': {e}")
        return results

    def register_table(self, df: pd.DataFrame, table_name: str, source_file: str = "",
                        document_id: Optional[str] = None, content_hash: Optional[str] = None,
                        doc_version: Optional[int] = None) -> str:
        """Register an in-memory DataFrame as a DuckDB table."""
        df = self._clean_dataframe(df)
        tname = self._ensure_unique_table_name(self._sanitize_table_name(table_name))
        self.conn.execute(f'DROP TABLE IF EXISTS "{tname}"')
        self.conn.execute(f'CREATE TABLE "{tname}" AS SELECT * FROM df')
        self._register_metadata(tname, source_file, "", len(df), len(df.columns), list(df.columns),
                                 document_id=document_id, content_hash=content_hash, doc_version=doc_version)
        return tname

    # ─── Public: Query Execution ──────────────────────────────────────────

    def validate_sql(self, sql: str) -> Tuple[bool, str]:
        """Validate SQL for safety (SELECT only)."""
        sql_upper = sql.upper().strip()
        if not (sql_upper.startswith("SELECT") or sql_upper.startswith("WITH")):
            return False, "Only SELECT queries are allowed."
        for pattern in SQL_FORBIDDEN_PATTERNS:
            if re.search(pattern, sql_upper, re.IGNORECASE):
                return False, f"Forbidden pattern detected: {pattern}"
        return True, "OK"

    def validate_sql_schema(self, sql: str) -> Tuple[bool, str]:
        """
        PROBLEM 4 (SQL Validation): beyond the safety check in validate_sql()
        (SELECT-only, no forbidden keywords), verify that every table the
        generated SQL references actually exists, so a hallucinated table
        name is caught and routed to fallback *before* wasting a DuckDB
        execution attempt (and before a confusing raw DuckDB error reaches
        the user). Column-level checks are intentionally left to DuckDB's own
        execution error + the existing self-repair loop in query_service.py,
        since column references inside complex SQL (aliases, expressions,
        subqueries) are unreliable to parse generically without a real SQL
        parser — table names are not.
        """
        is_valid, reason = self.validate_sql(sql)
        if not is_valid:
            return is_valid, reason

        known_tables = {t.lower() for t in self.list_tables()}
        if not known_tables:
            return False, "No tables exist in DuckDB to query."

        # CTE names (WITH foo AS (...), bar AS (...) SELECT ..., including
        # WITH RECURSIVE) are not real DuckDB tables but are perfectly valid
        # FROM/JOIN targets within the same query — exclude them from the
        # unknown-table check, or every CTE-based query (e.g. the
        # window-function "top per group" pattern) would be falsely rejected.
        cte_names = {
            m.lower() for m in re.findall(
                r'(?:WITH(?:\s+RECURSIVE)?|,)\s*"?([a-zA-Z_][a-zA-Z0-9_]*)"?\s+AS\s*\(', sql, re.IGNORECASE
            )
        }

        # Pull identifiers following FROM/JOIN, stripping quotes. Also accept
        # an optional "schema." prefix (e.g. "main.employees") and validate
        # against the LAST segment — DuckDB's default/only schema in this
        # project is "main", and rejecting a fully-qualified reference to a
        # table that legitimately exists would be a false positive.
        referenced = re.findall(
            r'(?:FROM|JOIN)\s+(?:"?[a-zA-Z_][a-zA-Z0-9_]*"?\.)?"?([a-zA-Z_][a-zA-Z0-9_]*)"?',
            sql, re.IGNORECASE,
        )
        unknown = sorted({t for t in referenced if t.lower() not in known_tables and t.lower() not in cte_names})
        if unknown:
            return False, (
                f"SQL references table(s) not present in the schema: {', '.join(unknown)}. "
                f"Known tables: {', '.join(sorted(known_tables))}"
            )
        return True, "OK"

    def get_tables_by_document_id(self, document_id: str) -> List[Dict[str, Any]]:
        """PROBLEM 5: fetch only the tables belonging to one specific ingested
        document version, for isolation-scoped tabular queries."""
        self._init_registry()
        try:
            rows = self.conn.execute(
                "SELECT * FROM _rag_table_registry WHERE document_id = ?", [document_id]
            ).fetchall()
        except Exception as e:
            logger.error(f"get_tables_by_document_id failed: {e}")
            return []
        result = []
        for row in rows:
            tname, source_file, sheet_name, row_count, col_count, columns_json = row[:6]
            result.append({"table_name": tname, "source_file": source_file, "sheet_name": sheet_name,
                            "row_count": row_count, "col_count": col_count,
                            "columns": json.loads(columns_json or "[]")})
        return result

    def execute_query(self, sql: str) -> Dict[str, Any]:
        """Execute a validated SELECT query and return structured results."""
        is_valid, reason = self.validate_sql(sql)
        if not is_valid:
            logger.warning(f"SQL rejected: {reason} | SQL: {sql}")
            raise ValueError(f"Invalid SQL: {reason}")
        logger.info(f"Executing SQL: {sql}")
        try:
            result = self.conn.execute(sql).fetchdf()
            rows = result.to_dict(orient="records")
            for row in rows:
                for k, v in row.items():
                    if isinstance(v, float) and pd.isna(v):
                        row[k] = None
                    elif hasattr(v, "item"):
                        row[k] = v.item()
            logger.info(f"Query returned {len(rows)} row(s)")
            return {"columns": list(result.columns), "rows": rows,
                    "row_count": len(rows), "sql_executed": sql}
        except Exception as e:
            logger.error(f"SQL execution error: {e} | SQL: {sql}")
            raise RuntimeError(f"Query execution failed: {e}")

    # ─── Public: Introspection ─────────────────────────────────────────────

    def list_tables(self) -> List[str]:
        """List all user-created tables (excludes internal _rag_ registry tables)."""
        try:
            # Use starts_with() instead of LIKE ESCAPE to avoid SyntaxWarning in Python
            result = self.conn.execute(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = 'main' AND NOT starts_with(table_name, '_rag_')"
            ).fetchall()
            return [row[0] for row in result]
        except Exception as e:
            logger.error(f"list_tables failed: {e}")
            return []

    def get_schema(self, table_name: Optional[str] = None) -> str:
        """Return schema description for SQL generation prompt."""
        self._init_registry()
        try:
            query = "SELECT * FROM _rag_table_registry"
            params = []
            if table_name:
                query += " WHERE table_name = ?"
                params = [table_name]
            rows = self.conn.execute(query, params).fetchall()
        except Exception:
            rows = []

        if not rows:
            tables = self.list_tables()
            if not tables:
                return "No tabular data loaded."
            parts = []
            for t in tables:
                try:
                    cols = self.conn.execute(f'DESCRIBE "{t}"').fetchdf()
                    col_str = ", ".join(f"{r['column_name']} ({r['column_type']})" for _, r in cols.iterrows())
                    parts.append(f'Table: "{t}"\nColumns: {col_str}')
                except Exception:
                    parts.append(f'Table: "{t}" (schema unavailable)')
            return "\n\n".join(parts)

        parts = []
        for row in rows:
            tname, source_file, sheet_name, row_count, col_count, columns_json = row[:6]
            try:
                type_info = self.conn.execute(f'DESCRIBE "{tname}"').fetchdf()
                col_defs = [f"{r['column_name']} ({r['column_type']})" for _, r in type_info.iterrows()]
            except Exception:
                col_defs = json.loads(columns_json or "[]")
            source_label = Path(source_file).name if source_file else "unknown"
            sheet_label  = f" | Sheet: {sheet_name}" if sheet_name else ""
            parts.append(
                f'Table: "{tname}" | Source: {source_label}{sheet_label} | {row_count} rows\n'
                f'Columns: {", ".join(col_defs)}'
            )
        return "\n\n".join(parts)

    def get_table_info(self, table_name: str) -> Optional[Dict[str, Any]]:
        """Return metadata dict for a specific table."""
        self._init_registry()
        try:
            row = self.conn.execute(
                "SELECT * FROM _rag_table_registry WHERE table_name = ?", [table_name]
            ).fetchone()
            if not row:
                return None
            tname, source_file, sheet_name, row_count, col_count, columns_json = row[:6]
            return {"table_name": tname, "source_file": source_file, "sheet_name": sheet_name,
                    "row_count": row_count, "col_count": col_count, "columns": json.loads(columns_json or "[]")}
        except Exception as e:
            logger.error(f"get_table_info failed: {e}")
            return None

    def get_tables_by_source(self, source_name: str) -> List[Dict[str, Any]]:
        """
        Return all tables whose source_file basename matches source_name.
        Used by the delete-document flow to find all DuckDB tables for a file.
        """
        self._init_registry()
        try:
            rows = self.conn.execute(
                "SELECT * FROM _rag_table_registry"
            ).fetchall()
            result = []
            for row in rows:
                tname, source_file, sheet_name, row_count, col_count, columns_json = row[:6]
                if Path(source_file).name == source_name:
                    result.append({
                        "table_name":  tname,
                        "source_file": source_file,
                        "sheet_name":  sheet_name,
                        "row_count":   row_count,
                        "col_count":   col_count,
                        "columns":     json.loads(columns_json or "[]"),
                    })
            return result
        except Exception as e:
            logger.error(f"get_tables_by_source failed: {e}")
            return []

    def drop_table(self, table_name: str) -> bool:
        """Remove a table from DuckDB."""
        try:
            self.conn.execute(f'DROP TABLE IF EXISTS "{table_name}"')
            self._init_registry()
            self.conn.execute("DELETE FROM _rag_table_registry WHERE table_name = ?", [table_name])
            logger.info(f"Dropped table '{table_name}'")
            return True
        except Exception as e:
            logger.error(f"drop_table failed: {e}")
            return False

    def reset(self) -> None:
        """Drop all user tables and registry."""
        tables = self.list_tables()
        for t in tables:
            self.conn.execute(f'DROP TABLE IF EXISTS "{t}"')
        try:
            self.conn.execute("DROP TABLE IF EXISTS _rag_table_registry")
        except Exception:
            pass
        logger.info(f"DuckDB reset: dropped {len(tables)} table(s)")


    def get_schema_with_samples(self, table_name: Optional[str] = None, sample_rows: int = 5) -> tuple:
        """
        FIX v2: Return (schema_str, sample_rows_str) together.
        Providing sample rows to the SQL generator dramatically improves accuracy
        because the LLM can see actual values, not just column names.

        FIX v3: Two changes to prevent silently-wrong (not obviously broken) SQL on
        real-world datasets:
          1. Random sample instead of `LIMIT n` (insertion order). Many real files are
             sorted/grouped near the top (e.g. exported in a particular order, or
             generated in blocks) — a plain LIMIT can show the LLM rows that aren't
             representative of the whole table at all.
          2. Explicit distinct-value listing for low-cardinality columns (flags,
             categories, statuses). A tiny sample can easily miss an entire category —
             e.g. an imbalanced binary column where only one of {0, 1} appears in the
             first/sampled few rows — leaving the LLM to guess which value means what.
             That guess doesn't fail loudly; it just produces a confidently wrong
             answer (e.g. filtering the wrong half of a "who got admitted" question).
        """
        schema = self.get_schema(table_name)
        samples_parts = []
        tables = [table_name] if table_name else self.list_tables()
        for t in tables:
            try:
                try:
                    result = self.conn.execute(
                        f'SELECT * FROM "{t}" USING SAMPLE {sample_rows} ROWS (reservoir)'
                    ).fetchdf()
                    label = f"{sample_rows} random rows"
                except Exception:
                    # USING SAMPLE unsupported for this table/DuckDB build — fall back
                    result = self.conn.execute(f'SELECT * FROM "{t}" LIMIT {sample_rows}').fetchdf()
                    label = f"first {sample_rows} rows"
                sample_str = result.to_string(index=False, max_cols=None)
                samples_parts.append(f'Table "{t}" sample ({label}):\n{sample_str}')
            except Exception:
                pass

            try:
                distinct_block = self._distinct_value_hints(t)
                if distinct_block:
                    samples_parts.append(distinct_block)
            except Exception as e:
                logger.debug(f"Distinct-value hinting skipped for '{t}': {e}")

        return schema, "\n\n".join(samples_parts) if samples_parts else None

    def _distinct_value_hints(self, table_name: str, max_distinct: int = 15) -> Optional[str]:
        """
        For low-cardinality columns (binary flags, categories, statuses), list every
        distinct value that actually occurs, so the SQL-generation LLM never has to
        guess semantics from a small sample (e.g. whether 0 or 1 means "admitted",
        or the exact spelling/casing of a status string like "Active" vs "active").
        Uses approx_count_distinct() first (cheap, HLL-based) so this stays fast even
        on multi-million-row tables — the exact-value fetch only runs for columns that
        already look low-cardinality.
        """
        cols = self.conn.execute(f'DESCRIBE "{table_name}"').fetchdf()
        lines = []
        for _, r in cols.iterrows():
            col, ctype = r["column_name"], str(r["column_type"]).upper()
            if not any(t in ctype for t in ("VARCHAR", "BOOL", "TINYINT", "SMALLINT", "INTEGER", "BIGINT")):
                continue
            try:
                approx = self.conn.execute(
                    f'SELECT approx_count_distinct("{col}") FROM "{table_name}"'
                ).fetchone()[0]
            except Exception:
                continue
            if approx is None or approx == 0 or approx > max_distinct:
                continue
            try:
                vals = self.conn.execute(
                    f'SELECT DISTINCT "{col}" FROM "{table_name}" '
                    f'WHERE "{col}" IS NOT NULL ORDER BY 1 LIMIT {max_distinct}'
                ).fetchall()
            except Exception:
                continue
            if vals:
                lines.append(f'  {col}: {", ".join(str(v[0]) for v in vals)}')

        if not lines:
            return None
        return (
            f'Table "{table_name}" — every distinct value for its low-cardinality '
            f'columns (use these exact values in WHERE/filter conditions):\n' + "\n".join(lines)
        )

    def close(self) -> None:
        """Close the DuckDB connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
