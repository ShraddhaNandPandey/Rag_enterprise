"""
loaders/file_loader.py — Multi-format document loader.

Routes files by extension:
  - PDF   → layout-aware parsing (PART 1): paragraphs/headings/lists/captions
            go out as text docs for ChromaDB; detected tables go out as
            PDF_TABLE_MARKER docs (handled by DuckDB, see PART 3/4). Falls
            back to plain pypdf extract_text() automatically if pdfplumber
            is unavailable or parsing fails (PART 10 backward compatibility).
  - DOCX, PPTX, TXT, MD       → extracted as text docs (for ChromaDB), unchanged
  - CSV, XLSX, XLS, TSV       → marked TABULAR_MARKER (handled by DuckDB), unchanged
  - Images (jpg/png/etc.)     → OCR'd into text docs, unchanged

Returns a flat list of dicts: {"text": str, "metadata": dict}
Tabular files return {"text": TABULAR_MARKER, "metadata": {"source": path, "type": ext}}
PDF tables return  {"text": PDF_TABLE_MARKER, "metadata": {..., "rows": [[...]]}}
"""

from pathlib import Path
from typing import Any, Dict, List, Set

from config.settings import (
    TABULAR_EXTENSIONS, IMAGE_EXTENSIONS, PDF_TEXT_MIN_LEN,
    ENABLE_PDF_LAYOUT_PARSING, PDF_TABLE_MIN_ROWS,
)
from utils.logger import get_logger
from utils.doc_identity import get_document_identity

logger = get_logger("loaders")

TABULAR_MARKER = "__TABULAR__"
# PART 3/4: a detected PDF table is handed off the same way a CSV/XLSX file
# is — as a special-marker doc that ingestion_service.py routes to DuckDB
# instead of the chunker/embedder.
PDF_TABLE_MARKER = "__PDF_TABLE__"


def load_files(file_paths: List[str]) -> List[Dict[str, Any]]:
    """Load a list of files, routing each to the appropriate loader.

    PROBLEM 5 (Document Isolation): every doc's metadata is stamped here with
    a stable document_id + content_hash + version, computed once per file.
    This is the single choke point all loaders funnel through, so every
    downstream consumer (chunker, ChromaDB metadata, DuckDB registry) gets
    these fields "for free" without each individual loader needing to know
    about identity/hashing.
    """
    all_docs: List[Dict[str, Any]] = []
    for path in file_paths:
        try:
            docs = load_single_file(path)
        except Exception as e:
            logger.error(f"Failed to load '{path}': {e}", exc_info=True)
            continue

        try:
            identity = get_document_identity(path)
        except Exception as e:
            # Identity computation must never block ingestion — worst case,
            # documents simply don't get isolation metadata this run.
            logger.warning(f"Could not compute document identity for '{path}': {e}")
            identity = None

        if identity:
            if identity.get("is_duplicate_content"):
                logger.info(
                    f"'{Path(path).name}' has identical content to a previous ingestion "
                    f"(document_id={identity['document_id']}) — re-ingesting will refresh, "
                    f"not duplicate, its stored chunks/tables."
                )
            for d in docs:
                meta = d.setdefault("metadata", {})
                meta.setdefault("document_id", identity["document_id"])
                meta.setdefault("content_hash", identity["content_hash"])
                meta.setdefault("doc_version", identity["version"])

        all_docs.extend(docs)
    return all_docs


def load_single_file(path: str) -> List[Dict[str, Any]]:
    """Load one file and return a list of doc dicts (usually one per page/slide/sheet)."""
    p = Path(path)
    ext = p.suffix.lower()
    name = p.name

    if ext in TABULAR_EXTENSIONS:
        ftype = ext.lstrip(".")
        return [{
            "text": TABULAR_MARKER,
            "metadata": {"source": str(p), "source_name": name, "type": ftype},
        }]

    if ext in IMAGE_EXTENSIONS:
        return _load_image(p)

    if ext == ".pdf":
        return _load_pdf(p)

    if ext in (".docx", ".doc"):
        return _load_docx(p)

    if ext == ".pptx":
        return _load_pptx(p)

    if ext in (".txt", ".md"):
        return _load_text(p)

    logger.warning(f"Unsupported extension '{ext}' for file '{name}', skipping.")
    return []


# ─── PDF ──────────────────────────────────────────────────────────────────────

def _load_pdf(p: Path) -> List[Dict[str, Any]]:
    """
    PART 1: Layout-aware PDF parsing.

    Tries pdfplumber-based layout parsing first, which separates paragraphs /
    headings / lists / captions from tables (PART 1/3). Detected tables come
    back as PDF_TABLE_MARKER docs for DuckDB (PART 3/4); everything else is a
    normal text doc for the existing chunker/embedder (PART 2), unchanged in
    shape from before.

    Falls back to the original plain pypdf extract_text() path whenever
    layout parsing is disabled, unavailable, or yields nothing usable — PDF
    ingestion can only ever improve, never regress (PART 10).
    """
    if ENABLE_PDF_LAYOUT_PARSING:
        try:
            from loaders.pdf_layout_parser import layout_parse_pdf
            blocks = layout_parse_pdf(p)
        except Exception as e:
            logger.warning(
                f"Layout-aware PDF parsing errored for '{p.name}', "
                f"falling back to plain text extraction: {e}"
            )
            blocks = None

        if blocks:
            total_pages = _get_pdf_page_count(p)
            docs = _blocks_to_docs(p, blocks, total_pages)
            if docs:
                return docs
            logger.info(
                f"Layout parser returned no usable content for '{p.name}', "
                f"falling back to plain text extraction."
            )

    return _load_pdf_legacy(p)


def _get_pdf_page_count(p: Path) -> int:
    """Cheap page count (no rendering) — used so _blocks_to_docs can iterate
    every page, not just the ones the layout parser happened to find text
    blocks on. Returns 0 on failure (caller degrades to the old behaviour:
    only pages with blocks get processed)."""
    try:
        from pypdf import PdfReader
        return len(PdfReader(str(p)).pages)
    except Exception as e:
        logger.debug(f"Could not get page count for '{p.name}': {e}")
        return 0


def _blocks_to_docs(p: Path, blocks: List[Dict[str, Any]], total_pages: int = 0) -> List[Dict[str, Any]]:
    """
    Turn layout-parser blocks into the doc list the rest of the pipeline
    expects: one merged text doc per page (paragraphs/headings/lists/captions
    joined, same shape as the legacy loader's per-page text doc) plus one
    PDF_TABLE_MARKER doc per detected table (PART 3/6).

    BUGFIX (mixed real-text + scanned PDFs silently dropping scanned pages):
    previously `pages` was derived only from `{b["page"] for b in blocks}` —
    i.e. only pages the layout parser found at least one block on. A page
    that is ENTIRELY a scanned image (no extractable text, no detected
    table) never produced a block, so it never appeared in `pages`, so the
    "page produced nothing at all, try OCR" branch below never actually ran
    for it — despite being written as if it would. A fully-scanned PDF still
    worked (zero blocks overall correctly falls back to `_load_pdf_legacy`,
    which iterates every page unconditionally), but a mix of real-text pages
    and scanned pages in the SAME PDF silently lost the scanned pages. Now
    `pages` covers every page in the document (1..total_pages) whenever the
    caller can supply that count, so every page-with-zero-blocks still hits
    the OCR fallback below.

    PHASE 2: blocks now arrive in TRUE top-to-bottom reading order (see
    pdf_layout_parser._parse_page), with headings carrying a "level" (1 =
    section title, 2 = sub-heading). This lets metadata track a genuine
    two-level hierarchy matching PART 6's example
    ({"section": "Payroll", "heading": "Salary Structure", ...}) instead of
    Phase 1's single flat "nearest heading" value:
      - `section`        — nearest level-1 heading seen so far (any page)
      - `heading`        — nearest heading at ANY level (most specific)
      - `parent_section` — the enclosing level-1 section for a level-2
                            heading ("" for a level-1 heading itself)
    """
    docs: List[Dict[str, Any]] = []
    pages_with_blocks = {b["page"] for b in blocks}
    pages = sorted(pages_with_blocks | set(range(1, total_pages + 1)))

    # Running hierarchy state — persists across pages (not reset per page) so
    # a table/paragraph on a page with no heading of its own still inherits
    # the section it visually belongs to (PART 6: "Parent Section").
    running_section = ""
    running_heading = ""
    running_parent = ""
    table_counter = 0

    for page_num in pages:
        page_blocks = [b for b in blocks if b["page"] == page_num]
        text_parts: List[str] = []
        block_types_seen: Set[str] = set()

        for b in page_blocks:
            btype = b["type"]
            block_types_seen.add(btype)

            if btype == "table":
                rows = b["rows"]
                data_row_count = len(rows) - 1  # excluding header row
                if data_row_count < PDF_TABLE_MIN_ROWS:
                    # Too small to justify its own DuckDB table + summary —
                    # fold it back into page text as simple delimited rows
                    # rather than silently dropping content (PART 10).
                    text_parts.append("\n".join(" | ".join(cell for cell in row) for row in rows))
                    continue

                table_counter += 1
                docs.append({
                    "text": PDF_TABLE_MARKER,
                    "metadata": {
                        "source": str(p),
                        "source_name": p.name,
                        "type": "pdf_table",
                        "page": page_num,
                        "block_type": "table",
                        "heading": running_heading,
                        "section": running_section,
                        "parent_section": running_parent,
                        "table_index": table_counter,
                        "rows": rows,
                    },
                })
                continue

            if btype == "heading":
                heading_text = b["text"].strip().splitlines()[0]
                level = b.get("level", 2)
                if level == 1:
                    running_section = heading_text
                    running_heading = heading_text
                    running_parent = ""  # a top-level section has no parent
                else:
                    running_heading = heading_text
                    running_parent = running_section

            text_parts.append(b["text"])

        page_text = "\n\n".join(text_parts).strip()
        if page_text:
            docs.append({
                "text": page_text,
                "metadata": {
                    "source": str(p),
                    "source_name": p.name,
                    "type": "pdf",
                    "page": page_num,
                    "heading": running_heading,
                    "section": running_section,
                    "parent_section": running_parent,
                    "block_types": sorted(block_types_seen - {"table"}),
                },
            })
        elif "table" not in block_types_seen:
            # Page produced nothing at all — likely a scanned page. Same OCR
            # fallback the legacy loader used, so scanned PDFs behave
            # identically whether layout parsing is on or off (PART 10).
            ocr_text = _ocr_pdf_page(p, page_num)
            if ocr_text and ocr_text.strip():
                docs.append({
                    "text": ocr_text.strip(),
                    "metadata": {
                        "source": str(p), "source_name": p.name,
                        "type": "pdf", "page": page_num,
                    },
                })

    return docs


def _load_pdf_legacy(p: Path) -> List[Dict[str, Any]]:
    """Original plain-text extraction path (pypdf extract_text()). Falls back
    to OCR for pages with little/no text. Kept behaviourally identical to the
    pre-audit implementation so PDF ingestion never regresses (PART 10)."""
    docs: List[Dict[str, Any]] = []
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(p))
        for i, page in enumerate(reader.pages, 1):
            try:
                text = page.extract_text() or ""
            except Exception as e:
                logger.warning(f"PDF page {i} extraction failed for '{p.name}': {e}")
                text = ""

            text = text.strip()

            if len(text) < PDF_TEXT_MIN_LEN:
                # Likely a scanned page — try OCR fallback
                ocr_text = _ocr_pdf_page(p, i)
                if ocr_text and len(ocr_text.strip()) > len(text):
                    text = ocr_text.strip()

            if text:
                docs.append({
                    "text": text,
                    "metadata": {
                        "source": str(p),
                        "source_name": p.name,
                        "type": "pdf",
                        "page": i,
                    },
                })
    except Exception as e:
        logger.error(f"Failed to read PDF '{p.name}': {e}", exc_info=True)

    return docs


def _ocr_pdf_page(p: Path, page_num: int) -> str:
    """OCR a single PDF page by rasterizing it to an image first."""
    try:
        from pdf2image import convert_from_path
        from config.settings import OCR_DPI

        images = convert_from_path(
            str(p), dpi=OCR_DPI, first_page=page_num, last_page=page_num
        )
        if not images:
            return ""

        from ocr.ocr_engine import OCREngine
        from config.settings import OCR_ENGINE, LLAVA_MODEL, TROCR_MODEL

        engine = OCREngine(engine=OCR_ENGINE, llava_model=LLAVA_MODEL, trocr_model=TROCR_MODEL)
        return engine.extract_text(images[0])
    except Exception as e:
        logger.warning(f"OCR fallback failed for '{p.name}' page {page_num}: {e}")
        return ""


# ─── DOCX ─────────────────────────────────────────────────────────────────────

def _load_docx(p: Path) -> List[Dict[str, Any]]:
    """Extract all paragraph and table text from a Word document as a single doc."""
    try:
        import docx
        document = docx.Document(str(p))

        parts = []
        for para in document.paragraphs:
            if para.text.strip():
                parts.append(para.text.strip())

        for table in document.tables:
            for row in table.rows:
                row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                if row_text:
                    parts.append(row_text)

        full_text = "\n".join(parts)
        if not full_text.strip():
            return []

        return [{
            "text": full_text,
            "metadata": {"source": str(p), "source_name": p.name, "type": "docx"},
        }]
    except Exception as e:
        logger.error(f"Failed to read DOCX '{p.name}': {e}", exc_info=True)
        return []


# ─── PPTX ─────────────────────────────────────────────────────────────────────

def _load_pptx(p: Path) -> List[Dict[str, Any]]:
    """Extract text per-slide from a PowerPoint file."""
    docs: List[Dict[str, Any]] = []
    try:
        from pptx import Presentation
        prs = Presentation(str(p))

        for i, slide in enumerate(prs.slides, 1):
            parts = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        text = "".join(run.text for run in para.runs).strip()
                        if text:
                            parts.append(text)
                if shape.has_table:
                    for row in shape.table.rows:
                        row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                        if row_text:
                            parts.append(row_text)

            # Speaker notes
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                notes = slide.notes_slide.notes_text_frame.text.strip()
                if notes:
                    parts.append(f"[Notes: {notes}]")

            slide_text = "\n".join(parts).strip()
            if slide_text:
                docs.append({
                    "text": slide_text,
                    "metadata": {
                        "source": str(p),
                        "source_name": p.name,
                        "type": "pptx",
                        "slide": i,
                    },
                })
    except Exception as e:
        logger.error(f"Failed to read PPTX '{p.name}': {e}", exc_info=True)

    return docs


# ─── Plain text / Markdown ────────────────────────────────────────────────────

def _load_text(p: Path) -> List[Dict[str, Any]]:
    """Load a plain text or markdown file."""
    try:
        text = p.read_text(encoding="utf-8", errors="ignore").strip()
        if not text:
            return []
        ftype = "markdown" if p.suffix.lower() == ".md" else "text"
        return [{
            "text": text,
            "metadata": {"source": str(p), "source_name": p.name, "type": ftype},
        }]
    except Exception as e:
        logger.error(f"Failed to read text file '{p.name}': {e}", exc_info=True)
        return []


# ─── Images ───────────────────────────────────────────────────────────────────

def _load_image(p: Path) -> List[Dict[str, Any]]:
    """Run OCR on an image file and return extracted text as a doc."""
    try:
        from PIL import Image
        from ocr.ocr_engine import OCREngine
        from config.settings import OCR_ENGINE, LLAVA_MODEL, TROCR_MODEL

        image = Image.open(str(p))
        engine = OCREngine(engine=OCR_ENGINE, llava_model=LLAVA_MODEL, trocr_model=TROCR_MODEL)
        text = engine.extract_text(image)

        if not text or not text.strip():
            logger.warning(f"No text extracted from image '{p.name}'")
            return []

        return [{
            "text": text.strip(),
            "metadata": {"source": str(p), "source_name": p.name, "type": "image"},
        }]
    except Exception as e:
        logger.error(f"Failed to OCR image '{p.name}': {e}", exc_info=True)
        return []
