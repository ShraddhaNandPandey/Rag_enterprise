"""
loaders/pdf_layout_parser.py — Layout-aware PDF parsing (PART 1 of the RAG audit).

WHY THIS EXISTS
----------------
The original PDF loader called pypdf's `page.extract_text()`, which flattens
every element on a page — headings, paragraphs, and table cells alike — into
one blob of plain text, in reading order determined by pypdf's internal text
stream walk. Table rows/columns collapse into disconnected lines, so
relationships between cells are lost before the chunker or embedder ever see
the page.

This module adds a second, optional parsing path that classifies each page
into typed blocks (heading / paragraph / list / caption / footer / table)
using pdfplumber, which exposes both text *and* geometric table detection.
Tables are extracted as row/column grids (PART 3) instead of prose.

PHASE 2 — HEADING/SECTION DETECTION
-------------------------------------
Phase 1 classified headings using text-only heuristics (line length, ending
punctuation, casing) and force-ordered all text blocks before tables on a
page, regardless of true vertical position. Phase 2 replaces the primary
signal with actual typography, read from pdfplumber's character-level data:

  - Body font size is estimated per page (the size covering the most
    characters), then each line's font size relative to that baseline
    decides whether it's a heading, and if so, which of two levels:
      level 1 ("section")  — a clearly larger and/or bold title line
      level 2 ("heading")  — a moderately emphasised sub-heading line
  - Lines (including table regions) are placed in TRUE top-to-bottom
    reading order via their vertical position, instead of the Phase 1
    "all text before all tables" approximation — so a table's nearest
    preceding heading is now an actual position match, not a guess.
  - The old text-only heuristics (`_is_heading_line` / `_classify_text_block`)
    are kept as a second-pass fallback for lines with no usable font
    signal (e.g. a heading rendered at body size but numbered "1.2 ..."),
    and as the sole classifier when a page has no extractable character
    metadata at all (rare — usually a sign of a scanned/rasterised page,
    which the OCR fallback path handles anyway).

This produces a genuine two-level section hierarchy matching the metadata
shape requested in PART 6 of the audit (`"section": "Payroll", "heading":
"Salary Structure"`), instead of Phase 1's single flat "nearest heading".

BACKWARD COMPATIBILITY (PART 10)
---------------------------------
- If pdfplumber is not installed, or fails to open/parse a PDF, this module
  returns None and the caller (`loaders/file_loader.py`) transparently falls
  back to the original pypdf `extract_text()` path. PDF ingestion therefore
  never regresses — it can only improve when pdfplumber is available.
- If a page has table geometry but no usable character/font data, this
  module falls back to the Phase 1 text-only classification for that page
  rather than losing content.
- This module has ZERO dependents outside `loaders/file_loader.py`. Nothing
  else in the project imports it directly.

DESIGN NOTES
------------
- Table/paragraph separation: every table found via `page.find_tables()` is
  excluded before line/paragraph extraction, so a table's cell text is never
  duplicated as paragraph prose.
- Block classification is a set of cheap, explainable heuristics (font size/
  boldness + regex) — no extra ML model, no network call, keeps ingestion
  fast and fully offline (PART 9: performance).
"""

import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from utils.logger import get_logger

logger = get_logger("pdf_layout")

_HEADING_NUMBERED_RE = re.compile(r"^(chapter|section|part)\s+\d+|^\d+(\.\d+)*\s+[A-Z]", re.IGNORECASE)
_CAPTION_RE = re.compile(r"^(figure|table|fig\.|chart)\s*\d*[:.]", re.IGNORECASE)
_LIST_ITEM_RE = re.compile(r"^\s*([-•*\u2022]|\d+[.)])\s+")
_FOOTER_HINTS = ("page ", "confidential", "copyright", "©", "all rights reserved")
_BOLD_HINTS = ("bold", "black", "heavy", "semibold", "demibold")

# Font-size ratios (relative to the page's estimated body-text size) that
# distinguish a level-1 ("section") heading and a level-2 ("heading") from
# ordinary body text. Tuned to be forgiving of PDF generators that only
# bump size slightly, while still requiring a real, deliberate size jump.
_SECTION_SIZE_RATIO = 1.35
_HEADING_SIZE_RATIO = 1.12
# A same-size-as-body but BOLD line is still treated as a (level-2) heading
# candidate, provided it's short enough to plausibly be a title, not a bolded
# sentence fragment inside a paragraph.
_BOLD_HEADING_MAX_CHARS = 80


def layout_parse_pdf(path: Path) -> Optional[List[Dict[str, Any]]]:
    """
    Parse a PDF into layout-aware blocks.

    Returns a flat list of blocks (each tagged with its page number), e.g.:
        {"type": "heading",   "page": 3, "text": "Salary Structure"}
        {"type": "paragraph", "page": 3, "text": "..."}
        {"type": "table",     "page": 3, "rows": [[...], [...], ...]}

    Returns None (not an empty list) if pdfplumber is unavailable or the file
    could not be opened at all — this distinguishes "layout parsing wasn't
    possible, fall back" from "the PDF was parsed but genuinely has no
    content", which the caller needs to tell apart.
    """
    try:
        import pdfplumber
    except ImportError:
        logger.info(
            "pdfplumber not installed — layout-aware PDF table parsing is disabled. "
            "Falling back to plain-text extraction. Install with: pip install pdfplumber"
        )
        return None

    blocks: List[Dict[str, Any]] = []
    try:
        with pdfplumber.open(str(path)) as pdf:
            for page_num, page in enumerate(pdf.pages, 1):
                try:
                    blocks.extend(_parse_page(page, page_num))
                except Exception as e:
                    # One bad page must not sink the whole document — skip it,
                    # the per-page OCR fallback in file_loader.py will pick up
                    # anything genuinely unreadable.
                    logger.warning(f"Layout parse failed on page {page_num} of '{path.name}': {e}")
        blocks = _merge_multipage_tables(blocks)
        return blocks
    except Exception as e:
        logger.warning(f"pdfplumber could not open '{path.name}': {e} — falling back to plain text extraction.")
        return None


# ── PROBLEM 12: multi-page table detection/merging ─────────────────────────

def _row_signature(row: List[str]) -> Tuple[int, ...]:
    """A cheap structural fingerprint of a row: which cells are non-empty,
    used to compare header/column shape across pages without depending on
    exact text (numbers/values differ row to row, but shape doesn't)."""
    return tuple(1 if str(c).strip() else 0 for c in row)


def _tables_look_continuous(prev_table: Dict[str, Any], next_table: Dict[str, Any]) -> bool:
    """
    Heuristic: two tables on consecutive pages are the same logical table,
    split by a PDF page break, when they have the same column count AND
    either the same header row text, or the "header" of the second table is
    actually indistinguishable from a data row (i.e. no page repeats a
    header at all — a strong continuation signal for exports/reports).
    """
    prev_rows = prev_table.get("rows") or []
    next_rows = next_table.get("rows") or []
    if not prev_rows or not next_rows:
        return False

    prev_cols = len(prev_rows[0])
    next_cols = len(next_rows[0])
    if prev_cols == 0 or prev_cols != next_cols:
        return False

    prev_header = [str(c).strip().lower() for c in prev_rows[0]]
    next_header = [str(c).strip().lower() for c in next_rows[0]]

    if prev_header == next_header:
        # Same header repeated on the next page — classic multi-page table.
        return True

    # No repeated header: only merge if the two tables are on ADJACENT pages
    # (checked by the caller) and column counts match — a same-width table
    # immediately continuing is a much stronger signal than shape alone, so
    # this branch stays conservative and lets the caller's adjacency check
    # do the rest of the work.
    return True


def _merge_multipage_tables(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Detect tables that are split across consecutive PDF pages and merge them
    into one logical table block before ingestion (PROBLEM 12), so a table
    that happens to break across a page boundary is treated — and chunked/
    summarized/loaded into DuckDB — as the single table it actually is,
    rather than two unrelated smaller tables.

    Merge condition (deliberately conservative to avoid false merges):
      - The earlier table is the LAST block on its page (nothing else came
        after it — i.e. the page break landed mid-table, not after other
        content).
      - The later table is the FIRST block on the very next page.
      - Both tables have the same column count.
      - If the later table's first row duplicates the earlier table's header
        row, that repeated header is dropped from the merged result (a
        common PDF-export convention: repeat the header on every page).
    """
    if not blocks:
        return blocks

    merged: List[Dict[str, Any]] = []
    i = 0
    while i < len(blocks):
        block = blocks[i]
        if block.get("type") != "table":
            merged.append(block)
            i += 1
            continue

        # Is this table the last block on its page?
        is_last_on_page = (i == len(blocks) - 1) or (blocks[i + 1].get("page") != block.get("page"))
        run_rows = list(block.get("rows") or [])
        run_pages = [block.get("page")]
        j = i + 1

        while is_last_on_page and j < len(blocks):
            nxt = blocks[j]
            is_first_on_its_page = (j == 0) or (blocks[j - 1].get("page") != nxt.get("page"))
            is_next_page = nxt.get("page") == run_pages[-1] + 1
            if (
                is_first_on_its_page and is_next_page and nxt.get("type") == "table"
                and _tables_look_continuous({"rows": run_rows}, nxt)
            ):
                next_rows = list(nxt.get("rows") or [])
                if next_rows and run_rows and _row_signature(next_rows[0]) == _row_signature(run_rows[0]) \
                        and [str(c).strip().lower() for c in next_rows[0]] == \
                            [str(c).strip().lower() for c in run_rows[0]]:
                    next_rows = next_rows[1:]  # drop repeated header
                run_rows.extend(next_rows)
                run_pages.append(nxt.get("page"))
                is_last_on_page = (j + 1 == len(blocks)) or (blocks[j + 1].get("page") != nxt.get("page"))
                j += 1
            else:
                break

        if len(run_pages) > 1:
            logger.info(f"Merged multi-page table spanning pages {run_pages} into one logical table "
                        f"({len(run_rows)} total rows)")
            merged_block = dict(block)
            merged_block["rows"] = run_rows
            merged_block["page"] = run_pages[0]
            merged_block["page_range"] = run_pages
            merged.append(merged_block)
        else:
            merged.append(block)

        i = j if len(run_pages) > 1 else i + 1

    return merged


def _parse_page(page, page_num: int) -> List[Dict[str, Any]]:
    """
    Extract typed blocks for a single page, in TRUE top-to-bottom reading
    order (tables interleaved with text by actual vertical position, not
    forced before/after each other).
    """
    # ── 1. Tables (PART 3: preserve row/column structure) ──────────────────
    table_bboxes: List[Tuple[float, float, float, float]] = []
    table_blocks: List[Dict[str, Any]] = []
    try:
        found_tables = page.find_tables()
    except Exception:
        found_tables = []

    for t in found_tables:
        try:
            raw_rows = t.extract()
        except Exception:
            raw_rows = None
        if not raw_rows:
            continue

        rows = [[("" if cell is None else str(cell).strip()) for cell in row] for row in raw_rows]
        rows = [r for r in rows if any(cell for cell in r)]  # drop fully-blank rows

        # A 1-row or 1-column grid is almost never a real table (usually a
        # mis-detected text box) — skip it and let it fall through as prose.
        if len(rows) < 2 or len(rows[0]) < 2:
            continue

        table_bboxes.append(t.bbox)
        table_blocks.append({"type": "table", "page": page_num, "rows": rows, "_top": t.bbox[1]})

    # ── 2. Font-aware line extraction, table regions excluded ──────────────
    try:
        lines = _extract_lines(page, table_bboxes)
    except Exception as e:
        logger.warning(f"Font-aware line extraction failed on page {page_num}: {e}")
        lines = []

    if lines:
        text_blocks = _lines_to_blocks(lines, page_num)
    else:
        # No usable character/font data (rare) — fall back to the Phase 1
        # text-only path so this page never yields less content than before.
        text_blocks = _fallback_text_blocks(page, table_bboxes, page_num)

    # ── 3. Merge into true top-to-bottom order ───────────────────────────────
    combined = sorted(text_blocks + table_blocks, key=lambda b: b.get("_top", 0.0))
    for b in combined:
        b.pop("_top", None)
    return combined


def _extract_lines(page, table_bboxes: List[Tuple[float, float, float, float]]) -> List[Dict[str, Any]]:
    """
    Group words (with font size/name) into lines, excluding any word that
    falls inside a detected table's bounding box. Returns lines sorted by
    vertical position (top-to-bottom, then left-to-right).
    """
    try:
        words = page.extract_words(extra_attrs=["size", "fontname"], keep_blank_chars=False)
    except Exception:
        words = []
    if not words:
        return []

    def _in_table(w) -> bool:
        cx, cy = (w["x0"] + w["x1"]) / 2, (w["top"] + w["bottom"]) / 2
        for (x0, top, x1, bottom) in table_bboxes:
            if x0 <= cx <= x1 and top <= cy <= bottom:
                return True
        return False

    words = [w for w in words if not _in_table(w)]
    if not words:
        return []

    words.sort(key=lambda w: (round(w["top"]), w["x0"]))

    lines: List[Dict[str, Any]] = []
    current: List[Dict[str, Any]] = []
    current_top = None
    for w in words:
        if current_top is None or abs(w["top"] - current_top) <= 3:
            current.append(w)
            current_top = w["top"] if current_top is None else current_top
        else:
            lines.append(_words_to_line(current))
            current = [w]
            current_top = w["top"]
    if current:
        lines.append(_words_to_line(current))

    lines.sort(key=lambda ln: ln["top"])
    return lines


def _words_to_line(words: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Collapse a list of same-line words into one line record with the
    line's dominant font size and whether it's predominantly bold."""
    words = sorted(words, key=lambda w: w["x0"])
    text = " ".join(w["text"] for w in words).strip()
    sizes = [w.get("size", 0) or 0 for w in words]
    fontnames = [str(w.get("fontname", "")).lower() for w in words]
    size = max(sizes) if sizes else 0.0
    bold = any(any(h in fn for h in _BOLD_HINTS) for fn in fontnames)
    return {
        "text": text,
        "top": min(w["top"] for w in words),
        "bottom": max(w["bottom"] for w in words),
        "size": size,
        "bold": bold,
    }


def _estimate_body_size(lines: List[Dict[str, Any]]) -> float:
    """
    Estimate the page's body-text font size: the size (rounded to the
    nearest 0.5pt) that covers the most characters. Falls back to the
    median line size if there's no clear majority (e.g. a very short page).
    """
    if not lines:
        return 0.0
    counts: Counter = Counter()
    for ln in lines:
        counts[round(ln["size"] * 2) / 2] += len(ln["text"])
    if not counts:
        return 0.0
    return counts.most_common(1)[0][0]


def _lines_to_blocks(lines: List[Dict[str, Any]], page_num: int) -> List[Dict[str, Any]]:
    """
    Classify each line as heading (level 1/2) via font size/boldness, then
    merge consecutive non-heading lines into paragraph-sized blocks (using
    vertical gap as the paragraph-break signal), applying the Phase 1
    text-only classifier/heading-line fallback to each merged group.
    """
    body_size = _estimate_body_size(lines)
    blocks: List[Dict[str, Any]] = []
    buffer: List[Dict[str, Any]] = []

    def _flush_buffer():
        if not buffer:
            return
        text = "\n".join(ln["text"] for ln in buffer)
        top = buffer[0]["top"]
        for sub in _decompose_block(text, page_num):
            sub["_top"] = top
            blocks.append(sub)
        buffer.clear()

    prev_bottom = None
    for ln in lines:
        gap = (ln["top"] - prev_bottom) if prev_bottom is not None else 0
        line_height = max(ln["bottom"] - ln["top"], 1.0)
        is_new_paragraph_gap = prev_bottom is not None and gap > line_height * 1.4

        level = _font_heading_level(ln, body_size)
        if level:
            _flush_buffer()
            blocks.append({
                "type": "heading", "page": page_num, "text": ln["text"].strip(),
                "level": level, "_top": ln["top"],
            })
        else:
            if is_new_paragraph_gap:
                _flush_buffer()
            buffer.append(ln)
        prev_bottom = ln["bottom"]

    _flush_buffer()
    return blocks


def _font_heading_level(line: Dict[str, Any], body_size: float) -> Optional[int]:
    """
    Font-based heading level for a single line: 1 (section), 2 (heading),
    or None (ordinary body text). Falls back to `_is_heading_line`'s
    text-only signal when body_size couldn't be estimated (e.g. every line
    on the page shares one font size, so there's no relative signal).
    """
    text = line["text"].strip()
    if not text or len(text) >= 120:
        return None

    if body_size > 0:
        ratio = line["size"] / body_size if body_size else 1.0
        if ratio >= _SECTION_SIZE_RATIO:
            return 1
        if ratio >= _HEADING_SIZE_RATIO:
            return 2
        if line["bold"] and ratio >= 0.98 and len(text) <= _BOLD_HEADING_MAX_CHARS and not text.endswith((".", ",", ";")):
            return 2
        return None

    # No reliable body-size baseline — fall back to the Phase 1 text-only
    # heuristic, treated as a level-2 heading by default.
    return 2 if _is_heading_line(text) else None


def _fallback_text_blocks(page, table_bboxes, page_num: int) -> List[Dict[str, Any]]:
    """Phase 1 text-only path, used only when a page has no extractable
    character/font metadata at all (rare)."""
    try:
        remaining_text = _extract_text_outside_tables(page, table_bboxes)
    except Exception:
        remaining_text = page.extract_text() or ""

    blocks: List[Dict[str, Any]] = []
    for para in _split_paragraphs(remaining_text):
        for sub in _decompose_block(para, page_num):
            sub["_top"] = 0.0  # unknown position — sorts to the top of the page
            blocks.append(sub)
    return blocks


def _extract_text_outside_tables(page, table_bboxes: List[tuple]) -> str:
    """Return page text with every detected table's bounding box excluded."""
    if not table_bboxes:
        return page.extract_text() or ""
    region = page
    for bbox in table_bboxes:
        region = region.outside_bbox(bbox)
    return region.extract_text() or ""


def _split_paragraphs(text: str) -> List[str]:
    """Split raw page text into paragraph-sized blocks on blank lines."""
    if not text or not text.strip():
        return []
    parts = re.split(r"\n\s*\n", text.strip())
    return [p.strip() for p in parts if p.strip()]


def _is_heading_line(line: str) -> bool:
    """Single-line heading heuristic, reused both for whole-block and
    leading-line-within-a-block heading detection."""
    if not line or len(line) >= 80:
        return False
    if line.endswith((".", ",", ";", ":")):
        return False
    return bool(line.isupper() or _HEADING_NUMBERED_RE.match(line) or line[:1].isupper())


def _heading_level_for_text(line: str) -> int:
    """
    Level for a regex-detected heading (used when there's no font-size
    signal to rely on): ALL CAPS or an explicit "Chapter/Section/Part N" /
    numbered heading reads as a level-1 section title; anything else
    heading-shaped is treated as a level-2 sub-heading.
    """
    return 1 if (line.isupper() or _HEADING_NUMBERED_RE.match(line)) else 2


def _decompose_block(raw: str, page_num: int) -> List[Dict[str, Any]]:
    """
    Split a paragraph-sized text block into typed sub-blocks. Many real PDFs
    (and generators that don't insert a blank line before a title) place a
    heading directly above body text with no blank-line gap, so — in
    addition to whole-block classification via `_classify_text_block` — this
    pulls any heading-shaped line(s) at the START of a block out as their own
    "heading" block(s), leaving the remainder classified normally.
    """
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    if not lines:
        return []

    blocks: List[Dict[str, Any]] = []
    idx = 0
    # Pull consecutive leading heading-shaped lines out one at a time, but
    # never consume the ENTIRE block this way — a block that is only ever
    # short heading-like lines is still just one heading, not N of them.
    while idx < len(lines) - 1 and _is_heading_line(lines[idx]):
        blocks.append({
            "type": "heading", "page": page_num, "text": lines[idx],
            "level": _heading_level_for_text(lines[idx]),
        })
        idx += 1

    remainder = "\n".join(lines[idx:])
    if remainder:
        rtype = _classify_text_block(remainder)
        block = {"type": rtype, "page": page_num, "text": remainder}
        if rtype == "heading":
            block["level"] = _heading_level_for_text(remainder.strip().splitlines()[0])
        blocks.append(block)
    elif not blocks:
        rtype = _classify_text_block(raw)
        block = {"type": rtype, "page": page_num, "text": raw}
        if rtype == "heading":
            block["level"] = _heading_level_for_text(raw.strip().splitlines()[0])
        blocks.append(block)

    return blocks


def _classify_text_block(text: str) -> str:
    """
    Cheap heuristic classifier for a paragraph-shaped block of text.
    Returns one of: heading, list, caption, footer, paragraph.
    """
    stripped = text.strip()
    lines = [ln for ln in stripped.splitlines() if ln.strip()]
    if not lines:
        return "paragraph"
    first_line = lines[0].strip()

    if _CAPTION_RE.match(first_line):
        return "caption"

    if len(stripped) < 100 and any(h in first_line.lower() for h in _FOOTER_HINTS):
        return "footer"

    if len(lines) >= 2 and all(_LIST_ITEM_RE.match(ln) for ln in lines):
        return "list"

    # Heading: a single short line, no terminal punctuation, title-like casing.
    if (
        len(lines) == 1
        and len(first_line) < 80
        and not first_line.endswith((".", ",", ";", ":"))
        and (first_line.isupper() or _HEADING_NUMBERED_RE.match(first_line) or first_line[:1].isupper())
    ):
        return "heading"

    return "paragraph"
