"""main.py — Entry point"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Block all internet calls
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("ANONYMIZED_TELEMETRY", "False")
os.environ.setdefault("CHROMA_TELEMETRY", "False")

from api.app import app
from config.settings import API_HOST, API_PORT

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=API_HOST,
        port=API_PORT,
        workers=1,
        reload=False,
        # FIX: Increase timeouts so slow Ollama responses don't get killed by uvicorn
        timeout_keep_alive=360,   # keep HTTP connection alive for 6 min
        h11_max_incomplete_event_size=16 * 1024 * 1024,  # 16MB for large uploads
    )
