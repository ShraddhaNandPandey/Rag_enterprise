"""
ocr/ocr_engine.py — Multi-backend OCR engine with cascading fallback.

Supported engines: tesseract, easyocr, llava (via Ollama), paddle, trocr, auto.
Each engine's `extract_text(image)` returns plain text or "" if it fails/unavailable.
"""

import base64
import io
import json

from utils.logger import get_logger

logger = get_logger("ocr")

# Lazy-loaded singletons so heavy models are only initialized once and only if used
_easyocr_reader = None
_paddle_ocr = None
_trocr_processor = None
_trocr_model = None

# BUGFIX (root cause of "no extractable content found" on every scanned PDF
# whenever EasyOCR isn't installed): OCR_LANGUAGE is one shared setting, but
# Tesseract's `lang=` parameter requires ISO 639-2/3 codes matching its
# *.traineddata filenames (e.g. "eng", "fra", "deu"), while EasyOCR's reader
# takes ISO 639-1 codes (e.g. "en", "fr", "de"). The default "en" is valid
# for EasyOCR but silently raises "Error opening data file .../en.traineddata"
# inside pytesseract — caught by the cascade's blanket except and logged only
# at DEBUG level, so it looked exactly like "OCR found nothing" instead of
# "OCR was misconfigured". Any deployment that only has Tesseract installed
# (a common, lightweight offline setup — EasyOCR needs a model download) hit
# this on every scanned/image-only PDF page.
_ISO639_1_TO_TESSERACT = {
    "en": "eng", "fr": "fra", "de": "deu", "es": "spa", "it": "ita",
    "pt": "por", "nl": "nld", "ru": "rus", "zh": "chi_sim", "ja": "jpn",
    "ko": "kor", "ar": "ara", "hi": "hin", "bn": "ben", "ta": "tam",
    "te": "tel", "mr": "mar", "gu": "guj", "pa": "pan", "ur": "urd",
    "vi": "vie", "th": "tha", "tr": "tur", "pl": "pol", "uk": "ukr",
}


def _to_tesseract_lang(lang_code: str) -> str:
    """Translate a configured OCR_LANGUAGE into a Tesseract-compatible code.
    Already-correct 3-letter codes (or unrecognized ones) pass through
    unchanged so an operator who already set e.g. "eng" isn't affected."""
    if not lang_code:
        return "eng"
    code = lang_code.strip().lower()
    return _ISO639_1_TO_TESSERACT.get(code, lang_code)


class OCREngine:
    """Cascading OCR engine. Tries the configured engine, falls back to others."""

    def __init__(
        self,
        engine: str = "easyocr",
        llava_model: str = "llava",
        trocr_model: str = "microsoft/trocr-base-printed",
        ollama_url: str = "http://localhost:11434",
    ):
        self.engine = engine.lower()
        self.llava_model = llava_model
        self.trocr_model = trocr_model
        self.ollama_url = ollama_url

    # ── Public API ────────────────────────────────────────────────────────────

    def extract_text(self, image) -> str:
        """
        Extract text from a PIL Image using the configured engine,
        cascading to fallbacks if it fails or returns empty text.
        """
        cascades = {
            "tesseract": [self._tesseract],
            "easyocr": [self._easyocr, self._tesseract],
            "llava": [self._llava, self._easyocr, self._tesseract],
            "paddle": [self._paddle, self._easyocr, self._tesseract],
            "trocr": [self._trocr, self._easyocr, self._tesseract],
            "auto": [self._llava, self._easyocr, self._paddle, self._trocr, self._tesseract],
        }

        chain = cascades.get(self.engine, [self._easyocr, self._tesseract])

        errors = []
        for fn in chain:
            try:
                text = fn(image)
                if text and text.strip():
                    return text.strip()
            except ModuleNotFoundError:
                # Engine simply isn't installed — expected/normal for engines
                # the operator didn't opt into, not worth surfacing loudly.
                continue
            except Exception as e:
                # A REAL error from an engine that IS installed (bad config,
                # missing language data, corrupt model, etc.) — this is not
                # the same situation as "no engine installed" and, left at
                # DEBUG level, is indistinguishable from "OCR just found
                # nothing" (see BUGFIX note above this class). Surface it.
                errors.append(f"{fn.__name__}: {e}")
                continue

        if errors:
            logger.warning(
                "All OCR engines failed or returned empty text. Engine error(s) — "
                "this usually means an installed engine is misconfigured, not that "
                f"the page has no readable text: {'; '.join(errors)}"
            )
        else:
            logger.warning("All OCR engines failed or returned empty text.")
        return ""

    def check_engines(self) -> dict:
        """Check availability of each OCR backend without running full OCR."""
        status = {}

        # Tesseract
        try:
            import pytesseract
            from config.settings import OCR_LANGUAGE
            pytesseract.get_tesseract_version()
            tess_lang = _to_tesseract_lang(OCR_LANGUAGE)
            available_langs = pytesseract.get_languages(config="")
            if tess_lang in available_langs:
                status["tesseract"] = f"✅ available (language '{tess_lang}' installed)"
            else:
                status["tesseract"] = (
                    f"⚠️ tesseract is installed but the '{tess_lang}' language pack is NOT "
                    f"(OCR_LANGUAGE='{OCR_LANGUAGE}') — installed: {', '.join(available_langs) or 'none'}. "
                    f"Install it with: apt install tesseract-ocr-{tess_lang}"
                )
        except Exception as e:
            status["tesseract"] = f"❌ unavailable ({e})"

        # EasyOCR
        try:
            import easyocr  # noqa: F401
            status["easyocr"] = "✅ available (model loads on first use)"
        except Exception as e:
            status["easyocr"] = f"❌ unavailable ({e})"

        # LLaVA (via Ollama)
        try:
            import urllib.request
            req = urllib.request.Request(f"{self.ollama_url}/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read())
                models = [m.get("name", "") for m in data.get("models", [])]
                if any(self.llava_model in m for m in models):
                    status["llava"] = "✅ available"
                else:
                    status["llava"] = f"❌ Ollama running but '{self.llava_model}' not pulled"
        except Exception as e:
            status["llava"] = f"❌ unavailable (Ollama unreachable: {e})"

        # PaddleOCR
        try:
            import paddleocr  # noqa: F401
            status["paddle"] = "✅ available"
        except Exception as e:
            status["paddle"] = f"❌ unavailable ({e})"

        # TrOCR
        try:
            import transformers  # noqa: F401
            import torch  # noqa: F401
            status["trocr"] = "✅ available (model loads on first use)"
        except Exception as e:
            status["trocr"] = f"❌ unavailable ({e})"

        return status

    # ── Backend implementations ───────────────────────────────────────────────

    def _tesseract(self, image) -> str:
        import pytesseract
        from config.settings import OCR_LANGUAGE
        return pytesseract.image_to_string(image, lang=_to_tesseract_lang(OCR_LANGUAGE))

    def _easyocr(self, image) -> str:
        global _easyocr_reader
        import numpy as np
        from config.settings import OCR_LANGUAGE, OCR_USE_GPU, EASYOCR_MODEL_DIR

        if _easyocr_reader is None:
            import easyocr
            kwargs = {"gpu": OCR_USE_GPU}
            if EASYOCR_MODEL_DIR:
                kwargs["model_storage_directory"] = EASYOCR_MODEL_DIR
            langs = [OCR_LANGUAGE] if OCR_LANGUAGE else ["en"]
            _easyocr_reader = easyocr.Reader(langs, **kwargs)

        img_array = np.array(image.convert("RGB"))
        results = _easyocr_reader.readtext(img_array, detail=0)
        return "\n".join(results)

    def _llava(self, image) -> str:
        import urllib.request

        buf = io.BytesIO()
        image.convert("RGB").save(buf, format="PNG")
        img_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

        payload = json.dumps({
            "model": self.llava_model,
            "prompt": "Describe this image for a search index. First, in 1-3 sentences, explain what "
                      "the image shows overall (e.g. a diagram, chart, photo, screenshot) and, if it is "
                      "a diagram, how its labeled parts relate to each other. Then transcribe ALL visible "
                      "text exactly as written, one label/line per line. Output only the description and "
                      "the transcribed text — no extra commentary, headers, or markdown.",
            "images": [img_b64],
            "stream": False,
        }).encode()

        req = urllib.request.Request(
            f"{self.ollama_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read())
            return data.get("response", "")

    def _paddle(self, image) -> str:
        global _paddle_ocr
        import numpy as np

        if _paddle_ocr is None:
            from paddleocr import PaddleOCR
            _paddle_ocr = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)

        img_array = np.array(image.convert("RGB"))
        result = _paddle_ocr.ocr(img_array, cls=True)
        lines = []
        for block in result or []:
            for line in block or []:
                if len(line) >= 2:
                    lines.append(line[1][0])
        return "\n".join(lines)

    def _trocr(self, image) -> str:
        global _trocr_processor, _trocr_model
        import torch
        from transformers import TrOCRProcessor, VisionEncoderDecoderModel

        if _trocr_processor is None or _trocr_model is None:
            _trocr_processor = TrOCRProcessor.from_pretrained(self.trocr_model)
            _trocr_model = VisionEncoderDecoderModel.from_pretrained(self.trocr_model)

        pixel_values = _trocr_processor(images=image.convert("RGB"), return_tensors="pt").pixel_values
        with torch.no_grad():
            generated_ids = _trocr_model.generate(pixel_values)
        return _trocr_processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
