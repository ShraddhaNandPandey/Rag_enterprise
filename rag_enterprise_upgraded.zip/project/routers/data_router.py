"""routers/data_router.py — Tabular data management endpoints"""

import asyncio

from fastapi import APIRouter, HTTPException
from utils.logger import get_logger

logger = get_logger("api")
router = APIRouter(prefix="/data", tags=["Tabular Data"])


@router.get("/tables")
async def list_tables():
    """List all DuckDB tables."""
    from api.dependencies import get_duckdb_manager
    try:
        db     = get_duckdb_manager()
        tables = db.list_tables()
        schema = db.get_schema()
        return {"tables": tables, "count": len(tables), "schema": schema}
    except Exception as e:
        logger.error(f"list_tables failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not list tables: {e}")


@router.get("/tables/{table_name}")
async def get_table_info(table_name: str):
    """Get metadata for a specific table."""
    from api.dependencies import get_duckdb_manager
    try:
        info = get_duckdb_manager().get_table_info(table_name)
    except Exception as e:
        logger.error(f"get_table_info failed for '{table_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not load table '{table_name}': {e}")
    if not info:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not found.")
    return info


@router.get("/tables/{table_name}/preview")
async def preview_table(table_name: str, limit: int = 10):
    """Preview first N rows of a table."""
    from api.dependencies import get_duckdb_manager
    db = get_duckdb_manager()
    try:
        result = db.execute_query(f'SELECT * FROM "{table_name}" LIMIT {min(limit, 100)}')
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/sources")
async def list_sources():
    """List all sources in ChromaDB vector store."""
    from api.dependencies import get_vector_store
    try:
        sources = get_vector_store().list_sources()
        return {"sources": sources, "count": len(sources)}
    except Exception as e:
        logger.error(f"list_sources failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not list sources: {e}")


# ─── OCR Diagnostic Endpoint ──────────────────────────────────────────────────

@router.get("/ocr/status")
async def ocr_status():
    """
    Check which OCR engines are available on this machine.
    Use this to verify your OCR setup before uploading images.
    """
    from config.settings import OCR_ENGINE, TROCR_MODEL, LLAVA_MODEL, OLLAMA_BASE_URL
    from ocr.ocr_engine import OCREngine

    try:
        engine = OCREngine(
            engine=OCR_ENGINE,
            llava_model=LLAVA_MODEL,
            trocr_model=TROCR_MODEL,
        )
        # check_engines() imports heavy optional libraries (torch, transformers,
        # easyocr, paddleocr) the first time it runs and pings Ollama over the
        # network — on a cold start this took ~48s in production and blocked
        # the entire event loop for that whole time (every other request,
        # including /health, simply queued up). Running it in a worker thread
        # keeps the rest of the app responsive while this check completes.
        status = await asyncio.get_running_loop().run_in_executor(None, engine.check_engines)
    except Exception as e:
        logger.error(f"ocr_status check failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not check OCR engine status: {e}")

    return {
        "configured_engine": OCR_ENGINE,
        "llava_model":       LLAVA_MODEL,
        "trocr_model":       TROCR_MODEL,
        "ollama_url":        OLLAMA_BASE_URL,
        "engine_status":     status,
        "recommendation":    _ocr_recommendation(status),
        "setup_guide":       _ocr_setup_guide(status),
    }


def _ocr_recommendation(status: dict) -> str:
    llava_ok = status.get("llava", "").startswith("✅")
    trocr_ok = status.get("trocr", "").startswith("✅")
    paddle_ok = status.get("paddle", "").startswith("✅")
    tess_ok  = status.get("tesseract", "").startswith("✅")

    if llava_ok:
        return "OCR_ENGINE=llava — best for all image types including charts and diagrams"
    if trocr_ok:
        return "OCR_ENGINE=trocr — best for printed text, invoices, scanned documents"
    if paddle_ok:
        return "OCR_ENGINE=paddle — good for dense text"
    if tess_ok:
        return "OCR_ENGINE=tesseract — basic OCR, works but lower accuracy"
    return "No OCR engine available — install pytesseract at minimum"


def _ocr_setup_guide(status: dict) -> dict:
    guide = {}
    if not status.get("tesseract", "").startswith("✅"):
        guide["tesseract"] = (
            "pip install pytesseract  "
            "| Windows: download from https://github.com/UB-Mannheim/tesseract/wiki"
        )
    if not status.get("trocr", "").startswith("✅"):
        guide["trocr"] = (
            "pip install transformers torch  "
            "| Then: python -c \"from transformers import TrOCRProcessor, "
            "VisionEncoderDecoderModel; "
            "TrOCRProcessor.from_pretrained('microsoft/trocr-base-printed'); "
            "VisionEncoderDecoderModel.from_pretrained('microsoft/trocr-base-printed')\"  "
            "| Set TROCR_MODEL=microsoft/trocr-base-printed in .env"
        )
    if not status.get("llava", "").startswith("✅"):
        guide["llava"] = (
            "Install Ollama: https://ollama.com  "
            "| Then: ollama pull llava  "
            "| Set OCR_ENGINE=llava and LLAVA_MODEL=llava in .env"
        )
    return guide
