"""
routers/export_router.py — Offline PDF export for chat answers.

New, additive endpoint only:
    POST /export/pdf   render a chat Q&A turn as a downloadable, print-ready PDF

Does not touch /ingest, /query, /data, /memory, /models, or /api/tts in any way.
Runs fully offline (ReportLab + local fonts) — no outbound network calls,
no cloud PDF service, no telemetry. Safe for air-gapped / defence intranets.
"""

import asyncio
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Response

from models.schemas import PDFExportRequest
from services.pdf_export_service import generate_pdf_report
from utils.logger import get_logger

logger = get_logger("api")
router = APIRouter(prefix="/export", tags=["Export"])


@router.post("/pdf")
async def export_pdf(request: PDFExportRequest):
    """
    Render one Q&A turn (question + answer + metadata) as a professionally
    formatted PDF report — headers, highlighted question, fully-formatted
    answer (headings/lists/tables/code), sources, and generation details,
    with a page footer on every page. 100% offline generation.
    """
    try:
        pdf_bytes, filename = await asyncio.get_running_loop().run_in_executor(
            None, generate_pdf_report, request
        )
    except Exception as e:
        logger.error(f"PDF export failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="PDF generation failed.")

    ascii_fallback = filename.encode("ascii", "ignore").decode("ascii") or "export.pdf"
    disposition = f'attachment; filename="{ascii_fallback}"; filename*=UTF-8\'\'{quote(filename)}'

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": disposition,
            "Cache-Control": "no-store",
        },
    )
