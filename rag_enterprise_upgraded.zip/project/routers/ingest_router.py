"""routers/ingest_router.py — File ingestion endpoints"""

import os
import re
import shutil
import tempfile
import threading
from pathlib import Path
from typing import List

from fastapi import APIRouter, UploadFile, File, HTTPException

from models.schemas import IngestResponse, StatsResponse
from config.settings import SUPPORTED_EXTENSIONS
from services.ingest_jobs import create_job, get_job
from utils.logger import get_logger

logger = get_logger("api")
router = APIRouter(prefix="/ingest", tags=["Ingestion"])


async def _save_uploads(files: List[UploadFile]):
    """
    Save uploaded files to a fresh temp dir with sanitized, space-free names
    (Windows paths with spaces can make pypdf/other libs fail silently).
    Shared by both the legacy synchronous /upload endpoint and the
    cancellable /upload/start job flow.
    Returns (temp_dir, saved_paths, rejected, failed).
    """
    safe_tmp = os.path.join(tempfile.gettempdir(), "rag_uploads")
    os.makedirs(safe_tmp, exist_ok=True)
    temp_dir = tempfile.mkdtemp(prefix="rag_", dir=safe_tmp)

    saved_paths, rejected, failed = [], [], []
    for upload in files:
        ext = Path(upload.filename).suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            rejected.append(upload.filename)
            continue
        try:
            safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", upload.filename)
            dest = Path(temp_dir) / safe_name
            counter = 1
            while dest.exists():
                dest = Path(temp_dir) / f"{Path(safe_name).stem}_{counter}{ext}"
                counter += 1
            content = await upload.read()
            dest.write_bytes(content)
            saved_paths.append(str(dest))
            logger.info(f"Saved upload: {upload.filename} → {dest.name} ({len(content)} bytes)")
            # NEW (additive, non-breaking): also keep a persistent copy so the
            # Document Preview feature has original bytes to render/download
            # after this temp dir is cleaned up. Never allowed to affect the
            # ingestion flow above — failures here are swallowed and logged.
            try:
                from services.preview_store import save_preview_copy
                save_preview_copy(dest.name, content)
            except Exception as preview_e:
                logger.warning(f"Preview copy not saved for '{dest.name}': {preview_e}")
        except Exception as e:
            logger.error(f"Failed to save upload '{upload.filename}': {e}", exc_info=True)
            failed.append(upload.filename)

    return temp_dir, saved_paths, rejected, failed


@router.post("/upload", response_model=IngestResponse)
async def upload_files(files: List[UploadFile] = File(...)):
    """Upload and ingest files. PDF/DOCX/PPTX/TXT→ChromaDB. CSV/Excel→DuckDB."""
    from api.dependencies import get_ingestion_service

    if not files:
        raise HTTPException(status_code=400, detail="No files provided.")

    try:
        service = get_ingestion_service()
    except Exception as e:
        logger.error(f"Could not initialize ingestion service: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Ingestion service unavailable: {e}")

    # FIXED: Use a temp dir with NO spaces in the path.
    # Windows paths like C:\Users\Shraddha Nand Pandey\... have spaces that can
    # cause pypdf (and other libs) to fail silently when opening the file.
    import os, re
    try:
        safe_tmp = os.path.join(tempfile.gettempdir(), "rag_uploads")
        os.makedirs(safe_tmp, exist_ok=True)
        temp_dir = tempfile.mkdtemp(prefix="rag_", dir=safe_tmp)
    except OSError as e:
        logger.error(f"Could not create temp upload directory: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not create temp directory for upload: {e}")

    saved_paths, rejected, failed = [], [], []

    try:
        for upload in files:
            ext = Path(upload.filename).suffix.lower()
            if ext not in SUPPORTED_EXTENSIONS:
                rejected.append(upload.filename)
                continue
            try:
                # Sanitize filename: remove spaces and special chars for safe path handling
                safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", upload.filename)
                dest = Path(temp_dir) / safe_name
                counter = 1
                while dest.exists():
                    dest = Path(temp_dir) / f"{Path(safe_name).stem}_{counter}{ext}"
                    counter += 1
                content = await upload.read()
                dest.write_bytes(content)
                saved_paths.append(str(dest))
                logger.info(f"Saved upload: {upload.filename} → {dest.name} ({len(content)} bytes)")
                # NEW (additive, non-breaking): persist a copy for Document Preview.
                # See _save_uploads() above for the same pattern and rationale.
                try:
                    from services.preview_store import save_preview_copy
                    save_preview_copy(dest.name, content)
                except Exception as preview_e:
                    logger.warning(f"Preview copy not saved for '{dest.name}': {preview_e}")
            except Exception as e:
                logger.error(f"Failed to save upload '{upload.filename}': {e}", exc_info=True)
                failed.append(upload.filename)

        if not saved_paths:
            raise HTTPException(status_code=400,
                detail=f"No valid files. Rejected: {rejected}. Failed to save: {failed}. "
                       f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")

        try:
            result = service.ingest(saved_paths)
        except Exception as e:
            logger.error(f"Ingestion pipeline failed: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Ingestion failed: {e}")

        if rejected:
            result["rejected_files"] = rejected
        if failed:
            result["failed_files"] = failed

        return IngestResponse(
            success=True,
            files_total=len(saved_paths),
            chunks_embedded=result["chunks_embedded"],
            tabular_tables=result["tabular_tables"],
            tabular_rows=result["tabular_rows"],
            details=result,
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Ingestion failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Ingestion error: {str(e)}")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ─────────────────────────────────────────────────────────────────────────
# Cancellable, background ingestion.
#
# The endpoint above blocks until every file is fully processed with no way
# to stop partway through. These three endpoints run ingestion on a
# background thread instead:
#   POST /ingest/upload/start        → save files, kick off the job, return immediately
#   GET  /ingest/upload/{id}/status  → poll progress
#   POST /ingest/upload/{id}/cancel  → stop at the next file boundary and roll
#                                       back anything that job already committed
# ─────────────────────────────────────────────────────────────────────────

@router.post("/upload/start")
async def start_upload(files: List[UploadFile] = File(...)):
    """Save the uploaded files and start ingesting them in the background."""
    from api.dependencies import get_ingestion_service

    if not files:
        raise HTTPException(status_code=400, detail="No files provided.")

    try:
        service = get_ingestion_service()
    except Exception as e:
        logger.error(f"Could not initialize ingestion service: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail=f"Ingestion service unavailable: {e}")

    try:
        temp_dir, saved_paths, rejected, failed = await _save_uploads(files)
    except OSError as e:
        logger.error(f"Could not create temp upload directory: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not create temp directory for upload: {e}")

    if not saved_paths:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(status_code=400,
            detail=f"No valid files. Rejected: {rejected}. Failed to save: {failed}. "
                   f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}")

    job = create_job([Path(p).name for p in saved_paths])
    for name in rejected:
        job.add_error(f"{name}: unsupported file type")
    for name in failed:
        job.add_error(f"{name}: could not be saved")

    def _run():
        try:
            service.ingest_with_control(saved_paths, job)
        except Exception as e:
            logger.error(f"Ingestion job {job.job_id} crashed: {e}", exc_info=True)
            job.add_error(str(e))
            job.finish("error")
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    threading.Thread(target=_run, name=f"ingest-{job.job_id[:8]}", daemon=True).start()

    return {
        "job_id": job.job_id,
        "files_total": job.files_total,
        "rejected_files": rejected,
        "failed_files": failed,
    }


@router.get("/upload/{job_id}/status")
async def upload_status(job_id: str):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"No ingestion job '{job_id}' (it may have expired).")
    return job.to_dict()


@router.post("/upload/{job_id}/cancel")
async def cancel_upload(job_id: str):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"No ingestion job '{job_id}' (it may have expired).")
    if job.status != "running":
        return {"job_id": job_id, "status": job.status, "cancel_requested": False}
    job.request_cancel()
    logger.info(f"Cancel requested for ingestion job {job_id}")
    return {"job_id": job_id, "status": job.status, "cancel_requested": True}


@router.get("/kb")
async def get_knowledge_base():
    """Return unified per-document knowledge base view for the UI panel."""
    from api.dependencies import get_ingestion_service
    try:
        return get_ingestion_service().get_knowledge_base()
    except Exception as e:
        logger.error(f"get_knowledge_base failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not load knowledge base: {e}")


@router.get("/sources")
async def list_sources():
    """
    Return a flat list of all ingested document filenames from both stores.
    Used by the UI to populate the document-filter selector for multi-doc queries.

    Response:
      {
        "sources": ["report.pdf", "data.xlsx", "policy.docx"],
        "count": 3,
        "semantic": ["report.pdf", "policy.docx"],   // in ChromaDB
        "tabular":  ["data.xlsx"]                    // in DuckDB
      }
    """
    from api.dependencies import get_vector_store, get_duckdb_manager
    from pathlib import Path

    try:
        vs = get_vector_store()
        db = get_duckdb_manager()

        semantic = vs.list_sources()                      # list[str] of source_name values

        tabular: list[str] = []
        for tname in db.list_tables():
            info = db.get_table_info(tname)
            if info and info.get("source_file"):
                fname = Path(info["source_file"]).name
                if fname not in tabular:
                    tabular.append(fname)

        all_sources = sorted(set(semantic) | set(tabular))

        return {
            "sources":  all_sources,
            "count":    len(all_sources),
            "semantic": sorted(semantic),
            "tabular":  sorted(tabular),
        }
    except Exception as e:
        logger.error(f"list_sources failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not list sources: {e}")


@router.delete("/kb/{doc_name}")
async def delete_document(doc_name: str):
    """
    Fully delete a document from ALL stores:
    ChromaDB embeddings, BM25 index, DuckDB tables, registry metadata.
    """
    from api.dependencies import get_ingestion_service
    try:
        result = get_ingestion_service().delete_document(doc_name)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"delete_document failed for '{doc_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not delete '{doc_name}': {e}")

    if not result["success"] and result["deleted_chunks"] == 0 and not result["deleted_tables"]:
        if result.get("errors"):
            # Backend failure prevented us from even checking — not a genuine 404
            raise HTTPException(
                status_code=500,
                detail=f"Could not delete '{doc_name}': {'; '.join(result['errors'])}",
            )
        raise HTTPException(status_code=404, detail=f"Document '{doc_name}' not found.")

    # NEW (additive, non-breaking): also drop the persisted preview copy so
    # deleted documents don't leave an orphaned original behind. Never allowed
    # to affect the deletion result computed above.
    try:
        from services.preview_store import delete_preview_copy
        delete_preview_copy(doc_name)
    except Exception as preview_e:
        logger.warning(f"Preview copy cleanup failed for '{doc_name}': {preview_e}")

    return result


@router.delete("/source/{source_name}")
async def delete_source(source_name: str):
    from api.dependencies import get_vector_store
    try:
        deleted = get_vector_store().delete_source(source_name)
        return {"deleted_chunks": deleted, "source": source_name}
    except Exception as e:
        logger.error(f"delete_source failed for '{source_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not delete source '{source_name}': {e}")


@router.delete("/table/{table_name}")
async def delete_table(table_name: str):
    from api.dependencies import get_duckdb_manager
    try:
        db = get_duckdb_manager()
        dropped = db.drop_table(table_name)
    except Exception as e:
        logger.error(f"delete_table failed for '{table_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not delete table '{table_name}': {e}")

    if not dropped:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not found.")
    return {"deleted": True, "table": table_name}


@router.post("/reset")
async def reset_all():
    """⚠️ Delete ALL ChromaDB chunks and DuckDB tables."""
    from api.dependencies import get_vector_store, get_duckdb_manager

    errors = []
    try:
        get_vector_store().reset()
    except Exception as e:
        logger.error(f"reset_all: vector store reset failed: {e}", exc_info=True)
        errors.append(f"vector store: {e}")

    try:
        get_duckdb_manager().reset()
    except Exception as e:
        logger.error(f"reset_all: DuckDB reset failed: {e}", exc_info=True)
        errors.append(f"tabular store: {e}")

    if errors:
        raise HTTPException(
            status_code=500,
            detail=f"Reset partially failed: {'; '.join(errors)}. "
                   f"Some data may have been cleared — check /ingest/kb to verify current state.",
        )

    logger.warning("Full reset performed")
    return {"reset": True, "message": "All data cleared."}


@router.get("/stats", response_model=StatsResponse)
async def ingestion_stats():
    from api.dependencies import get_ingestion_service
    try:
        return get_ingestion_service().get_ingestion_summary()
    except Exception as e:
        logger.error(f"ingestion_stats failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not load ingestion stats: {e}")
