"""routers/memory_router.py — Conversation memory endpoints"""

from fastapi import APIRouter, HTTPException
from models.schemas import SessionCreateRequest, SessionResponse
from utils.logger import get_logger

logger = get_logger("api")
router = APIRouter(prefix="/memory", tags=["Memory"])


@router.post("/sessions", response_model=SessionResponse)
async def create_session(request: SessionCreateRequest = SessionCreateRequest()):
    """Create a new conversation session."""
    from api.dependencies import get_memory
    try:
        sid = get_memory().create_session(request.session_id, request.metadata)
        return SessionResponse(session_id=sid)
    except Exception as e:
        logger.error(f"create_session failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not create session: {e}")


@router.get("/sessions")
async def list_sessions():
    """List all conversation sessions."""
    from api.dependencies import get_memory
    try:
        return {"sessions": get_memory().list_sessions()}
    except Exception as e:
        logger.error(f"list_sessions failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not list sessions: {e}")


@router.get("/sessions/{session_id}/history")
async def get_history(session_id: str, limit: int = 50):
    """Get conversation history for a session."""
    from api.dependencies import get_memory
    try:
        history = get_memory().get_full_history(session_id, limit=limit)
    except Exception as e:
        logger.error(f"get_history failed for session '{session_id}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not load history: {e}")
    if not history:
        return {"session_id": session_id, "messages": [], "count": 0}
    return {"session_id": session_id, "messages": history, "count": len(history)}


@router.delete("/sessions/{session_id}")
async def delete_session(session_id: str):
    """Delete a session and all its messages."""
    from api.dependencies import get_memory
    try:
        deleted = get_memory().delete_session(session_id)
    except Exception as e:
        logger.error(f"delete_session failed for '{session_id}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not delete session: {e}")
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found.")
    return {"deleted": True, "session_id": session_id}


@router.post("/sessions/{session_id}/clear")
async def clear_session(session_id: str):
    """Clear messages in a session (keep session record)."""
    from api.dependencies import get_memory
    try:
        count = get_memory().clear_session(session_id)
        return {"cleared": count, "session_id": session_id}
    except Exception as e:
        logger.error(f"clear_session failed for '{session_id}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not clear session: {e}")


@router.get("/sessions/{session_id}/stats")
async def session_stats(session_id: str):
    """Get statistics for a session."""
    from api.dependencies import get_memory
    try:
        return get_memory().get_session_stats(session_id)
    except Exception as e:
        logger.error(f"session_stats failed for '{session_id}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not load session stats: {e}")
