"""
routers/preview_router.py — Document Preview endpoints (read-only, additive)

These endpoints are entirely new and do not modify, wrap, or depend on any
existing route. They only read files that services/preview_store.py has
persisted from uploads, and render them for display:

  GET /preview/{doc_name}/meta                  -> what kind of preview is available
  GET /preview/{doc_name}/file                   -> raw original bytes (images, download)
  GET /preview/{doc_name}/pdf/page/{page}        -> PNG render of one PDF page
  GET /preview/{doc_name}/docx/html              -> read-only HTML rendering of a .docx
  GET /preview/{doc_name}/excel/sheets           -> list of sheet names in a workbook
  GET /preview/{doc_name}/excel/sheets/{sheet}   -> rows for one sheet

Nothing here touches ChromaDB, DuckDB, the ingestion pipeline, or Ollama.
"""

from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response, FileResponse

from services.preview_store import get_preview_path
from utils.logger import get_logger

logger = get_logger("preview")
router = APIRouter(prefix="/preview", tags=["Preview"])

PDF_EXTS   = {".pdf"}
DOCX_EXTS  = {".docx"}
EXCEL_EXTS = {".xlsx", ".xls"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp"}
SUPPORTED_PREVIEW_EXTS = PDF_EXTS | DOCX_EXTS | EXCEL_EXTS | IMAGE_EXTS

_MIME = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls": "application/vnd.ms-excel",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".bmp": "image/bmp",
}


def _resolve(doc_name: str) -> Path:
    path = get_preview_path(doc_name)
    if path is None:
        raise HTTPException(
            status_code=404,
            detail=f"Original file for '{doc_name}' is not available for preview "
                   f"(it may have been uploaded before preview support was added, "
                   f"or removed from storage).",
        )
    return path


@router.get("/{doc_name}/meta")
async def preview_meta(doc_name: str):
    ext = Path(doc_name).suffix.lower()
    supported = ext in SUPPORTED_PREVIEW_EXTS
    path = get_preview_path(doc_name)
    available = supported and path is not None

    kind = None
    if ext in PDF_EXTS: kind = "pdf"
    elif ext in DOCX_EXTS: kind = "docx"
    elif ext in EXCEL_EXTS: kind = "excel"
    elif ext in IMAGE_EXTS: kind = "image"

    resp = {
        "doc_name": doc_name,
        "ext": ext,
        "kind": kind,
        "supported": supported,
        "available": available,
        "size": path.stat().st_size if path else None,
        "download_available": path is not None,
    }

    if available and kind == "pdf":
        try:
            from services.preview_render import pdf_page_count
            resp["page_count"] = pdf_page_count(path)
        except Exception as e:
            logger.warning(f"preview_meta: pdf_page_count failed for '{doc_name}': {e}")
            resp["available"] = False
            resp["error"] = "This PDF could not be opened for preview."

    if available and kind == "excel":
        try:
            from services.preview_render import excel_sheet_names
            resp["sheets"] = excel_sheet_names(path)
        except Exception as e:
            logger.warning(f"preview_meta: excel_sheet_names failed for '{doc_name}': {e}")
            resp["available"] = False
            resp["error"] = "This workbook could not be opened for preview."

    return resp


@router.get("/{doc_name}/file")
async def preview_raw_file(doc_name: str, download: bool = Query(False)):
    """Raw bytes of the stored original — used for image display and as the
    universal Download fallback for any file type (including unsupported ones)."""
    path = _resolve(doc_name)
    ext = path.suffix.lower()
    mime = _MIME.get(ext, "application/octet-stream")
    if download:
        return FileResponse(str(path), media_type=mime, filename=doc_name)
    return FileResponse(str(path), media_type=mime)


@router.get("/{doc_name}/pdf/page/{page_number}")
async def preview_pdf_page(doc_name: str, page_number: int, dpi: int = Query(130, ge=60, le=300)):
    path = _resolve(doc_name)
    if path.suffix.lower() not in PDF_EXTS:
        raise HTTPException(status_code=400, detail=f"'{doc_name}' is not a PDF.")
    if page_number < 1:
        raise HTTPException(status_code=400, detail="page_number must be >= 1.")
    try:
        from services.preview_render import pdf_page_count
        total_pages = pdf_page_count(path)
    except Exception as e:
        logger.error(f"preview_pdf_page: could not open '{doc_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not open PDF: {e}")
    if page_number > total_pages:
        raise HTTPException(
            status_code=400,
            detail=f"Page {page_number} does not exist — '{doc_name}' has {total_pages} page(s).",
        )
    try:
        from services.preview_render import render_pdf_page_png
        png_bytes = render_pdf_page_png(path, page_number, dpi=dpi)
    except Exception as e:
        logger.error(f"preview_pdf_page failed for '{doc_name}' page {page_number}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not render page {page_number}: {e}")
    return Response(content=png_bytes, media_type="image/png")


@router.get("/{doc_name}/docx/html")
async def preview_docx_html(doc_name: str):
    path = _resolve(doc_name)
    if path.suffix.lower() not in DOCX_EXTS:
        raise HTTPException(status_code=400, detail=f"'{doc_name}' is not a .docx file.")
    try:
        from services.preview_render import render_docx_html
        html = render_docx_html(path)
    except Exception as e:
        logger.error(f"preview_docx_html failed for '{doc_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not render document: {e}")
    return {"doc_name": doc_name, "html": html}


@router.get("/{doc_name}/excel/sheets")
async def preview_excel_sheets(doc_name: str):
    path = _resolve(doc_name)
    if path.suffix.lower() not in EXCEL_EXTS:
        raise HTTPException(status_code=400, detail=f"'{doc_name}' is not an Excel workbook.")
    try:
        from services.preview_render import excel_sheet_names
        sheets = excel_sheet_names(path)
    except Exception as e:
        logger.error(f"preview_excel_sheets failed for '{doc_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not open workbook: {e}")
    return {"doc_name": doc_name, "sheets": sheets}


@router.get("/{doc_name}/excel/sheets/{sheet_name}")
async def preview_excel_sheet_data(doc_name: str, sheet_name: str):
    path = _resolve(doc_name)
    if path.suffix.lower() not in EXCEL_EXTS:
        raise HTTPException(status_code=400, detail=f"'{doc_name}' is not an Excel workbook.")
    try:
        from services.preview_render import excel_sheet_names
        if sheet_name not in excel_sheet_names(path):
            raise HTTPException(status_code=404, detail=f"Sheet '{sheet_name}' not found in '{doc_name}'.")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"preview_excel_sheet_data: could not list sheets for '{doc_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not open workbook: {e}")
    try:
        from services.preview_render import render_excel_sheet
        data = render_excel_sheet(path, sheet_name)
    except Exception as e:
        logger.error(f"preview_excel_sheet_data failed for '{doc_name}'/'{sheet_name}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not read sheet '{sheet_name}': {e}")
    return data
