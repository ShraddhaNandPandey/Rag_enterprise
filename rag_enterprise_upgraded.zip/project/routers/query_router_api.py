"""routers/query_router_api.py — Query and chat endpoints"""

from fastapi import APIRouter, HTTPException
from models.schemas import AskRequest, AskResponse, ChatRequest, SQLRequest
from config.settings import CONFIDENCE_THRESHOLD
from utils.logger import get_logger

logger = get_logger("api")
router = APIRouter(prefix="/query", tags=["Query"])


@router.post("/ask", response_model=AskResponse)
async def ask(request: AskRequest):
    """
    Ask a question. Auto-routes to:
    - ChromaDB semantic search (documents, policies, descriptions)
    - DuckDB SQL (sums, averages, counts, aggregations on CSV/Excel)
    """
    from api.dependencies import get_query_service, get_memory
    service = get_query_service()
    memory  = get_memory()

    session_history = None
    if request.session_id:
        try:
            memory.get_or_create_session(request.session_id)
            session_history = memory.get_history(request.session_id, limit=10)
        except Exception as e:
            logger.error(f"Memory lookup failed for session '{request.session_id}': {e}", exc_info=True)
            # Degrade gracefully: answer without conversation history rather than failing the request
            session_history = None

    try:
        result = service.ask(
            question=request.question,
            session_history=session_history,
            filters=request.filters,
            k=request.k,
            source_names=request.source_names,
            per_document_answers=request.per_document_answers,
        )
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=f"Ollama unavailable: {e}")
    except Exception as e:
        logger.error(f"Query failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

    # Save to memory — best-effort. The query already succeeded, so a memory
    # write failure must not turn a good answer into a 500 for the user.
    if request.session_id:
        try:
            memory.add_message(request.session_id, "user", request.question,
                               query_type=result["query_type"])
            memory.add_message(request.session_id, "assistant", result["answer"],
                               query_type=result["query_type"],
                               confidence=result["confidence"],
                               sources=result["sources"])
        except Exception as e:
            logger.error(f"Failed to persist message to session '{request.session_id}': {e}", exc_info=True)

    # BUGFIX: query_service.py can already set low_confidence_warning=True itself
    # (e.g. the tabular ground-truth mismatch check in _build_tabular_response).
    # The old code below recomputed low_conf from scratch and only considered
    # "semantic"/"multi_document" query types — which silently discarded any
    # tabular warning the service layer had already raised. Now we OR the two
    # together so neither source of a low-confidence signal gets dropped.
    # "hybrid" (PART 7/8: combined DuckDB + ChromaDB answers) is included here
    # too — otherwise a genuinely low-confidence hybrid answer would never
    # trigger the threshold-based warning that "semantic" answers already get.
    low_conf = (
        result.get("low_confidence_warning", False)
        or (
            result["confidence"] < CONFIDENCE_THRESHOLD
            and result["query_type"] in ("semantic", "multi_document", "hybrid")
        )
    )

    return AskResponse(
        answer=result["answer"],
        query_type=result["query_type"],
        confidence=result["confidence"],
        sources=result["sources"],
        sql=result.get("sql"),
        sql_result=result.get("sql_result"),
        session_id=request.session_id,
        low_confidence_warning=low_conf,
        per_doc_results=result.get("per_doc_results"),
        docs_searched=result.get("docs_searched"),
        chart=result.get("chart"),
    )


@router.post("/chat", response_model=AskResponse)
async def chat(request: ChatRequest):
    """Multi-turn chat with session memory."""
    return await ask(AskRequest(
        question=request.question,
        session_id=request.session_id,
        filters=request.filters,
    ))


@router.post("/sql/preview")
async def preview_sql(request: SQLRequest):
    """Generate and preview SQL without executing it."""
    from api.dependencies import get_query_service, get_duckdb_manager
    from tools.sql_generator import generate_sql

    try:
        service = get_query_service()
        db      = get_duckdb_manager()
        schema  = db.get_schema()
        result = generate_sql(request.question, schema, model=service.model, base_url=service.ollama_url)
        return {
            "question":    request.question,
            "sql":         result.get("sql"),
            "is_valid":    result["is_valid"],
            "message":     result["validation_message"],
            "schema_used": schema,
        }
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=f"Ollama unavailable: {e}")
    except Exception as e:
        logger.error(f"preview_sql failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"SQL preview failed: {e}")


@router.post("/sql/execute")
async def execute_sql(request: SQLRequest):
    """Execute a raw SQL SELECT query directly (for debugging)."""
    from api.dependencies import get_duckdb_manager
    from tools.sql_generator import validate_sql

    sql = request.question.strip()
    is_valid, msg = validate_sql(sql)
    if not is_valid:
        raise HTTPException(status_code=400, detail=f"Invalid SQL: {msg}")

    try:
        db = get_duckdb_manager()
        result = db.execute_query(sql)
        return result
    except Exception as e:
        logger.error(f"execute_sql failed: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=str(e))
