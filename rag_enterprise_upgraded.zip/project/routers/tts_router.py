"""
routers/tts_router.py — Read Aloud (Text-to-Speech) endpoints.

New, additive endpoints only:
    POST   /api/tts             synthesize speech for AI response text
    GET    /api/tts/status      whether Read Aloud is available + which engine
    DELETE /api/tts/cache       clear the local audio cache (admin/maintenance)

Does not touch /ingest, /query, /data, /memory, /models, or auth in any way.
Runs fully offline: text and audio never leave the local machine.
"""

import asyncio

from fastapi import APIRouter, HTTPException, Response

from models.schemas import TTSRequest, TTSStatusResponse, TTSCacheClearResponse
from services.tts_service import TTSUnavailableError, TTSSynthesisError
from utils.logger import get_logger

logger = get_logger("api")
router = APIRouter(prefix="/api/tts", tags=["Read Aloud (TTS)"])


@router.post("")
async def synthesize_speech(request: TTSRequest):
    """
    Synthesize the given AI-response text to speech and return a WAV file.

    Fully offline (Piper preferred, pyttsx3 fallback). Identical text reuses
    a cached audio file instead of regenerating it. Generation runs in a
    worker thread so it never blocks the event loop / freezes the UI.
    """
    from api.dependencies import get_tts_service
    service = get_tts_service()

    try:
        audio_bytes, was_cached = await asyncio.get_running_loop().run_in_executor(
            None, service.synthesize, request.text
        )
    except TTSUnavailableError as e:
        logger.warning(f"TTS unavailable: {e}")
        raise HTTPException(status_code=503, detail=str(e))
    except TTSSynthesisError as e:
        logger.error(f"TTS synthesis failed: {e}")
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        logger.error(f"TTS unexpected error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Audio generation failed.")

    return Response(
        content=audio_bytes,
        media_type="audio/wav",
        headers={
            "X-TTS-Cached": "true" if was_cached else "false",
            "Cache-Control": "private, max-age=3600",
        },
    )


@router.get("/status", response_model=TTSStatusResponse)
async def tts_status():
    """Report whether Read Aloud is available and basic cache stats."""
    from api.dependencies import get_tts_service
    service = get_tts_service()
    stats = service.cache_stats()
    return TTSStatusResponse(
        available=service.is_available,
        engine=service.engine_name,
        cache_enabled=service.cache.enabled,
        cached_files=stats.files,
        cached_bytes=stats.total_bytes,
    )


@router.delete("/cache", response_model=TTSCacheClearResponse)
async def clear_tts_cache():
    """Clear all locally cached Read Aloud audio files."""
    from api.dependencies import get_tts_service
    service = get_tts_service()
    try:
        cleared = service.clear_cache()
    except Exception as e:
        logger.error(f"TTS cache clear failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Could not clear TTS cache: {e}")
    return TTSCacheClearResponse(cleared_files=cleared)
