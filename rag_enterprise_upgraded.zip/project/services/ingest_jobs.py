"""
services/ingest_jobs.py — In-memory registry for background ingestion jobs.

Ingestion can take a long time (large files, slow embedding model), and the
old flow blocked the request until every file was fully processed with no
way to stop it partway through. This module tracks one "job" per upload
batch so the frontend can:

  1. start a batch in the background (the HTTP request returns immediately),
  2. poll its progress,
  3. request cancellation, which takes effect at the next file boundary and
     rolls back anything already committed for that job.

This is intentionally a simple in-process dict, not a task queue — good
enough for a single-instance intranet deployment, and requires no new
infrastructure (Redis, Celery, etc.) to stay consistent with the rest of
the project.
"""

import threading
import time
import uuid
from typing import Dict, List, Optional


class IngestJob:
    def __init__(self, job_id: str, filenames: List[str]):
        self.job_id = job_id
        self.filenames = filenames          # original filenames, in upload order
        self.files_total = len(filenames)

        self.status = "running"             # running | done | done_with_errors | cancelled | error
        self.current_file: Optional[str] = None
        self.files_done = 0

        self.chunks_embedded = 0
        self.tabular_tables = 0
        self.tabular_rows = 0

        self.committed_files: List[str] = []   # saved-file basenames fully committed so far
        self.rolled_back_chunks = 0
        self.rolled_back_tables = 0

        self.errors: List[str] = []
        self.created_at = time.time()
        self.finished_at: Optional[float] = None

        self._cancel_event = threading.Event()
        self._lock = threading.Lock()

    # ── cancellation ──
    def request_cancel(self):
        self._cancel_event.set()

    def cancel_requested(self) -> bool:
        return self._cancel_event.is_set()

    # ── progress updates (called from the worker thread) ──
    def mark_file_started(self, name: str):
        with self._lock:
            self.current_file = name

    def mark_file_done(self, saved_name: str):
        with self._lock:
            self.committed_files.append(saved_name)
            self.files_done += 1
            self.current_file = None

    def add_stats(self, chunks: int = 0, tables: int = 0, rows: int = 0):
        with self._lock:
            self.chunks_embedded += chunks
            self.tabular_tables += tables
            self.tabular_rows += rows

    def add_error(self, message: str):
        with self._lock:
            self.errors.append(message)

    def finish(self, status: str, rolled_back_chunks: int = 0, rolled_back_tables: int = 0):
        with self._lock:
            self.status = status
            self.rolled_back_chunks = rolled_back_chunks
            self.rolled_back_tables = rolled_back_tables
            self.current_file = None
            self.finished_at = time.time()

    # ── serialization for the /status endpoint ──
    def to_dict(self) -> Dict:
        with self._lock:
            return {
                "job_id": self.job_id,
                "status": self.status,
                "files_total": self.files_total,
                "files_done": self.files_done,
                "current_file": self.current_file,
                "chunks_embedded": self.chunks_embedded,
                "tabular_tables": self.tabular_tables,
                "tabular_rows": self.tabular_rows,
                "cancel_requested": self.cancel_requested(),
                "rolled_back_chunks": self.rolled_back_chunks,
                "rolled_back_tables": self.rolled_back_tables,
                "errors": self.errors,
            }


_jobs: Dict[str, IngestJob] = {}
_jobs_lock = threading.Lock()

# Completed jobs are kept around briefly so a final status poll can still see
# them, then swept so this dict doesn't grow forever on a long-running server.
_JOB_TTL_SECONDS = 15 * 60


def create_job(filenames: List[str]) -> IngestJob:
    job = IngestJob(str(uuid.uuid4()), filenames)
    with _jobs_lock:
        _sweep_old_jobs()
        _jobs[job.job_id] = job
    return job


def get_job(job_id: str) -> Optional[IngestJob]:
    with _jobs_lock:
        return _jobs.get(job_id)


def _sweep_old_jobs():
    now = time.time()
    stale = [
        jid for jid, j in _jobs.items()
        if j.finished_at is not None and (now - j.finished_at) > _JOB_TTL_SECONDS
    ]
    for jid in stale:
        _jobs.pop(jid, None)
