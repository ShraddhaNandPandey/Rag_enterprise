"""
services/ingestion_service.py — Enterprise Ingestion Pipeline

Text files  → OCR if needed → Chunking → Embeddings → ChromaDB
CSV/Excel   → DuckDB (direct, no embedding)
"""

from pathlib import Path
from typing import List, Dict, Any

from loaders.file_loader import load_files, TABULAR_MARKER, PDF_TABLE_MARKER
from core.chunker import chunk_documents, chunk_stats
from vectorstore.chroma_store import VectorStore
from database.duckdb_manager import DuckDBManager
from config.settings import CHUNK_SIZE, CHUNK_OVERLAP, MIN_CHUNK_SIZE, MAX_CHUNK_SIZE
from utils.logger import get_logger

logger = get_logger("ingestion")


class IngestionService:
    """Routes text docs → ChromaDB and tabular files → DuckDB."""

    def __init__(self, vector_store: VectorStore, duckdb_manager: DuckDBManager):
        self.vector_store   = vector_store
        self.duckdb_manager = duckdb_manager

    def _clear_stale_data_for(self, file_paths: List[str]) -> None:
        """
        PROBLEM 5/6/7 (Document Isolation / stale ChromaDB & DuckDB data):
        before (re-)ingesting a file, remove anything already stored under
        that same filename — old semantic chunks in ChromaDB AND old DuckDB
        tables. Without this, re-uploading an updated version of a file (or
        the exact same file twice) silently accumulates duplicate chunks and
        duplicate/orphaned tables, and later queries can retrieve a mix of
        current and stale data for what looks like a single document.

        Safe no-op the first time a filename is ever ingested (nothing to
        clear). Never raises — a cleanup failure must not block ingestion.
        """
        for path in file_paths:
            name = Path(path).name
            try:
                removed_chunks = self.vector_store.delete_source(name)
                if removed_chunks:
                    logger.info(f"Cleared {removed_chunks} stale chunk(s) for '{name}' before re-ingestion")
            except Exception as e:
                logger.warning(f"Stale-chunk cleanup failed for '{name}': {e}")
            try:
                for tinfo in self.duckdb_manager.get_tables_by_source(name):
                    self.duckdb_manager.drop_table(tinfo["table_name"])
                    logger.info(f"Dropped stale table '{tinfo['table_name']}' for '{name}' before re-ingestion")
            except Exception as e:
                logger.warning(f"Stale-table cleanup failed for '{name}': {e}")

    def ingest(self, file_paths: List[str], chunk_size: int = CHUNK_SIZE, chunk_overlap: int = CHUNK_OVERLAP) -> Dict[str, Any]:
        logger.info(f"Starting ingestion of {len(file_paths)} file(s)")
        self._clear_stale_data_for(file_paths)

        try:
            all_docs = load_files(file_paths)
        except Exception as e:
            logger.error(f"load_files failed: {e}", exc_info=True)
            raise RuntimeError(f"Could not read uploaded files: {e}") from e

        # Files that loaded to zero docs (most commonly: an image whose OCR
        # pass found no readable text, or no OCR engine is available at all)
        # would otherwise disappear silently — 0 chunks, no error, and no way
        # to tell "nothing to ingest" apart from "ingestion is broken".
        from config.settings import IMAGE_EXTENSIONS
        loaded_names = {d.get("metadata", {}).get("source_name") for d in all_docs}
        empty_content_errors = []
        for path in file_paths:
            name = Path(path).name
            if name in loaded_names:
                continue
            if Path(path).suffix.lower() in IMAGE_EXTENSIONS:
                empty_content_errors.append(
                    f"{name}: no text could be extracted from this image — OCR ran but found "
                    f"nothing readable (or no OCR engine is available). Check System Health → OCR Engines."
                )
            else:
                empty_content_errors.append(f"{name}: no extractable content found in this file.")

        tabular_docs   = [d for d in all_docs if d.get("text") == TABULAR_MARKER]
        pdf_table_docs = [d for d in all_docs if d.get("text") == PDF_TABLE_MARKER]
        text_docs      = [d for d in all_docs
                           if d.get("text") not in (TABULAR_MARKER, PDF_TABLE_MARKER)]

        # Run tabular, PDF-table, and semantic ingestion independently so a
        # failure in one doesn't discard results already committed by another.
        try:
            tabular_stats = self._ingest_tabular(tabular_docs)
        except Exception as e:
            logger.error(f"Tabular ingestion stage failed: {e}", exc_info=True)
            tabular_stats = {"tables": 0, "rows": 0, "details": [], "error": str(e)}

        # PART 3/4/5: PDF tables → DuckDB (same engine as CSV/XLSX) + a short
        # semantic summary per table, which is merged into text_docs below so
        # it flows through the SAME, unmodified chunker/embedder (PART 2/9) —
        # never the raw table rows.
        try:
            pdf_table_stats = self._ingest_pdf_tables(pdf_table_docs)
        except Exception as e:
            logger.error(f"PDF table ingestion stage failed: {e}", exc_info=True)
            pdf_table_stats = {"tables": 0, "rows": 0, "details": [], "errors": [],
                                "summary_docs": [], "error": str(e)}

        text_docs_for_semantic = text_docs + pdf_table_stats.get("summary_docs", [])

        try:
            semantic_stats = self._ingest_semantic(text_docs_for_semantic, chunk_size, chunk_overlap)
        except Exception as e:
            logger.error(f"Semantic ingestion stage failed: {e}", exc_info=True)
            semantic_stats = {"docs": 0, "chunks": 0, "embedded": 0, "chunk_stats": {}, "error": str(e)}

        result = {
            "files_total": len(file_paths),
            "text_sections": semantic_stats["docs"],
            "chunks_created": semantic_stats["chunks"],
            "chunks_embedded": semantic_stats["embedded"],
            "tabular_tables": tabular_stats["tables"] + pdf_table_stats["tables"],
            "tabular_rows": tabular_stats["rows"] + pdf_table_stats["rows"],
            "chunk_stats": semantic_stats.get("chunk_stats", {}),
            "tabular_details": tabular_stats["details"] + pdf_table_stats["details"],
            # Additive/new — never removes or renames an existing key, so
            # existing API consumers are unaffected (PART 10).
            "pdf_tables_extracted": pdf_table_stats["tables"],
        }

        errors = []
        if "error" in tabular_stats:
            errors.append(f"tabular: {tabular_stats['error']}")
        if "error" in pdf_table_stats:
            errors.append(f"pdf_tables: {pdf_table_stats['error']}")
        if "error" in semantic_stats:
            errors.append(f"semantic: {semantic_stats['error']}")
        errors.extend(tabular_stats.get("errors", []))
        errors.extend(pdf_table_stats.get("errors", []))
        errors.extend(semantic_stats.get("errors", []))
        errors.extend(empty_content_errors)
        if errors:
            result["partial_errors"] = errors

        logger.info(
            f"Ingestion complete: {result['chunks_embedded']} chunks, "
            f"{result['tabular_tables']} tables ({pdf_table_stats['tables']} from PDFs)"
        )
        return result

    def ingest_with_control(self, file_paths: List[str], job,
                             chunk_size: int = CHUNK_SIZE, chunk_overlap: int = CHUNK_OVERLAP) -> None:
        """
        Same pipeline as ingest(), but processes one file at a time and checks
        job.cancel_requested() between files instead of committing everything
        in one batch. This is what makes "Stop ingesting" meaningful:

          - if cancellation is requested before a file starts, that file (and
            every file after it) is simply skipped — nothing to roll back.
          - files that finished embedding/loading *before* the cancel request
            arrived have already been committed to ChromaDB/DuckDB; those are
            rolled back afterwards via delete_document() so a cancelled batch
            never leaves partial chunks behind.

        Progress and the final result are written onto `job` (an IngestJob)
        rather than returned, since this runs on a background thread that the
        HTTP request already returned from.
        """
        was_cancelled = False

        for path in file_paths:
            if job.cancel_requested():
                was_cancelled = True
                break

            saved_name = Path(path).name
            job.mark_file_started(saved_name)
            self._clear_stale_data_for([path])

            try:
                docs = load_files([path])
            except Exception as e:
                logger.error(f"ingest_with_control: load_files failed for '{path}': {e}", exc_info=True)
                job.add_error(f"{saved_name}: could not read file ({e})")
                continue

            if not docs:
                # load_files() already logged the specific reason; surface a
                # user-facing hint here since a silent zero-doc result is
                # otherwise indistinguishable from "nothing to do" in the UI.
                # This is the single most common way images look "not
                # ingested": OCR ran but found no readable text (or no OCR
                # engine is actually available on this machine).
                ext = Path(path).suffix.lower()
                from config.settings import IMAGE_EXTENSIONS
                if ext in IMAGE_EXTENSIONS:
                    job.add_error(
                        f"{saved_name}: no text could be extracted from this image — "
                        f"OCR ran but found nothing readable (or no OCR engine is available). "
                        f"Check System Health → OCR Engines."
                    )
                else:
                    job.add_error(f"{saved_name}: no extractable content found in this file.")
                job.mark_file_done(saved_name)
                if job.cancel_requested():
                    was_cancelled = True
                    break
                continue

            tabular_docs   = [d for d in docs if d.get("text") == TABULAR_MARKER]
            pdf_table_docs = [d for d in docs if d.get("text") == PDF_TABLE_MARKER]
            text_docs      = [d for d in docs
                               if d.get("text") not in (TABULAR_MARKER, PDF_TABLE_MARKER)]

            try:
                pdf_summary_docs: List[Dict] = []
                if tabular_docs:
                    t_stats = self._ingest_tabular(tabular_docs)
                    job.add_stats(tables=t_stats["tables"], rows=t_stats["rows"])
                    for msg in t_stats.get("errors", []):
                        job.add_error(msg)
                if pdf_table_docs:
                    # PART 3/4/5: same DuckDB engine as CSV/XLSX, plus a short
                    # summary doc merged into this file's text_docs below so it
                    # rides the normal chunker/embedder — never raw table rows.
                    pt_stats = self._ingest_pdf_tables(pdf_table_docs)
                    job.add_stats(tables=pt_stats["tables"], rows=pt_stats["rows"])
                    for msg in pt_stats.get("errors", []):
                        job.add_error(msg)
                    pdf_summary_docs = pt_stats.get("summary_docs", [])
                if text_docs or pdf_summary_docs:
                    s_stats = self._ingest_semantic(text_docs + pdf_summary_docs, chunk_size, chunk_overlap)
                    job.add_stats(chunks=s_stats["embedded"])
                    for msg in s_stats.get("errors", []):
                        job.add_error(f"{saved_name}: {msg}")
            except Exception as e:
                logger.error(f"ingest_with_control: failed on '{saved_name}': {e}", exc_info=True)
                job.add_error(f"{saved_name}: {e}")
                continue

            # Only counted as "committed" (and therefore rollback-eligible) once
            # its chunks/tables actually made it into the stores above.
            job.mark_file_done(saved_name)

            # Re-check right after finishing this file too, so a cancel that
            # arrives mid-file doesn't wait for an extra file to complete.
            if job.cancel_requested():
                was_cancelled = True
                break

        if not was_cancelled:
            # Errors collected above (failed loads, tables that wouldn't parse,
            # chunks that failed to embed) don't stop the batch — but the job
            # must not be reported as a clean "done" when some of it silently
            # failed, or the user has no way to know part of their upload
            # never made it into the knowledge base.
            final_status = "done_with_errors" if job.errors else "done"
            logger.info(
                f"Ingestion job {job.job_id} complete ({final_status}): "
                f"{job.chunks_embedded} chunks, {job.tabular_tables} tables, "
                f"{len(job.errors)} error(s)"
            )
            job.finish(final_status)
            return

        # Cancelled: roll back every file this job actually committed so the
        # knowledge base ends up exactly as it was before the job started,
        # plus whatever finished before the stop request landed is removed too.
        rolled_back_chunks, rolled_back_tables = 0, 0
        for saved_name in job.committed_files:
            try:
                result = self.delete_document(saved_name)
                rolled_back_chunks += result.get("deleted_chunks", 0)
                rolled_back_tables += len(result.get("deleted_tables", []))
            except Exception as e:
                logger.error(f"ingest_with_control: rollback failed for '{saved_name}': {e}", exc_info=True)
                job.add_error(f"Could not fully roll back '{saved_name}': {e}")

        logger.info(
            f"Ingestion job {job.job_id} cancelled: rolled back "
            f"{rolled_back_chunks} chunks, {rolled_back_tables} tables "
            f"across {len(job.committed_files)} file(s)"
        )
        job.finish("cancelled", rolled_back_chunks=rolled_back_chunks, rolled_back_tables=rolled_back_tables)

    def _ingest_tabular(self, tabular_docs: List[Dict]) -> Dict[str, Any]:
        tables, rows, details, errors = 0, 0, [], []
        for doc in tabular_docs:
            meta  = doc["metadata"]
            path  = meta["source"]
            ftype = meta["type"]
            name  = Path(path).name
            # PROBLEM 5: carry document identity (stamped by load_files()) into
            # the DuckDB registry so a table can be traced back to the exact
            # ingested file version it came from.
            doc_id, content_hash, doc_version = meta.get("document_id"), meta.get("content_hash"), meta.get("doc_version")
            try:
                if ftype in ("csv", "tsv"):
                    info = self.duckdb_manager.load_csv(
                        path, document_id=doc_id, content_hash=content_hash, doc_version=doc_version)
                    tables += 1; rows += info["row_count"]; details.append(info)
                elif ftype in ("xlsx", "xlsm", "xls"):
                    infos = self.duckdb_manager.load_excel(
                        path, document_id=doc_id, content_hash=content_hash, doc_version=doc_version)
                    tables += len(infos)
                    for info in infos:
                        rows += info["row_count"]; details.append(info)
            except Exception as e:
                logger.error(f"Tabular ingestion failed '{path}': {e}")
                errors.append(f"{name}: could not load as a table ({e})")
        return {"tables": tables, "rows": rows, "details": details, "errors": errors}

    def _ingest_pdf_tables(self, pdf_table_docs: List[Dict]) -> Dict[str, Any]:
        """
        PART 3/4/5/6: Turn each extracted PDF table block into:
          (a) a DuckDB table, via the exact same DuckDBManager used for
              CSV/XLSX (PART 4 — "Both PDF tables and CSV tables should use
              the same DuckDB engine"), and
          (b) a short semantic-summary doc (table name / columns / row count)
              that the caller merges into the normal text_docs list so it
              flows through the UNCHANGED chunker/embedder (PART 2/9) and
              lands in ChromaDB — never the raw table rows (PART 5/9).

        Returns stats in the same shape as _ingest_tabular() (tables/rows/
        details/errors) plus "summary_docs" for the caller to merge in.
        """
        from core.table_summarizer import rows_to_dataframe, build_table_summary

        tables, rows_total, details, errors = 0, 0, [], []
        summary_docs: List[Dict[str, Any]] = []

        for doc in pdf_table_docs:
            meta = doc.get("metadata", {})
            source_name = meta.get("source_name", "unknown.pdf")
            source_path = meta.get("source", source_name)
            page = meta.get("page", 0)
            # PHASE 2: heading/section are now tracked separately (nearest
            # specific heading vs. enclosing top-level section) — see
            # loaders/file_loader.py's two-level hierarchy.
            heading = meta.get("heading") or ""
            section = meta.get("section") or heading
            parent_section = meta.get("parent_section", "")
            table_idx = meta.get("table_index", 1)
            raw_rows = meta.get("rows", [])

            try:
                df = rows_to_dataframe(raw_rows)
                if df.empty:
                    logger.warning(f"PDF table on '{source_name}' page {page} produced no usable rows, skipping.")
                    continue

                base_name = f"{Path(source_name).stem}_p{page}_t{table_idx}"
                # NOTE: register_table() cleans column names in place (lowercases,
                # strips punctuation, de-duplicates) and mutates `df` itself — so
                # `df.columns` below already reflects the exact column names the
                # DuckDB table was created with. Keep this call BEFORE
                # build_table_summary() so the embedded summary text never
                # drifts out of sync with the real table schema.
                table_name = self.duckdb_manager.register_table(
                    df, base_name, source_file=source_path,
                    document_id=meta.get("document_id"), content_hash=meta.get("content_hash"),
                    doc_version=meta.get("doc_version"))

                tables += 1
                rows_total += len(df)
                details.append({
                    "table_name":  table_name,
                    "source_file": source_path,
                    "sheet_name":  None,
                    "row_count":   len(df),
                    "col_count":   len(df.columns),
                    "columns":     list(df.columns),
                })

                summary_text = build_table_summary(
                    table_name=table_name, df=df, source_name=source_name,
                    page=page, heading=heading, section=section,
                )
                # PART 6: metadata carries document/page/section/heading/type/
                # table-name/source-file so retrieval and citations can point
                # straight back to both the summary AND the exact DuckDB table.
                summary_docs.append({
                    "text": summary_text,
                    "metadata": {
                        "source":         source_path,
                        "source_name":    source_name,
                        "type":           "pdf_table_summary",
                        "page":           page,
                        "heading":        heading,
                        "section":        section,
                        "parent_section": parent_section,
                        "block_type":     "table_summary",
                        "duckdb_table":   table_name,
                    },
                })
            except Exception as e:
                logger.error(f"PDF table ingestion failed for '{source_name}' page {page}: {e}", exc_info=True)
                errors.append(f"{source_name} (page {page}): could not load table into DuckDB ({e})")

        return {"tables": tables, "rows": rows_total, "details": details,
                "errors": errors, "summary_docs": summary_docs}

    def _ingest_semantic(self, text_docs: List[Dict], chunk_size: int, chunk_overlap: int) -> Dict[str, Any]:
        if not text_docs:
            return {"docs": 0, "chunks": 0, "embedded": 0, "errors": []}
        chunks = chunk_documents(text_docs, chunk_size=chunk_size, chunk_overlap=chunk_overlap,
                                  min_chunk_size=MIN_CHUNK_SIZE, max_chunk_size=MAX_CHUNK_SIZE)
        stats    = chunk_stats(chunks)
        total    = stats.get("total_chunks", 0)
        embedded = self.vector_store.add_chunks(chunks)

        errors = []
        if total and embedded < total:
            failed = total - embedded
            if embedded == 0:
                errors.append(
                    f"all {total} chunk(s) failed to embed — check Ollama is running and "
                    f"reachable, and that the embedding model is installed"
                )
            else:
                errors.append(
                    f"{failed} of {total} chunk(s) failed to embed (embedded {embedded}) — "
                    f"the document was only partially indexed"
                )
        return {"docs": len(text_docs), "chunks": total, "embedded": embedded,
                "chunk_stats": stats, "errors": errors}

    def get_ingestion_summary(self) -> Dict[str, Any]:
        try:
            vs = self.vector_store.get_stats()
        except Exception as e:
            logger.error(f"get_ingestion_summary: vector_store.get_stats() failed: {e}", exc_info=True)
            vs = {"total_chunks": 0, "unique_sources": 0, "sources": []}

        try:
            tables = self.duckdb_manager.list_tables()
        except Exception as e:
            logger.error(f"get_ingestion_summary: duckdb_manager.list_tables() failed: {e}", exc_info=True)
            tables = []

        return {"vector_store": vs, "tabular_tables": tables,
                "has_semantic": vs.get("total_chunks", 0) > 0, "has_tabular": len(tables) > 0}

    def get_knowledge_base(self) -> Dict[str, Any]:
        """
        Build a unified per-document view merging ChromaDB and DuckDB.
        Returns one KBDocument per unique filename across both stores.
        If one backend fails, still returns data from the other rather than
        failing the whole view.
        """
        from collections import defaultdict

        docs: Dict[str, Dict] = defaultdict(lambda: {
            "name": "", "doc_type": "semantic",
            "chunk_count": 0, "tables": []
        })

        # Semantic docs from ChromaDB
        try:
            semantic_entries = self.vector_store.get_knowledge_base()
        except Exception as e:
            logger.error(f"get_knowledge_base: vector_store.get_knowledge_base() failed: {e}", exc_info=True)
            semantic_entries = []

        for entry in semantic_entries:
            name = entry["source_name"]
            docs[name]["name"]        = name
            docs[name]["chunk_count"] = entry["chunk_count"]
            docs[name]["doc_type"]    = "semantic"

        # Tabular docs from DuckDB
        try:
            table_names = self.duckdb_manager.list_tables()
        except Exception as e:
            logger.error(f"get_knowledge_base: duckdb_manager.list_tables() failed: {e}", exc_info=True)
            table_names = []

        for tname in table_names:
            try:
                info = self.duckdb_manager.get_table_info(tname)
            except Exception as e:
                logger.warning(f"get_table_info failed for '{tname}': {e}")
                continue
            if not info:
                continue
            name = Path(info["source_file"]).name
            if name in docs:
                docs[name]["doc_type"] = "both"
            else:
                docs[name]["name"]     = name
                docs[name]["doc_type"] = "tabular"
            docs[name]["tables"].append(info)

        doc_list = sorted(docs.values(), key=lambda d: d["name"])
        total_chunks = sum(d["chunk_count"] for d in doc_list)
        total_tables = sum(len(d["tables"]) for d in doc_list)

        return {
            "documents":    doc_list,
            "total_files":  len(doc_list),
            "total_chunks": total_chunks,
            "total_tables": total_tables,
        }

    def delete_document(self, doc_name: str) -> Dict[str, Any]:
        """
        Fully remove a document from every store:
          - ChromaDB embeddings + BM25 index
          - All DuckDB tables whose source file matches doc_name
          - Registry metadata entries

        Each store is attempted independently — a failure in one does not
        prevent deletion from the other, and is reported in 'errors'.
        """
        errors = []

        # 1. Remove from ChromaDB + BM25
        try:
            deleted_chunks = self.vector_store.delete_source(doc_name)
        except Exception as e:
            logger.error(f"delete_document: vector_store.delete_source failed for '{doc_name}': {e}", exc_info=True)
            deleted_chunks = 0
            errors.append(f"ChromaDB deletion failed: {e}")

        # 2. Find and drop all DuckDB tables for this file
        deleted_tables: List[str] = []
        try:
            tables_info = self.duckdb_manager.get_tables_by_source(doc_name)
        except Exception as e:
            logger.error(f"delete_document: get_tables_by_source failed for '{doc_name}': {e}", exc_info=True)
            tables_info = []
            errors.append(f"DuckDB lookup failed: {e}")

        for info in tables_info:
            try:
                if self.duckdb_manager.drop_table(info["table_name"]):
                    deleted_tables.append(info["table_name"])
            except Exception as e:
                logger.error(f"delete_document: drop_table failed for '{info['table_name']}': {e}", exc_info=True)
                errors.append(f"Could not drop table '{info['table_name']}': {e}")

        total = deleted_chunks + len(deleted_tables)
        logger.info(
            f"Deleted '{doc_name}': {deleted_chunks} chunks, "
            f"{len(deleted_tables)} tables {deleted_tables}"
        )

        result = {
            "success":        total > 0,
            "document":       doc_name,
            "deleted_chunks": deleted_chunks,
            "deleted_tables": deleted_tables,
            "message": (
                f"Removed {deleted_chunks} chunk(s) from ChromaDB and "
                f"{len(deleted_tables)} table(s) from DuckDB."
                if total > 0 else
                (f"Could not verify or delete '{doc_name}' due to backend errors."
                 if errors else
                 f"'{doc_name}' not found in any store.")
            ),
        }
        if errors:
            result["errors"] = errors
        return result
