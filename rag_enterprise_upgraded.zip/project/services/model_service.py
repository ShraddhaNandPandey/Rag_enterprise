"""
services/model_service.py — Ollama Model Management Service

Responsibilities:
  - List all locally installed Ollama models
  - Validate a model exists before switching
  - Switch active LLM model at runtime (no server restart needed)
  - Persist the new model name to .env
  - Provide typed error taxonomy for the UI

Industry-standard error handling:
  OllamaUnavailableError  — Ollama process not running
  ModelNotFoundError      — model name not in ollama list
  ModelSwitchError        — model found but failed to load/respond
"""

import json
import urllib.request
import urllib.error
from typing import Optional, Tuple

from config.settings import OLLAMA_BASE_URL, LLM_MODEL, EMBED_MODEL, BASE_DIR
from utils.logger import get_logger

logger = get_logger("model_service")


# ─── Typed Exceptions ─────────────────────────────────────────────────────────

class OllamaUnavailableError(RuntimeError):
    """Ollama process is not reachable at the configured URL."""

class ModelNotFoundError(ValueError):
    """Model name is not in the locally installed Ollama model list."""

class ModelSwitchError(RuntimeError):
    """Model is installed but failed to load or respond to a test prompt."""


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _ollama_get(path: str, timeout: int = 5) -> dict:
    """GET from Ollama API. Raises OllamaUnavailableError on connection failure."""
    req = urllib.request.Request(f"{OLLAMA_BASE_URL}{path}", method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.URLError as e:
        raise OllamaUnavailableError(
            f"Cannot reach Ollama at {OLLAMA_BASE_URL}. "
            f"Make sure it is running: ollama serve\n(Detail: {e})"
        )
    except Exception as e:
        raise OllamaUnavailableError(f"Ollama request failed: {e}")


def _format_size(bytes_: int) -> Optional[float]:
    if not bytes_:
        return None
    return round(bytes_ / (1024 ** 3), 2)


def _parse_model_entry(m: dict, current_llm: str, current_embed: str) -> dict:
    """Parse one entry from /api/tags into a clean OllamaModel-compatible dict."""
    name         = m.get("name", "")
    display_name = name.split(":")[0]
    details      = m.get("details", {})
    return {
        "name":           name,
        "display_name":   display_name,
        "family":         details.get("family"),
        "parameter_size": details.get("parameter_size"),
        "quantization":   details.get("quantization_level"),
        "size_gb":        _format_size(m.get("size", 0)),
        "is_current":     display_name == current_llm.split(":")[0],
        "is_embed":       display_name == current_embed.split(":")[0],
    }


def _write_env_key(key: str, value: str) -> None:
    """
    Update a single key in the project .env file.
    If key does not exist, it is appended. If .env itself doesn't exist yet
    (e.g. a fresh checkout that only has .env.example), it is created.
    """
    env_path = BASE_DIR / ".env"
    try:
        lines = env_path.read_text(encoding="utf-8").splitlines(keepends=True) if env_path.exists() else []
        found = False
        new_lines = []
        for line in lines:
            if line.startswith(f"{key}="):
                new_lines.append(f"{key}={value}\n")
                found = True
            else:
                new_lines.append(line)
        if not found:
            new_lines.append(f"{key}={value}\n")
        env_path.write_text("".join(new_lines), encoding="utf-8")
        logger.info(f".env updated: {key}={value}")
    except Exception as e:
        logger.warning(f"Could not persist {key} to .env: {e}")


# ─── ModelService ─────────────────────────────────────────────────────────────

class ModelService:
    """Runtime model management — list, validate, switch without restart."""

    def __init__(
        self,
        ollama_url: str = OLLAMA_BASE_URL,
        current_llm: str = LLM_MODEL,
        current_embed: str = EMBED_MODEL,
    ):
        self.ollama_url    = ollama_url
        self.current_llm   = current_llm
        self.current_embed = current_embed

    # ── Public API ────────────────────────────────────────────────────────────

    def list_models(self) -> dict:
        """
        Return all locally installed Ollama models.
        Never raises — returns error field on failure so UI can display it.
        """
        try:
            data   = _ollama_get("/api/tags", timeout=5)
            models = [
                _parse_model_entry(m, self.current_llm, self.current_embed)
                for m in data.get("models", [])
            ]
            # Sort: current first, then alphabetical
            models.sort(key=lambda m: (not m["is_current"], m["display_name"]))
            return {
                "models":           models,
                "current_llm":      self.current_llm,
                "current_embed":    self.current_embed,
                "ollama_available": True,
                "error":            None,
            }
        except OllamaUnavailableError as e:
            logger.warning(f"list_models: {e}")
            return {
                "models":           [],
                "current_llm":      self.current_llm,
                "current_embed":    self.current_embed,
                "ollama_available": False,
                "error":            str(e),
            }
        except Exception as e:
            logger.error(f"list_models unexpected: {e}", exc_info=True)
            return {
                "models":           [],
                "current_llm":      self.current_llm,
                "current_embed":    self.current_embed,
                "ollama_available": False,
                "error":            f"Unexpected error: {e}",
            }

    def validate_model(self, model_name: str) -> Tuple[bool, str]:
        """
        Check a model is installed locally.
        Returns (True, "") or (False, human-readable reason).
        """
        try:
            data       = _ollama_get("/api/tags", timeout=5)
            installed  = [m.get("name","") for m in data.get("models", [])]
            # Match by full name or by base name (without tag)
            base_names = [n.split(":")[0] for n in installed]
            model_base = model_name.split(":")[0]
            if model_name in installed or model_base in base_names:
                return True, ""
            # Build helpful suggestion
            llm_models = [
                n for n in installed
                if not any(kw in n for kw in ["embed", "bert", "clip", "vision"])
            ]
            suggestion = ""
            if llm_models:
                suggestion = f" Available LLMs: {', '.join(llm_models[:5])}"
            return False, (
                f"Model '{model_name}' is not installed in Ollama. "
                f"Run: ollama pull {model_name}{suggestion}"
            )
        except OllamaUnavailableError as e:
            return False, str(e)
        except Exception as e:
            return False, f"Validation error: {e}"

    def switch_model(self, model_name: str, query_service) -> dict:
        """
        Switch the active LLM model at runtime.

        Steps:
          1. Validate model is installed  → ModelNotFoundError if not
          2. Send a minimal test prompt   → ModelSwitchError if it fails
          3. Update QueryService.model + QueryRouter.model in place
          4. Persist to .env
          5. Return ModelSwitchResponse-compatible dict

        The query_service is mutated in-place — no restart required.
        """
        model_name = model_name.strip()
        if not model_name:
            raise ValueError("Model name cannot be empty.")

        previous = self.current_llm

        # ── Step 1: validate installed ────────────────────────────────────────
        ok, reason = self.validate_model(model_name)
        if not ok:
            raise ModelNotFoundError(reason)

        # ── Step 2: smoke-test the model responds ─────────────────────────────
        try:
            self._smoke_test(model_name)
        except Exception as e:
            raise ModelSwitchError(
                f"Model '{model_name}' is installed but failed to respond: {e}\n"
                f"Try: ollama run {model_name}"
            )

        # ── Step 3: hot-swap model in QueryService + QueryRouter ──────────────
        query_service.model         = model_name
        query_service.router.model  = model_name
        self.current_llm            = model_name

        # ── Step 4: persist to .env ───────────────────────────────────────────
        _write_env_key("LLM_MODEL", model_name)

        logger.info(f"Model switched: {previous} → {model_name}")
        return {
            "success":        True,
            "model_name":     model_name,
            "previous_model": previous,
            "message":        f"Switched from '{previous}' to '{model_name}' successfully.",
            "warning":        None,
        }

    def get_current(self) -> dict:
        """Return current model config with live Ollama availability check."""
        try:
            _ollama_get("/api/tags", timeout=3)
            ollama_ok = True
        except OllamaUnavailableError:
            ollama_ok = False
        return {
            "current_llm":      self.current_llm,
            "current_embed":    self.current_embed,
            "ollama_available": ollama_ok,
        }

    # ── Private ───────────────────────────────────────────────────────────────

    def _smoke_test(self, model_name: str, timeout: int = 60) -> None:
        """
        Send a minimal 1-token generate request to confirm the model loads.
        Uses num_predict=1 so it returns in <5s for most models.
        """
        payload = json.dumps({
            "model":   model_name,
            "prompt":  "Hi",
            "stream":  False,
            "options": {"num_predict": 1, "temperature": 0},
        }).encode()
        req = urllib.request.Request(
            f"{self.ollama_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read())
                if "error" in data:
                    raise ModelSwitchError(data["error"])
        except urllib.error.URLError as e:
            raise OllamaUnavailableError(str(e))
