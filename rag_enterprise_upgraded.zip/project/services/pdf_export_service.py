"""
services/pdf_export_service.py — Renders one chat Q&A turn as a
professionally formatted, offline PDF report.

Fully offline: uses ReportLab (BSD-licensed, pure Python/C, no network calls)
plus local TTF fonts (bundled or system). No cloud PDF services, no CDN
fonts, no telemetry — safe for air-gapped / defence intranet deployments.

Used by routers/export_router.py for the chat UI's "Download" button.
"""

import functools
import io
import re
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.platypus import (
    HRFlowable, KeepTogether, ListFlowable, ListItem, Paragraph, SimpleDocTemplate,
    Spacer, Table, TableStyle,
)

from config.settings import API_TITLE, API_VERSION, EMBED_MODEL, LLM_MODEL, ORG_NAME, PDF_FONTS_DIR
from models.schemas import PDFExportMeta, PDFExportRequest, PDFSourceItem
from utils.logger import get_logger

logger = get_logger("pdf_export")

# ═══════════════════════════ Offline fonts ═══════════════════════════════════
# Registers bundled/system Unicode TTFs (Noto Sans / DejaVu Sans / Liberation)
# so PDFs render identically on every intranet host and support non-Latin
# text. Falls back to ReportLab's built-in Helvetica/Courier (Latin-1 only,
# but zero external dependency) if no TTF can be found anywhere.

_FONT_REGULAR = "Helvetica"
_FONT_BOLD = "Helvetica-Bold"
_FONT_MONO = "Courier"
_FONT_MONO_BOLD = "Courier-Bold"
_fonts_ready = False


def _candidate_font_dirs() -> List[Path]:
    dirs = []
    if PDF_FONTS_DIR:
        dirs.append(Path(PDF_FONTS_DIR))
    dirs += [
        Path("/usr/share/fonts/truetype/dejavu"),
        Path("/usr/share/fonts/truetype/liberation"),
        Path("/usr/share/fonts/truetype/liberation2"),
        Path("/usr/share/fonts/opentype/noto"),
        Path("/usr/share/fonts/truetype/noto"),
        Path("C:/Windows/Fonts"),
    ]
    return dirs


def _find_font(filenames: Sequence[str]) -> Optional[Path]:
    for d in _candidate_font_dirs():
        try:
            if not d.is_dir():
                continue
        except OSError:
            continue
        for name in filenames:
            p = d / name
            if p.is_file():
                return p
    return None


def _register_fonts() -> None:
    """Idempotent. Registers offline Unicode fonts once per process."""
    global _FONT_REGULAR, _FONT_BOLD, _FONT_MONO, _FONT_MONO_BOLD, _fonts_ready
    if _fonts_ready:
        return
    _fonts_ready = True

    regular = _find_font(["NotoSans-Regular.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"])
    bold = _find_font(["NotoSans-Bold.ttf", "DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf"])
    mono = _find_font(["NotoSansMono-Regular.ttf", "DejaVuSansMono.ttf", "LiberationMono-Regular.ttf"])
    mono_bold = _find_font(["NotoSansMono-Bold.ttf", "DejaVuSansMono-Bold.ttf", "LiberationMono-Bold.ttf"])

    try:
        if regular and bold:
            pdfmetrics.registerFont(TTFont("PDFSans", str(regular)))
            pdfmetrics.registerFont(TTFont("PDFSans-Bold", str(bold)))
            _FONT_REGULAR, _FONT_BOLD = "PDFSans", "PDFSans-Bold"
        else:
            logger.warning(
                "PDF export: no offline Unicode TTF found for body text; falling back to "
                "Helvetica (Latin-1 only). Set PDF_FONTS_DIR or install fonts-dejavu-core."
            )
        if mono:
            pdfmetrics.registerFont(TTFont("PDFMono", str(mono)))
            _FONT_MONO = "PDFMono"
            if mono_bold:
                pdfmetrics.registerFont(TTFont("PDFMono-Bold", str(mono_bold)))
                _FONT_MONO_BOLD = "PDFMono-Bold"
            else:
                _FONT_MONO_BOLD = "PDFMono"
        else:
            logger.warning("PDF export: no offline monospace TTF found for code blocks; falling back to Courier.")
    except Exception as e:
        logger.error(f"PDF export: font registration failed, using Helvetica/Courier fallback: {e}")
        _FONT_REGULAR, _FONT_BOLD, _FONT_MONO, _FONT_MONO_BOLD = (
            "Helvetica", "Helvetica-Bold", "Courier", "Courier-Bold",
        )


def _build_styles() -> dict:
    accent = colors.HexColor("#1F3B57")
    ink = colors.HexColor("#111827")
    muted = colors.HexColor("#6B7280")
    return {
        "Brand": ParagraphStyle("Brand", fontName=_FONT_BOLD, fontSize=16, textColor=accent, spaceAfter=2),
        "OrgSub": ParagraphStyle("OrgSub", fontName=_FONT_REGULAR, fontSize=10, textColor=muted),
        "ReportTitle": ParagraphStyle("ReportTitle", fontName=_FONT_BOLD, fontSize=14, textColor=ink, spaceAfter=2),
        "Small": ParagraphStyle("Small", fontName=_FONT_REGULAR, fontSize=8.5, textColor=muted),
        "H1": ParagraphStyle("H1", fontName=_FONT_BOLD, fontSize=14, textColor=accent, spaceBefore=10, spaceAfter=6),
        "H2": ParagraphStyle("H2", fontName=_FONT_BOLD, fontSize=12.5, textColor=accent, spaceBefore=10, spaceAfter=6),
        "H3": ParagraphStyle("H3", fontName=_FONT_BOLD, fontSize=11, textColor=accent, spaceBefore=8, spaceAfter=4),
        "H4": ParagraphStyle("H4", fontName=_FONT_BOLD, fontSize=10, textColor=accent, spaceBefore=6, spaceAfter=4),
        "Body": ParagraphStyle("Body", fontName=_FONT_REGULAR, fontSize=10, leading=14.5, textColor=ink),
        "QuestionBody": ParagraphStyle("QuestionBody", fontName=_FONT_BOLD, fontSize=10.5, leading=15, textColor=accent),
        "Code": ParagraphStyle("Code", fontName=_FONT_MONO, fontSize=8.5, leading=12.5, textColor=colors.HexColor("#1F2937")),
        "TableHeader": ParagraphStyle("TableHeader", fontName=_FONT_BOLD, fontSize=9, leading=11, textColor=colors.white),
        "TableCell": ParagraphStyle("TableCell", fontName=_FONT_REGULAR, fontSize=9, leading=12.5, textColor=ink),
        "Mono": ParagraphStyle("Mono", fontName=_FONT_MONO, fontSize=8.5, leading=12, textColor=ink),
        "MonoBold": ParagraphStyle("MonoBold", fontName=_FONT_MONO_BOLD, fontSize=8.5, leading=12, textColor=accent),
    }


# ═══════════════════════ Markdown-lite → flowables ═══════════════════════════
# Mirrors the same lightweight grammar the chat UI uses to render answers
# (static/js/app.js:renderRichText) — fenced code, GFM pipe tables, bullet /
# numbered lists, **bold**, `inline code` — plus headings and horizontal
# rules for a more complete printed report.

_CODE_FENCE_RE = re.compile(r"```([\s\S]*?)```")


def _esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _is_table_row(l: str) -> bool:
    return "|" in l and l.strip() != ""


def _is_table_sep(l: str) -> bool:
    return bool(re.match(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$", l))


def _is_bullet(l: str) -> bool:
    return bool(re.match(r"^\s*[-*]\s+", l))


def _is_ordered(l: str) -> bool:
    return bool(re.match(r"^\s*\d+[.)]\s+", l))


def _is_heading(l: str) -> bool:
    return bool(re.match(r"^\s{0,3}#{1,6}\s+\S", l))


def _is_hr(l: str) -> bool:
    return bool(re.match(r"^\s*([-*_])\1{2,}\s*$", l))


def _split_row(l: str) -> List[str]:
    s = l.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]


def _inline(s: str) -> str:
    s = _esc(s)
    s = re.sub(r"`([^`]+)`", lambda m: f'<font face="{_FONT_MONO}" color="#B3261E">{m.group(1)}</font>', s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", s)
    return s


def _escape_code_line(line: str) -> str:
    """Preserve leading indentation (non-breaking) while keeping interior
    spaces breakable, so long code still wraps instead of clipping."""
    stripped = line.lstrip(" ")
    n_lead = len(line) - len(stripped)
    return ("&nbsp;" * n_lead) + _esc(stripped)


def _build_code_block(code: str, styles: dict, content_width: float) -> Table:
    lines = code.split("\n")
    # Strip a bare ```lang tag line, if present, for a cleaner printed block.
    if len(lines) > 1 and re.match(r"^[a-zA-Z0-9_+-]{1,20}$", lines[0].strip()):
        lines = lines[1:]
    code = "\n".join(lines).strip("\n")
    html = "<br/>".join(_escape_code_line(l) for l in code.split("\n")) or "&nbsp;"
    para = Paragraph(html, styles["Code"])
    tbl = Table([[para]], colWidths=[content_width])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F4F5F7")),
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#D1D5DB")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return tbl


def _build_gfm_table(header: List[str], rows: List[List[str]], styles: dict, content_width: float) -> Table:
    ncols = max(1, len(header))
    col_width = content_width / ncols
    data = [[Paragraph(_inline(h), styles["TableHeader"]) for h in header]]
    for r in rows:
        data.append([Paragraph(_inline(r[ci] if ci < len(r) else ""), styles["TableCell"]) for ci in range(ncols)])
    tbl = Table(data, colWidths=[col_width] * ncols, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3B57")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D1D5DB")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
    ]))
    return tbl


def _build_list(items: List[str], styles: dict, ordered: bool) -> ListFlowable:
    list_items = [ListItem(Paragraph(_inline(it), styles["Body"]), leftIndent=6, spaceBefore=2) for it in items]
    kwargs = dict(
        leftIndent=16,
        bulletFontName=_FONT_REGULAR,
        bulletFontSize=9,
        spaceBefore=2,
        spaceAfter=8,
    )
    if ordered:
        kwargs.update(bulletType="1", start="1")
    else:
        kwargs.update(bulletType="bullet", bulletChar="•")
    return ListFlowable(list_items, **kwargs)


def _md_to_flowables(text: str, styles: dict, content_width: float) -> list:
    if not text or not text.strip():
        return [Paragraph("<i>(empty response)</i>", styles["Body"])]

    code_blocks: List[str] = []

    def _stash(m):
        code_blocks.append(m.group(1))
        return f"\x00CODEBLOCK{len(code_blocks) - 1}\x00"

    text_wo_code = _CODE_FENCE_RE.sub(_stash, text)
    lines = text_wo_code.split("\n")

    parts = []
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]

        if line.strip() == "":
            i += 1
            continue

        code_m = re.match(r"^\s*\x00CODEBLOCK(\d+)\x00\s*$", line)
        if code_m:
            parts.append(Spacer(1, 4))
            parts.append(_build_code_block(code_blocks[int(code_m.group(1))], styles, content_width))
            parts.append(Spacer(1, 8))
            i += 1
            continue

        if _is_table_row(line) and i + 1 < n and _is_table_sep(lines[i + 1]):
            header = _split_row(line)
            j = i + 2
            rows = []
            while j < n and _is_table_row(lines[j]) and not _is_table_sep(lines[j]):
                rows.append(_split_row(lines[j]))
                j += 1
            parts.append(_build_gfm_table(header, rows, styles, content_width))
            parts.append(Spacer(1, 8))
            i = j
            continue

        if _is_bullet(line):
            items = []
            while i < n and _is_bullet(lines[i]):
                items.append(re.sub(r"^\s*[-*]\s+", "", lines[i]))
                i += 1
            parts.append(_build_list(items, styles, ordered=False))
            continue

        if _is_ordered(line):
            items = []
            while i < n and _is_ordered(lines[i]):
                items.append(re.sub(r"^\s*\d+[.)]\s+", "", lines[i]))
                i += 1
            parts.append(_build_list(items, styles, ordered=True))
            continue

        if _is_heading(line):
            hm = re.match(r"^\s{0,3}(#{1,6})\s+(.*)$", line)
            level = len(hm.group(1))
            style_name = {1: "H1", 2: "H2", 3: "H3"}.get(level, "H4")
            parts.append(Paragraph(_inline(hm.group(2).strip()), styles[style_name]))
            i += 1
            continue

        if _is_hr(line):
            parts.append(HRFlowable(width="100%", thickness=0.75, color=colors.HexColor("#D1D5DB"),
                                     spaceBefore=6, spaceAfter=10))
            i += 1
            continue

        # Plain paragraph: consume consecutive lines until a blank line or the
        # start of another block type.
        para_lines = []
        while (
            i < n and lines[i].strip() != ""
            and not _is_bullet(lines[i]) and not _is_ordered(lines[i])
            and not _is_heading(lines[i]) and not _is_hr(lines[i])
            and not re.match(r"^\s*\x00CODEBLOCK\d+\x00\s*$", lines[i])
            and not (_is_table_row(lines[i]) and i + 1 < n and _is_table_sep(lines[i + 1]))
        ):
            para_lines.append(lines[i])
            i += 1
        if para_lines:
            parts.append(Paragraph("<br/>".join(_inline(pl) for pl in para_lines), styles["Body"]))
            parts.append(Spacer(1, 6))

    return parts or [Paragraph("<i>(empty response)</i>", styles["Body"])]


# ═══════════════════════════ Page footer (X of Y) ════════════════════════════

class _FooterCanvas(pdfcanvas.Canvas):
    """Draws 'Generated by ... / Model ... / Page X of Y' on every page.
    Standard two-pass ReportLab recipe: buffer page states, then redraw each
    with the final page count known."""

    def __init__(self, *args, footer_text_fn=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []
        self._footer_text_fn = footer_text_fn

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_footer(total)
            super().showPage()
        super().save()

    def _draw_footer(self, total: int) -> None:
        if not self._footer_text_fn:
            return
        try:
            line1, line2 = self._footer_text_fn(self._pageNumber, total)
        except Exception:
            return
        width, _height = self._pagesize
        self.setStrokeColor(colors.HexColor("#D1D5DB"))
        self.setLineWidth(0.5)
        self.line(20 * mm, 20 * mm, width - 20 * mm, 20 * mm)
        self.setFont(_FONT_REGULAR, 7.5)
        self.setFillColor(colors.HexColor("#6B7280"))
        self.drawCentredString(width / 2, 15 * mm, line1)
        self.drawCentredString(width / 2, 11 * mm, line2)


# ═══════════════════════════ Filename + misc helpers ═════════════════════════

def _slugify_question(question: str, max_words: int = 5) -> str:
    words = re.findall(r"[A-Za-z0-9]+", question or "")[:max_words]
    if not words:
        return ""
    return "".join(w.capitalize() for w in words)[:60]


def build_export_filename(question: str, generated_dt: datetime) -> str:
    slug = _slugify_question(question)
    ts = generated_dt.strftime("%Y-%m-%d_%H-%M")
    return f"EnterpriseRAG_{slug}_{ts}.pdf" if slug else f"EnterpriseRAG_{ts}.pdf"


def _split_model_version(model_str: Optional[str]) -> Tuple[str, Optional[str]]:
    if not model_str:
        return "—", None
    if ":" in model_str:
        name, ver = model_str.split(":", 1)
        return name, ver
    return model_str, None


def _source_label(s) -> str:
    if isinstance(s, PDFSourceItem):
        bits = [s.name]
        if s.doc_type:
            bits.append(s.doc_type)
        if s.page is not None:
            bits.append(f"page {s.page}")
        if s.sheet:
            bits.append(f"sheet '{s.sheet}'")
        if s.confidence is not None:
            bits.append(f"confidence {round(s.confidence * 100)}%")
        return " — ".join(bits)
    if isinstance(s, dict):
        bits = [s.get("name") or s.get("file_name") or "unnamed"]
        if s.get("doc_type"):
            bits.append(s["doc_type"])
        if s.get("page") is not None:
            bits.append(f"page {s['page']}")
        if s.get("sheet"):
            bits.append(f"sheet '{s['sheet']}'")
        if s.get("confidence") is not None:
            bits.append(f"confidence {round(s['confidence'] * 100)}%")
        return " — ".join(bits)
    return str(s)


# ═══════════════════════════ Main entry point ════════════════════════════════

def generate_pdf_report(req: PDFExportRequest) -> Tuple[bytes, str]:
    """Render one Q&A turn as a PDF. Returns (pdf_bytes, suggested_filename)."""
    _register_fonts()
    styles = _build_styles()

    now = datetime.now()
    generated_label = now.strftime("%d %B %Y %H:%M")

    org = (req.organization or ORG_NAME or "").strip() or ORG_NAME
    report_title = (req.report_title or "AI Response Report").strip()
    meta: PDFExportMeta = req.meta or PDFExportMeta()

    llm_model_raw = meta.llm_model or LLM_MODEL
    embed_model = meta.embedding_model or EMBED_MODEL
    model_name, model_version = _split_model_version(llm_model_raw)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=26 * mm,
        title=report_title, author=org,
    )
    content_width = doc.width

    story = []

    # ── Header ──────────────────────────────────────────────────────────
    story.append(Paragraph(_esc(API_TITLE), styles["Brand"]))
    story.append(Paragraph(_esc(org), styles["OrgSub"]))
    story.append(Spacer(1, 6))
    story.append(HRFlowable(width="100%", thickness=1.2, color=colors.HexColor("#1F3B57")))
    story.append(Spacer(1, 10))
    story.append(Paragraph(_esc(report_title), styles["ReportTitle"]))
    story.append(Paragraph(f"Exported: {_esc(generated_label)}", styles["Small"]))
    story.append(Spacer(1, 16))

    # ── Question ────────────────────────────────────────────────────────
    story.append(Paragraph("User Question", styles["H2"]))
    q_html = _esc(req.question).replace("\n", "<br/>")
    q_table = Table([[Paragraph(q_html, styles["QuestionBody"])]], colWidths=[content_width])
    q_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#EAF1FB")),
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#BFD7F5")),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(q_table)
    story.append(Spacer(1, 18))

    # ── Answer ──────────────────────────────────────────────────────────
    story.append(Paragraph("AI Generated Answer", styles["H2"]))
    story.append(Spacer(1, 2))
    story.extend(_md_to_flowables(req.answer, styles, content_width))
    story.append(Spacer(1, 8))

    # ── Sources (omitted entirely if none) ─────────────────────────────
    sources = meta.sources or []
    if sources:
        story.append(KeepTogether([
            Paragraph("Sources", styles["H2"]),
            _build_list([_source_label(s) for s in sources], styles, ordered=False),
        ]))
        story.append(Spacer(1, 6))

    # ── Generation details ──────────────────────────────────────────────
    detail_rows = [
        ("LLM Model", model_name),
        ("Model Version", model_version or "—"),
        ("Embedding Model", embed_model),
        ("Generated On", generated_label),
    ]
    if meta.response_time_ms is not None:
        detail_rows.append(("Response Time", f"{meta.response_time_ms / 1000:.2f} sec"))
    if meta.query_type:
        detail_rows.append(("Query Type", meta.query_type.replace("_", " ").title()))
    if meta.confidence is not None:
        detail_rows.append(("Confidence", f"{round(meta.confidence * 100)}%"))
    if meta.tokens_used is not None:
        detail_rows.append(("Tokens Used", str(meta.tokens_used)))
    detail_rows.append(("Application", API_TITLE))
    detail_rows.append(("Version", API_VERSION))

    detail_table = Table(
        [[Paragraph(_esc(k), styles["MonoBold"]), Paragraph(_esc(str(v)), styles["Mono"])] for k, v in detail_rows],
        colWidths=[content_width * 0.32, content_width * 0.68],
    )
    detail_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F4F5F7")),
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#D1D5DB")),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#E5E7EB")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(KeepTogether([Paragraph("Generation Details", styles["H2"]), detail_table]))

    # ── Footer (every page) ─────────────────────────────────────────────
    def _footer_text(page: int, total: int):
        return (
            f"Generated by {API_TITLE}",
            f"Model: {model_name} ({model_version or 'n/a'})    |    Page {page} of {total}",
        )

    canvas_maker = functools.partial(_FooterCanvas, footer_text_fn=_footer_text)
    doc.build(story, canvasmaker=canvas_maker)

    pdf_bytes = buf.getvalue()
    buf.close()

    filename = build_export_filename(req.question, now)
    return pdf_bytes, filename
