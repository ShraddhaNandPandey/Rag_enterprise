"""
services/preview_render.py — Document Preview rendering

Renders original files (persisted by services/preview_store.py) into a form
the frontend can display, using only libraries already pinned in
requirements.txt for the existing ingestion/OCR pipeline:

  PDF    -> pypdf (page count) + pdf2image/poppler (page -> PNG bytes)
  DOCX   -> python-docx (paragraphs/headings/tables -> sanitized HTML)
  Excel  -> pandas (sheets -> JSON-serializable rows), openpyxl/xlrd engines

This is read-only rendering for preview purposes only. It does not touch
ChromaDB, DuckDB, the chunker, or anything in the RAG pipeline.
"""

from html import escape
from pathlib import Path
from typing import Any, Dict, List

from utils.logger import get_logger

logger = get_logger("preview")

MAX_EXCEL_ROWS_PER_SHEET = 5000  # safety cap so a huge sheet can't blow up memory/response size


# ───────────────────────── PDF ─────────────────────────

def pdf_page_count(path: Path) -> int:
    from pypdf import PdfReader
    reader = PdfReader(str(path))
    return len(reader.pages)


def render_pdf_page_png(path: Path, page_number: int, dpi: int = 130) -> bytes:
    """Render a single 1-indexed PDF page to PNG bytes."""
    from pdf2image import convert_from_path
    images = convert_from_path(
        str(path), dpi=dpi, first_page=page_number, last_page=page_number
    )
    if not images:
        raise ValueError(f"Could not render page {page_number}")
    import io
    buf = io.BytesIO()
    images[0].save(buf, format="PNG")
    return buf.getvalue()


# ───────────────────────── DOCX ─────────────────────────

def render_docx_html(path: Path) -> str:
    """Convert a .docx file into readable, read-only HTML preserving
    headings, paragraphs, tables, and basic run formatting (bold/italic/underline)."""
    import docx

    document = docx.Document(str(path))
    parts: List[str] = []

    def render_runs(paragraph) -> str:
        out = []
        for run in paragraph.runs:
            text = escape(run.text).replace("\n", "<br>")
            if not text:
                continue
            if run.bold:
                text = f"<strong>{text}</strong>"
            if run.italic:
                text = f"<em>{text}</em>"
            if run.underline:
                text = f"<u>{text}</u>"
            out.append(text)
        # Fall back to the paragraph's plain text if runs produced nothing
        # (can happen with certain field codes / nested content).
        return "".join(out) if out else escape(paragraph.text)

    def render_table(table) -> str:
        rows_html = []
        for row in table.rows:
            cells_html = "".join(f"<td>{escape(cell.text)}</td>" for cell in row.cells)
            rows_html.append(f"<tr>{cells_html}</tr>")
        return f"<table class='docx-table'>{''.join(rows_html)}</table>"

    # Walk the document body in order so tables land in the right place
    # relative to surrounding paragraphs, instead of grouping all tables
    # at the end (python-docx exposes them as separate collections).
    body = document.element.body
    for child in body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            para = next((p for p in document.paragraphs if p._p is child), None)
            if para is None:
                continue
            style = (para.style.name or "").lower() if para.style else ""
            content = render_runs(para)
            if not content.strip():
                parts.append("<p class='docx-empty-line'>&nbsp;</p>")
            elif style.startswith("heading 1") or style == "title":
                parts.append(f"<h1>{content}</h1>")
            elif style.startswith("heading 2"):
                parts.append(f"<h2>{content}</h2>")
            elif style.startswith("heading 3"):
                parts.append(f"<h3>{content}</h3>")
            elif style.startswith("heading"):
                parts.append(f"<h4>{content}</h4>")
            elif style == "list bullet" or style == "list paragraph":
                parts.append(f"<li>{content}</li>")
            else:
                parts.append(f"<p>{content}</p>")
        elif tag == "tbl":
            table = next((t for t in document.tables if t._tbl is child), None)
            if table is not None:
                parts.append(render_table(table))

    if not parts:
        return "<p class='docx-empty-line'><em>This document has no readable text content.</em></p>"
    return "\n".join(parts)


# ───────────────────────── Excel ─────────────────────────

def excel_sheet_names(path: Path) -> List[str]:
    import pandas as pd
    engine = "xlrd" if path.suffix.lower() == ".xls" else "openpyxl"
    try:
        xl = pd.ExcelFile(str(path), engine=engine)
    except Exception:
        # Let pandas auto-pick if the forced engine isn't available
        xl = pd.ExcelFile(str(path))
    return list(xl.sheet_names)


def render_excel_sheet(path: Path, sheet_name: str) -> Dict[str, Any]:
    import pandas as pd
    engine = "xlrd" if path.suffix.lower() == ".xls" else "openpyxl"
    try:
        df = pd.read_excel(str(path), sheet_name=sheet_name, engine=engine, header=None)
    except Exception:
        df = pd.read_excel(str(path), sheet_name=sheet_name, header=None)

    total_rows = len(df)
    truncated = total_rows > MAX_EXCEL_ROWS_PER_SHEET
    if truncated:
        df = df.iloc[:MAX_EXCEL_ROWS_PER_SHEET]

    # Treat the first row as the header if the sheet looks like it has one;
    # otherwise fall back to generic column labels. Either way this is a
    # display-only decision — it never touches how the tabular data was
    # already ingested into DuckDB.
    if total_rows > 0:
        header = [("" if pd.isna(v) else str(v)) for v in df.iloc[0].tolist()]
        data_rows = df.iloc[1:]
    else:
        header, data_rows = [], df

    def clean_row(row) -> List[str]:
        return ["" if pd.isna(v) else str(v) for v in row.tolist()]

    rows = [clean_row(r) for _, r in data_rows.iterrows()]

    return {
        "sheet": sheet_name,
        "columns": header if header else [f"Column {i+1}" for i in range(df.shape[1])],
        "rows": rows,
        "total_rows": total_rows,
        "truncated": truncated,
    }
