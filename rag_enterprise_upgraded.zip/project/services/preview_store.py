"""
services/preview_store.py — Persistent storage for Document Preview

Why this exists
----------------
The existing ingestion flow (routers/ingest_router.py) saves uploads to a
*temporary* directory, ingests them into ChromaDB / DuckDB, and then deletes
the temp directory. That is correct and unchanged for ingestion — but it
means the original file bytes are gone once ingestion finishes, so there is
nothing left to show in a document preview.

This module adds a small, self-contained, additive side-store: a copy of
each uploaded file is kept in the app's already-configured UPLOADS_DIR
(config/settings.py — the directory existed before this feature but was
unused). Nothing about ingestion, chunking, embeddings, or the RAG pipeline
reads from or depends on this store; it is only consulted by the new
preview endpoints (routers/preview_router.py).

All functions here are defensive (never raise into the caller's upload
flow) so a preview-store failure can never break uploading or ingestion.
"""

from pathlib import Path
from typing import Optional

from config.settings import UPLOADS_DIR
from utils.logger import get_logger

logger = get_logger("preview")


def save_preview_copy(filename: str, content: bytes) -> None:
    """Persist a copy of an uploaded file's bytes for later preview/download.

    `filename` must already be the sanitized name used by the ingestion
    pipeline (the same value stored as `source_name` / shown as the
    document's `name` in /ingest/kb), so preview lookups line up exactly
    with what the Knowledge Base UI already displays.
    """
    try:
        Path(UPLOADS_DIR).mkdir(parents=True, exist_ok=True)
        dest = Path(UPLOADS_DIR) / filename
        dest.write_bytes(content)
    except Exception as e:
        # Never let preview storage failures affect the upload/ingestion flow.
        logger.warning(f"preview_store: could not persist copy of '{filename}': {e}")


def get_preview_path(filename: str) -> Optional[Path]:
    """Return the Path to the stored original for `filename`, or None if unavailable."""
    try:
        p = Path(UPLOADS_DIR) / filename
        if p.exists() and p.is_file():
            return p
    except Exception as e:
        logger.warning(f"preview_store: lookup failed for '{filename}': {e}")
    return None


def delete_preview_copy(filename: str) -> None:
    """Remove a stored preview copy, e.g. when the document is deleted from the KB."""
    try:
        p = Path(UPLOADS_DIR) / filename
        if p.exists():
            p.unlink()
    except Exception as e:
        logger.warning(f"preview_store: could not delete stored copy of '{filename}': {e}")
