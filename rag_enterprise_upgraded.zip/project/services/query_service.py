"""
services/query_service.py — Query Orchestration Service

FIX v2 (Industry Standard):
  1. Router is now kept aware of which filenames are in tabular vs semantic stores
     so it can use file-name hints from the question.
  2. Tabular pipeline has hybrid fallback: if SQL generation fails OR returns 0 rows,
     the service now tries semantic search before returning an error — prevents
     "I cannot answer" when the Excel data was partially embedded as text chunks.
  3. stream=False for Ollama (stream=True + urllib is unreliable on Windows/slow machines).
  4. Proper exception propagation so FastAPI returns meaningful errors, not HTTP 500.
  5. Source lists are refreshed on every ask() call so router always has current state.
"""

import json
import re
import difflib
import urllib.request
import urllib.error
from pathlib import Path
from typing import List, Dict, Any, Optional

from vectorstore.chroma_store import VectorStore
from database.duckdb_manager import DuckDBManager
from tools.query_router import QueryRouter
from tools.sql_generator import generate_sql, repair_sql, format_query_result
from config.settings import (
    OLLAMA_BASE_URL, LLM_MODEL, LLM_TIMEOUT, LLM_MAX_TOKENS,
    RAG_SYSTEM_PROMPT, TOP_K,
)
from utils.logger import get_logger
# NEW: AI-powered chart generation — fully additive, modular service. Never
# imported by anything else in the query pipeline; only called from ask()
# below, and any failure here is swallowed so it can never break a normal
# chat answer. See services/chart_service.py for details.
from services.chart_service import maybe_generate_chart
from core.answer_verifier import apply_verification

logger = get_logger("retrieval")
# PROBLEM 15: dedicated structured-trace logger (separate stream name so it
# can be filtered/parsed independently from normal prose log lines).
trace_logger = get_logger("trace")


def _call_ollama_generate(
    prompt: str,
    model: str,
    base_url: str,
    max_tokens: int = LLM_MAX_TOKENS,
    timeout: int = LLM_TIMEOUT,
) -> str:
    """Call Ollama /api/generate with stream=False for reliability."""
    payload = json.dumps({
        "model":   model,
        "prompt":  prompt,
        "stream":  False,
        "options": {"temperature": 0.1, "num_predict": max_tokens},
    }).encode()

    req = urllib.request.Request(
        f"{base_url}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data.get("response", "").strip()
    except urllib.error.URLError as e:
        raise ConnectionError(
            f"Ollama unreachable at {base_url}: {e}\n"
            f"Run: ollama serve && ollama pull {model}"
        )
    except Exception as e:
        raise ConnectionError(f"Ollama call failed: {e}")


def _call_ollama_chat(
    messages: List[Dict],
    model: str,
    base_url: str,
    max_tokens: int = LLM_MAX_TOKENS,
    timeout: int = LLM_TIMEOUT,
) -> str:
    """Call Ollama /api/chat for multi-turn generation."""
    payload = json.dumps({
        "model":    model,
        "messages": messages,
        "stream":   False,
        "options":  {"temperature": 0.1, "num_predict": max_tokens},
    }).encode()

    req = urllib.request.Request(
        f"{base_url}/api/chat",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data.get("message", {}).get("content", "").strip()
    except urllib.error.URLError as e:
        raise ConnectionError(f"Ollama unreachable: {e}")
    except Exception as e:
        raise ConnectionError(f"Ollama chat failed: {e}")


_IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".gif", ".webp")


def _build_context(chunks: List[Dict]) -> str:
    if not chunks:
        return "No relevant context found in the uploaded documents."
    parts = []
    for i, chunk in enumerate(chunks, 1):
        meta  = chunk["metadata"]
        src   = meta.get("source_name", "unknown")
        score = chunk.get("confidence", chunk.get("score", 0))
        loc   = ""
        if "page"  in meta: loc = f", page {meta['page']}"
        elif "slide" in meta: loc = f", slide {meta['slide']}"
        elif "sheet" in meta: loc = f", sheet '{meta['sheet']}'"
        tag = " (image, OCR-extracted)" if src.lower().endswith(_IMAGE_EXTENSIONS) else ""
        parts.append(f"[Source {i}: {src}{tag}{loc} | relevance: {score:.2f}]\n{chunk['text']}")
    return "\n\n---\n\n".join(parts)


def _compute_confidence(chunks: List[Dict]) -> float:
    if not chunks:
        return 0.0
    scores = [c.get("confidence", c.get("score", 0.0)) for c in chunks]
    return round(sum(scores) / len(scores), 4)


# --- BUGFIX: ground-truth verification for tabular answers -----------------
# Root cause of the "all 10 students admitted" bug: the natural-language
# synthesis step handed the LLM raw rows and trusted it to summarize
# per-row categorical/binary values (e.g. admission_status) correctly. Small
# local models (llama3.2) can hallucinate here — they saw 10 rows and wrote
# "all admitted" even though 2 of the 10 rows had admission_status=0. The
# SQL/data layer was never wrong; the unverified prose layer was.
#
# Fix: compute exact value counts for low-cardinality columns directly in
# Python (no LLM involved, cannot hallucinate), inject them into the prompt
# as facts the model must not contradict, and — belt and suspenders — always
# append the code-computed breakdown to the final answer so the user sees
# the true numbers even if the model's prose still gets it wrong.

_ID_LIKE_SUFFIXES = ("_id", "id")


def _looks_like_identifier(col: str) -> bool:
    c = col.lower().strip()
    return c in ("id", "index", "idx", "row_id", "rowid") or c.endswith("_id")


def compute_categorical_summary(
    rows: List[Dict[str, Any]],
    columns: List[str],
    max_distinct: int = 6,
) -> Dict[str, Dict[Any, int]]:
    """
    Compute exact value counts for columns that behave like categorical or
    binary fields, so answers about them can be verified against ground
    truth instead of relying on the LLM to correctly restate every row.

    Skips obvious identifier columns and columns with too many distinct
    values (free text, continuous numerics) to avoid noisy, unhelpful output.
    """
    summary: Dict[str, Dict[Any, int]] = {}
    n = len(rows)
    # BUGFIX: with a single row, EVERY column trivially has exactly 1 distinct
    # value, which satisfies the distinct<=2 "binary column" heuristic below —
    # so a 1-row result (e.g. "all details of student 56") was incorrectly
    # flagging every single column (family_income, sat_score, essay_score...)
    # as "categorical" and dumping a noisy, useless breakdown that just
    # repeats the answer. The whole point of this check is to verify a
    # multi-row uniformity claim (e.g. "all 10 admitted") — with only one row
    # there's no such claim to verify, so skip entirely.
    if n <= 1:
        return summary

    for col in columns:
        if _looks_like_identifier(col):
            continue
        # DEFENSIVE: duckdb_manager.execute_query() already converts pandas
        # NaN floats to None before rows reach here, but this helper is
        # general-purpose — normalize NaN to None ourselves too, since
        # float('nan') != float('nan') means distinct NaN objects would
        # otherwise hash/collide unreliably as dict keys and split what
        # should be one "missing value" bucket into several.
        def _normalize(x):
            if isinstance(x, float) and x != x:  # NaN check without importing math
                return None
            return x

        values = [_normalize(row.get(col)) for row in rows]
        distinct = set(values)
        if len(distinct) < 1 or len(distinct) > max_distinct:
            continue
        # Only worth flagging as "categorical" if there's actually repetition
        # (otherwise every value is unique and it's just an identifier-like
        # column that happens to have few rows), OR it's a true binary/bool
        # field (2 distinct values), which is the highest-risk case for
        # "all X" style hallucinations regardless of row count.
        if n > len(distinct) or len(distinct) <= 2:
            counts: Dict[Any, int] = {}
            for v in values:
                counts[v] = counts.get(v, 0) + 1
            summary[col] = counts

    return summary


def format_verified_facts(summary: Dict[str, Dict[Any, int]]) -> str:
    """Render the computed categorical summary as plain-text ground truth."""
    if not summary:
        return ""
    lines = []
    for col, counts in summary.items():
        parts = ", ".join(
            f"{v}={c}" for v, c in sorted(counts.items(), key=lambda kv: str(kv[0]))
        )
        lines.append(f"- {col}: {parts}")
    return "\n".join(lines)


def format_verified_breakdown_markdown(summary: Dict[str, Dict[Any, int]]) -> str:
    """Render the computed categorical summary as a user-facing Markdown block."""
    if not summary:
        return ""
    lines = ["**Verified breakdown (computed directly from the query result):**"]
    for col, counts in summary.items():
        parts = "; ".join(
            f"{v} → {c}" for v, c in sorted(counts.items(), key=lambda kv: str(kv[0]))
        )
        lines.append(f"- `{col}`: {parts}")
    return "\n".join(lines)


def _get_source_lists(
    vector_store: VectorStore,
    duckdb_manager: DuckDBManager,
) -> tuple[List[str], List[str]]:
    """
    Return (tabular_sources, semantic_sources) — filenames in each store.
    Used to give the router file-name-hint awareness.
    """
    # Tabular: names from DuckDB registry
    tabular: List[str] = []
    try:
        for tname in duckdb_manager.list_tables():
            try:
                info = duckdb_manager.get_table_info(tname)
            except Exception as e:
                logger.warning(f"get_table_info failed for '{tname}': {e}")
                continue
            if info and info.get("source_file"):
                fname = Path(info["source_file"]).name
                if fname not in tabular:
                    tabular.append(fname)
    except Exception as e:
        logger.warning(f"DuckDB list_tables failed while building source lists: {e}")

    # Semantic: names from ChromaDB
    semantic: List[str] = []
    try:
        kb = vector_store.get_knowledge_base()
        for entry in kb:
            fname = entry.get("source_name", "")
            if fname and fname not in semantic:
                semantic.append(fname)
    except Exception as e:
        logger.warning(f"ChromaDB get_knowledge_base failed while building source lists: {e}")

    return tabular, semantic


class QueryService:
    """Orchestrates routing, retrieval, and LLM generation."""

    def __init__(
        self,
        vector_store: VectorStore,
        duckdb_manager: DuckDBManager,
        model: str = LLM_MODEL,
        ollama_url: str = OLLAMA_BASE_URL,
    ):
        self.vector_store   = vector_store
        self.duckdb_manager = duckdb_manager
        self.model          = model
        self.ollama_url     = ollama_url
        self.router         = QueryRouter(model=model, ollama_url=ollama_url)
        logger.info(f"QueryService initialized | model={model} | ollama={ollama_url}")

    def _refresh_router_state(self) -> None:
        """
        FIX: Keep router fully up-to-date before every query.
        This ensures file-hint routing and has_tabular flag are always current.
        Never raises — a transient DuckDB/ChromaDB issue degrades routing
        gracefully (falls back to semantic-only) rather than failing the query.
        """
        try:
            has_tabular = len(self.duckdb_manager.list_tables()) > 0
        except Exception as e:
            logger.warning(f"DuckDB list_tables failed during router refresh, assuming no tabular data: {e}")
            has_tabular = False

        self.router.update_has_tabular(has_tabular)

        try:
            has_semantic = self.vector_store.collection.count() > 0
        except Exception as e:
            logger.warning(f"ChromaDB count() failed during router refresh, assuming no semantic data: {e}")
            has_semantic = False

        self.router.update_has_semantic(has_semantic)

        tabular_sources, semantic_sources = _get_source_lists(
            self.vector_store, self.duckdb_manager
        )
        self.router.update_sources(tabular_sources, semantic_sources)
        logger.debug(
            f"Router state refreshed | tabular={has_tabular} | semantic={has_semantic} "
            f"| tabular_files={tabular_sources} | semantic_files={semantic_sources}"
        )

    def ask(
        self,
        question: str,
        session_history: Optional[List[Dict]] = None,
        filters: Optional[Dict] = None,
        k: int = TOP_K,
        source_names: Optional[List[str]] = None,
        per_document_answers: bool = False,
    ) -> Dict[str, Any]:
        """
        PROBLEM 15 (Logging): thin timing + structured-trace wrapper around
        _ask_impl(). Emits one JSON trace line per query (question, routing
        decision, sources, sql, verification, timing, errors) to the "trace"
        logger, purely additively — the return value and all existing
        behaviour of the pipeline itself are unchanged from _ask_impl().
        """
        import time as _time
        started = _time.time()
        error_info = None
        result: Dict[str, Any] = {}
        try:
            result = self._ask_impl(
                question, session_history=session_history, filters=filters, k=k,
                source_names=source_names, per_document_answers=per_document_answers,
            )
            return result
        except Exception as e:
            error_info = str(e)
            raise
        finally:
            elapsed_ms = round((_time.time() - started) * 1000, 1)
            try:
                trace = {
                    "question":          question[:300],
                    "query_type":        result.get("query_type"),
                    "docs_searched":     result.get("docs_searched"),
                    "sql":               result.get("sql"),
                    "sql_row_count":     (result.get("sql_result") or {}).get("row_count")
                                         if isinstance(result.get("sql_result"), dict) else None,
                    "chunks_retrieved":  len(result.get("chunks") or []),
                    "sources":           result.get("sources"),
                    "confidence":        result.get("confidence"),
                    "verification":      result.get("verification"),
                    "answer_length":     len(result.get("answer") or ""),
                    "elapsed_ms":        elapsed_ms,
                    "error":             error_info,
                }
                trace_logger.info(json.dumps(trace, default=str))
            except Exception as log_err:
                logger.debug(f"Structured trace logging failed (non-fatal): {log_err}")

    def _ask_impl(
        self,
        question: str,
        session_history: Optional[List[Dict]] = None,
        filters: Optional[Dict] = None,
        k: int = TOP_K,
        source_names: Optional[List[str]] = None,
        per_document_answers: bool = False,
    ) -> Dict[str, Any]:
        """
        Main query entry point.

        Multi-document behaviour:
          source_names=None / []       -> search all ingested documents (default)
          source_names=["a.pdf"]       -> restrict retrieval to that one document
          source_names=["a.pdf","b"]   -> restrict to those documents only
          per_document_answers=True    -> also return one answer per doc + synthesis
        """
        self._refresh_router_state()

        # Normalise: empty list -> None (no filter = search everything)
        scoped_sources: Optional[List[str]] = [s for s in (source_names or []) if s] or None

        # Handle explicit source-override prefixes from the UI
        forced_type: Optional[str] = None
        clean_question = question
        if question.startswith("[TABULAR] "):
            forced_type    = "tabular"
            clean_question = question[len("[TABULAR] "):]
        elif question.startswith("[SEMANTIC] "):
            forced_type    = "semantic"
            clean_question = question[len("[SEMANTIC] "):]

        # Build ChromaDB source filter when specific docs are selected
        source_filter: Optional[Dict] = None
        if scoped_sources:
            source_filter = self.vector_store.build_source_filter(scoped_sources)

        # Merge source filter with any extra caller-supplied metadata filters
        if scoped_sources and filters:
            combined: Dict = dict(filters)
            combined["source_name"] = scoped_sources
            source_filter = self.vector_store._build_where_clause(combined)

        effective_filters = source_filter if scoped_sources else filters

        logger.info(
            f"ask() | scope={scoped_sources or 'ALL'} "
            f"| per_doc={per_document_answers} | Q: '{question[:80]}'"
        )

        if forced_type:
            logger.info(f"User forced route: {forced_type} | Q: '{clean_question[:80]}'")
            if forced_type == "tabular":
                result = self._answer_tabular(clean_question, effective_filters, session_history, k)
            else:
                result = self._answer_semantic(clean_question, session_history, effective_filters, k)
            result["docs_searched"] = scoped_sources
            result["per_doc_results"] = None
            self._attach_chart_if_requested(clean_question, result)
            return result

        route      = self.router.route_with_evidence(
            question, vector_store=self.vector_store, duckdb_manager=self.duckdb_manager
        )
        query_type = route["query_type"]
        logger.info(
            f"Route: {query_type} (method={route['method']}) | "
            f"Q: '{question[:80]}'"
        )

        # Per-document mode: answer each document independently, then synthesise
        if per_document_answers and scoped_sources and len(scoped_sources) >= 2:
            return self._answer_per_document(
                question, scoped_sources, session_history, filters, k, query_type
            )

        if query_type == "tabular":
            result = self._answer_tabular(question, effective_filters, session_history, k)
        elif query_type == "hybrid":
            # PART 7/8: question needs both DuckDB (table) and ChromaDB (text).
            result = self._answer_hybrid(question, effective_filters, session_history, k)
        else:
            result = self._answer_semantic(question, session_history, effective_filters, k)

        result["docs_searched"] = scoped_sources
        result["per_doc_results"] = None
        self._attach_chart_if_requested(question, result)
        return result

    def _answer_per_document(
        self,
        question: str,
        source_names: List[str],
        session_history: Optional[List[Dict]],
        base_filters: Optional[Dict],
        k: int,
        query_type: str,
    ) -> Dict[str, Any]:
        """
        Answer the question independently for each document in source_names,
        then synthesise a single cross-document answer.

        Returns the standard result dict plus:
          per_doc_results: [PerDocResult, ...]   — one entry per document
          docs_searched:   [str, ...]            — document filenames in scope
        """
        from models.schemas import PerDocResult  # local import avoids circular

        per_doc_results = []
        all_chunks: List[Dict] = []

        for doc_name in source_names:
            # Build a filter scoped to just this one document
            doc_filter = self.vector_store.build_source_filter([doc_name])
            if base_filters:
                combined = dict(base_filters)
                combined["source_name"] = [doc_name]
                doc_filter = self.vector_store._build_where_clause(combined)

            chunks = self.vector_store.hybrid_search(question, k=k, filters=doc_filter)
            confidence = _compute_confidence(chunks)

            if not chunks or confidence == 0.0:
                per_doc_results.append(PerDocResult(
                    source_name=doc_name,
                    answer=f"No relevant content found in '{doc_name}' for this question.",
                    confidence=0.0,
                    chunks_used=0,
                    has_answer=False,
                ))
                continue

            context = _build_context(chunks)
            prompt = (
                f"Answer the following question using ONLY the content from the document "
                f"'{doc_name}'.\n\n"
                f"CONTEXT FROM '{doc_name}':\n{context}\n\n"
                f"Question: {question}\n\n"
                f"Answer based solely on the above context. Cite the document name."
            )
            try:
                answer = _call_ollama_generate(prompt, self.model, self.ollama_url)
            except Exception as e:
                answer = f"[Generation failed for '{doc_name}': {e}]\n\nContext:\n{context[:500]}"

            per_doc_results.append(PerDocResult(
                source_name=doc_name,
                answer=answer,
                confidence=confidence,
                chunks_used=len(chunks),
                has_answer=True,
            ))
            all_chunks.extend(chunks)

        # ── Cross-document synthesis ─────────────────────────────────────────
        docs_with_answers = [r for r in per_doc_results if r.has_answer]

        if not docs_with_answers:
            return {
                "answer": "None of the selected documents contained relevant content for this question.",
                "query_type": "multi_document",
                "confidence": 0.0,
                "sources": source_names,
                "chunks": [],
                "sql": None,
                "sql_result": None,
                "per_doc_results": [r.dict() for r in per_doc_results],
                "docs_searched": source_names,
            }

        if len(docs_with_answers) == 1:
            # Only one doc had content — no need for synthesis
            r = docs_with_answers[0]
            return {
                "answer": r.answer,
                "query_type": "multi_document",
                "confidence": r.confidence,
                "sources": [r.source_name],
                "chunks": all_chunks,
                "sql": None,
                "sql_result": None,
                "per_doc_results": [pr.dict() for pr in per_doc_results],
                "docs_searched": source_names,
            }

        # Build a synthesis prompt from all per-doc answers
        doc_summaries = "\n\n".join(
            f"=== {r.source_name} ===\n{r.answer}"
            for r in docs_with_answers
        )
        synthesis_prompt = (
            f"You have received answers to the same question from {len(docs_with_answers)} "
            f"different documents. Synthesise a single comprehensive answer that:\n"
            f"1. Highlights agreements and key common findings\n"
            f"2. Notes any differences or contradictions between documents\n"
            f"3. Cites which document each point comes from\n\n"
            f"Question: {question}\n\n"
            f"Per-document answers:\n{doc_summaries}\n\n"
            f"Synthesised answer:"
        )
        try:
            synthesised = _call_ollama_generate(synthesis_prompt, self.model, self.ollama_url)
        except Exception as e:
            synthesised = (
                f"[Synthesis failed: {e}]\n\n"
                + "\n\n".join(f"**{r.source_name}**: {r.answer}" for r in docs_with_answers)
            )

        overall_confidence = round(
            sum(r.confidence for r in docs_with_answers) / len(docs_with_answers), 4
        )
        source_citations = list({r.source_name for r in docs_with_answers})

        logger.info(
            f"Multi-doc answer | docs={source_names} | answered={len(docs_with_answers)} "
            f"| confidence={overall_confidence:.3f}"
        )
        return {
            "answer": synthesised,
            "query_type": "multi_document",
            "confidence": overall_confidence,
            "sources": source_citations,
            "chunks": all_chunks,
            "sql": None,
            "sql_result": None,
            "per_doc_results": [r.dict() for r in per_doc_results],
            "docs_searched": source_names,
        }

    def _answer_semantic(
        self,
        question: str,
        session_history: Optional[List[Dict]],
        filters: Optional[Dict],
        k: int,
    ) -> Dict[str, Any]:
        if self.vector_store.collection.count() == 0:
            return {
                "answer": "No documents ingested yet. Please upload files first.",
                "query_type": "semantic", "confidence": 0.0,
                "sources": [], "chunks": [], "sql": None, "sql_result": None,
            }

        chunks     = self.vector_store.hybrid_search(question, k=k, filters=filters)
        confidence = _compute_confidence(chunks)

        if confidence == 0.0:
            return {
                "answer": "I do not have enough information in the uploaded documents to answer this.",
                "query_type": "semantic", "confidence": 0.0,
                "sources": [], "chunks": [], "sql": None, "sql_result": None,
            }

        context = _build_context(chunks)

        if session_history:
            # Derive the system message from RAG_SYSTEM_PROMPT itself (minus the
            # {question}/Answer: tail, which doesn't apply in chat-message mode)
            # so the rules can never drift out of sync between single-turn and
            # multi-turn conversations.
            system_msg = RAG_SYSTEM_PROMPT.split("Question: {question}")[0].format(context=context).strip()
            messages = [{"role": "system", "content": system_msg}] + session_history + \
                       [{"role": "user", "content": question}]
            answer = _call_ollama_chat(messages, self.model, self.ollama_url)
        else:
            prompt = RAG_SYSTEM_PROMPT.format(context=context, question=question)
            answer = _call_ollama_generate(prompt, self.model, self.ollama_url)

        # PROBLEM 10 (Answer Verification): check the generated answer is
        # actually grounded in the retrieved chunks before returning it.
        answer, verification = apply_verification(answer, context)
        if not verification["is_grounded"]:
            logger.warning(
                f"Answer verification flagged low grounding "
                f"(ratio={verification['grounded_ratio']}) for Q: '{question[:80]}'"
            )

        source_citations = []
        for c in chunks:
            meta = c["metadata"]
            src  = meta.get("source_name", "?")
            loc  = f"page {meta['page']}" if "page" in meta else \
                   f"slide {meta['slide']}" if "slide" in meta else \
                   f"sheet '{meta['sheet']}'" if "sheet" in meta else ""
            citation = f"{src}" + (f" ({loc})" if loc else "")
            if citation not in source_citations:
                source_citations.append(citation)

        logger.info(f"Semantic answer done | confidence={confidence:.3f}")
        return {
            "answer":     answer,
            "query_type": "semantic",
            "confidence": confidence,
            "sources":    source_citations,
            "chunks":     chunks,
            "sql":        None,
            "sql_result": None,
            "verification": verification,
        }

    def _answer_hybrid(
        self,
        question: str,
        filters: Optional[Dict],
        session_history: Optional[List[Dict]],
        k: int,
    ) -> Dict[str, Any]:
        """
        PART 7/8: TEXT + TABLE hybrid answering.

        Deliberately reuses the exact same, already-hardened _answer_tabular()
        and _answer_semantic() code paths (SQL generation + self-repair,
        hybrid BM25+dense retrieval, ground-truth verification, etc.) rather
        than duplicating that logic — this keeps hybrid answers only ever as
        reliable as the two pipelines it's built from, and means neither
        pipeline's behaviour changes for tabular-only or semantic-only
        questions (this method is only ever reached when the router
        explicitly classifies a question as "hybrid").

        The two results are then merged into ONE prompt (PART 8: "Merge
        Semantic Context + SQL Result into one prompt") and answered with a
        single LLM call. Per PART 8/9, the SQL side already only sends the
        relevant rows (format_query_result caps displayed rows and always
        states the true total) — never a dump of an entire table.
        """
        tabular_part = self._answer_tabular(question, filters, session_history, k)

        # BUGFIX: _answer_tabular() already falls back to a full semantic
        # answer internally (including its own Ollama LLM call) whenever SQL
        # generation fails or the query returns zero rows. Calling
        # _answer_semantic() again unconditionally after that would silently
        # duplicate an expensive retrieval + LLM call for no benefit — reuse
        # the result it already computed instead.
        if tabular_part.get("query_type") in ("tabular_fallback_semantic", "semantic"):
            result = dict(tabular_part)
            result["query_type"] = "hybrid"
            return result

        semantic_part = self._answer_semantic(question, session_history, filters, k)

        sql = tabular_part.get("sql")
        sql_result = tabular_part.get("sql_result")
        has_sql_rows = bool(sql_result and sql_result.get("row_count", 0) > 0)
        chunks = semantic_part.get("chunks") or []
        has_chunks = bool(chunks)

        # Graceful degradation: if only one side actually produced anything
        # (e.g. the SQL query matched no rows, or nothing relevant was found
        # in ChromaDB), fall back to whichever side has data rather than
        # generating a prompt promising context that doesn't exist.
        if not has_sql_rows and not has_chunks:
            result = dict(semantic_part)
            result["query_type"] = "hybrid"
            result["sql"] = sql
            return result
        if not has_sql_rows:
            result = dict(semantic_part)
            result["query_type"] = "hybrid"
            result["sql"] = sql
            return result
        if not has_chunks:
            result = dict(tabular_part)
            result["query_type"] = "hybrid"
            return result

        # Both sides have data — merge into a single prompt (PART 8).
        result_text = format_query_result(sql_result, question)
        context = _build_context(chunks)

        prompt = (
            f"Answer the question below using BOTH sources of information provided:\n"
            f"1. Document context (explanatory/policy text retrieved from the knowledge base)\n"
            f"2. Table data (an exact SQL query result from the structured data store)\n\n"
            f"Do not say information is missing if it appears in either source below.\n\n"
            f"=== Document context ===\n{context}\n\n"
            f"=== Table data (SQL: {sql}) ===\n{result_text}\n\n"
            f"Question: {question}\n\n"
            f"Write one combined, natural-language answer. Address the explanatory/policy part "
            f"using the document context, and the data part using the exact table data — do not "
            f"round or invent numbers, use the values exactly as shown in the table data.\n\n"
            f"Answer:"
        )

        try:
            answer = _call_ollama_generate(prompt, self.model, self.ollama_url)
        except Exception as e:
            logger.warning(f"Hybrid LLM synthesis failed, falling back to concatenated answer: {e}")
            answer = (
                f"{semantic_part.get('answer', '')}\n\n"
                f"Related data:\n{tabular_part.get('answer', '')}"
            )

        # PROBLEM 10: verify against BOTH evidence sources combined.
        combined_evidence = f"{context}\n\n{result_text}"
        answer, verification = apply_verification(answer, combined_evidence)
        if not verification["is_grounded"]:
            logger.warning(
                f"Hybrid answer verification flagged low grounding "
                f"(ratio={verification['grounded_ratio']}) for Q: '{question[:80]}'"
            )

        sources = list(dict.fromkeys(
            (semantic_part.get("sources") or []) + (tabular_part.get("sources") or [])
        ))
        confidence = round(
            (semantic_part.get("confidence", 0.0) + tabular_part.get("confidence", 0.0)) / 2, 4
        )

        logger.info(f"Hybrid answer done | SQL: {sql} | chunks: {len(chunks)} | confidence={confidence:.3f}")
        return {
            "answer":            answer,
            "query_type":        "hybrid",
            "confidence":        confidence,
            "low_confidence_warning": tabular_part.get("low_confidence_warning", False),
            "sources":           sources,
            "chunks":            chunks,
            "sql":               sql,
            "sql_result":        sql_result,
            "verification":      verification,
        }

    def _tabular_failure_response(
        self,
        question: str,
        session_history: Optional[List[Dict]],
        filters: Optional[Dict],
        k: int,
        sql: str,
        error: Exception,
    ) -> Dict[str, Any]:
        """
        Build the response when SQL generation/repair both failed to execute.
        Falls back to semantic search, but if that also has nothing, surfaces the
        real SQL error instead of the generic "no documents ingested" message —
        which is misleading when tabular data clearly exists but the SQL was bad.
        """
        fallback = self._answer_semantic(question, session_history, filters, k)
        if fallback["confidence"] == 0.0 and self.vector_store.collection.count() == 0:
            fallback["answer"] = (
                f"I generated a SQL query for this question, but it failed to run "
                f"(even after attempting a self-correction):\n\n"
                f"`{sql}`\n\n"
                f"Error: {error}\n\n"
                f"This usually means the question needs rephrasing, or the column/table "
                f"names don't match your data. There are also no semantic documents "
                f"uploaded to fall back to."
            )
        fallback["query_type"]  = "tabular_fallback_semantic"
        fallback["sql"]         = sql
        fallback["sql_result"]  = None
        return fallback

    # Regex for "<superlative> ... <entity> per/each/by/for each <group>" questions, e.g.
    # "top-paid teacher per subject", "highest scorer per class", "best employee by department".
    # group(1)=superlative, group(2)=entity word right before per/each/by (best-effort, may be
    # missing/irrelevant), group(3)=the grouping/category word.
    _TOP_PER_GROUP_RE = re.compile(
        r"\b(top|highest|lowest|best|worst|most|least)\b.*?\b([a-zA-Z_]+)\s+"
        r"(?:per|each|for each|by)\s+([a-zA-Z_][\w]*)",
        re.IGNORECASE,
    )
    _LOW_WORDS = {"lowest", "worst", "least"}
    # Keyword groups used to pick the right numeric "metric" column when several numeric
    # columns exist in the matched table (e.g. salary vs age vs experience).
    _METRIC_KEYWORD_GROUPS = [
        ("paid", "salary", "pay", "wage", "income"),
        ("score", "marks", "mark", "grade"),
        ("price", "cost", "amount", "revenue", "profit", "sale"),
        ("age",),
        ("experience", "years"),
        ("rating", "rate"),
    ]

    def _try_top_per_group_sql(self, question: str) -> Optional[Dict[str, Any]]:
        """
        Deterministically build SQL for "top/best/highest X per Y" style questions by
        inspecting the actual schema, instead of relying on the LLM to avoid an
        unnecessary JOIN every single time.

        Returns {"sql": str, "result": <execute_query dict>} on success (already executed,
        so the caller doesn't have to re-run it), or None if the pattern doesn't match
        cleanly, no single table contains everything needed, or the built query errors out
        / returns 0 rows.
        """
        m = self._TOP_PER_GROUP_RE.search(question)
        if not m:
            return None
        superlative = m.group(1).lower()
        entity_word = (m.group(2) or "").lower().rstrip("s")
        group_word = m.group(3).lower().rstrip("s")
        descending = superlative not in self._LOW_WORDS

        try:
            tables = self.duckdb_manager.list_tables()
        except Exception:
            return None

        # (combined_score, table, cat_col, name_col, metric_col)
        best_candidate = None

        for t in tables:
            try:
                cols_df = self.duckdb_manager.conn.execute(f'DESCRIBE "{t}"').fetchdf()
            except Exception:
                continue
            col_names = list(cols_df["column_name"])
            col_types = dict(zip(cols_df["column_name"], cols_df["column_type"]))

            # Find the best fuzzy match for the grouping/category column in this table.
            cat_col, cat_score = None, 0.0
            for c in col_names:
                ratio = difflib.SequenceMatcher(None, group_word, c.lower().replace("_", "")).ratio()
                if group_word in c.lower() or c.lower() in group_word:
                    ratio = max(ratio, 0.85)
                if ratio > cat_score:
                    cat_score, cat_col = ratio, c
            if cat_col is None or cat_score < 0.6:
                continue

            numeric_types = {"BIGINT", "INTEGER", "DOUBLE", "FLOAT", "DECIMAL", "HUGEINT", "SMALLINT", "TINYINT"}
            numeric_cols = [c for c in col_names if any(nt in col_types[c].upper() for nt in numeric_types) and c != cat_col]
            if not numeric_cols:
                continue

            # Pick the metric column: prefer one matching a keyword group referenced in the question.
            metric_col = None
            q_lower = question.lower()
            for group in self._METRIC_KEYWORD_GROUPS:
                if any(kw in q_lower for kw in group):
                    for c in numeric_cols:
                        if any(kw in c.lower() for kw in group):
                            metric_col = c
                            break
                if metric_col:
                    break
            if metric_col is None:
                metric_col = numeric_cols[0] if len(numeric_cols) == 1 else None
            if metric_col is None:
                continue

            # Pick an identifying "name" column distinct from the category/metric columns.
            name_col = None
            for c in col_names:
                if c.lower() == "name" or c.lower().endswith("_name"):
                    name_col = c
                    break
            if name_col is None:
                string_cols = [c for c in col_names if c not in numeric_cols and c != cat_col]
                name_col = string_cols[0] if string_cols else None
            if name_col is None:
                continue

            # Disambiguate ties between tables (e.g. "Section" exists in both "Students" and
            # "Class_Assignments") by also checking whether the table name matches the entity
            # word the question is actually about (e.g. "teacher" -> "sheet_teachers").
            entity_bonus = 0.0
            if entity_word:
                t_norm = t.lower().replace("sheet_", "").replace("_", "")
                if entity_word in t_norm or t_norm in entity_word:
                    entity_bonus = 0.5
                else:
                    entity_bonus = difflib.SequenceMatcher(None, entity_word, t_norm).ratio() * 0.3
            combined_score = cat_score + entity_bonus

            if best_candidate is None or combined_score > best_candidate[0]:
                best_candidate = (combined_score, t, cat_col, name_col, metric_col)

        if not best_candidate:
            return None

        _, table, cat_col, name_col, metric_col = best_candidate
        order = "DESC" if descending else "ASC"
        sql = (
            f'WITH ranked AS (\n'
            f'  SELECT "{cat_col}", "{name_col}", "{metric_col}",\n'
            f'         ROW_NUMBER() OVER (PARTITION BY "{cat_col}" ORDER BY "{metric_col}" {order}) AS rn\n'
            f'  FROM "{table}"\n'
            f')\n'
            f'SELECT "{cat_col}", "{name_col}", "{metric_col}" FROM ranked WHERE rn = 1 ORDER BY "{cat_col}"'
        )

        try:
            result = self.duckdb_manager.execute_query(sql)
        except Exception as e:
            logger.warning(f"Deterministic top-per-group SQL failed to execute: {e} | SQL: {sql}")
            return None
        if result.get("row_count", 0) == 0:
            logger.info(f"Deterministic top-per-group SQL returned 0 rows, discarding: {sql}")
            return None

        logger.info(f"Deterministic top-per-group SQL built (bypassing LLM): {sql}")
        return {"sql": sql, "result": result}

    def _answer_tabular(
        self,
        question: str,
        filters: Optional[Dict],
        session_history: Optional[List[Dict]] = None,
        k: int = TOP_K,
    ) -> Dict[str, Any]:
        """
        FIX v2: Added hybrid fallback.
        If SQL generation or execution fails / returns 0 rows, automatically
        fall back to semantic search so the user never gets a blank answer
        just because the LLM wrote imperfect SQL.
        """
        # FIX v2: Use schema + sample rows for better SQL accuracy
        try:
            schema, sample_rows = self.duckdb_manager.get_schema_with_samples()
        except AttributeError:
            # Backward compat if method not yet available
            schema = self.duckdb_manager.get_schema()
            sample_rows = None

        if "No tabular data" in schema or not schema.strip():
            # No DuckDB data at all — silently fall back to semantic
            logger.info("No tabular data in DuckDB, falling back to semantic search")
            return self._answer_semantic(question, session_history, filters, k)

        # Deterministic shortcut for "top/best X per Y" questions: a small local LLM
        # repeatedly invents unnecessary cross-table JOINs for this exact pattern, so
        # try building the correct single-table window-function SQL directly from the
        # schema first. Falls through to normal LLM generation if it doesn't apply.
        heuristic = self._try_top_per_group_sql(question)
        if heuristic:
            sql = heuristic["sql"]
            query_result = heuristic["result"]
            return self._build_tabular_response(question, sql, query_result)

        sql_result_obj = generate_sql(
            question, schema, model=self.model, base_url=self.ollama_url,
            sample_rows=sample_rows,
        )

        if not sql_result_obj["is_valid"] or not sql_result_obj["sql"]:
            logger.warning(
                f"SQL generation failed: {sql_result_obj['validation_message']}. "
                f"Falling back to semantic search."
            )
            fallback = self._answer_semantic(question, session_history, filters, k)
            # BUGFIX: previously, if semantic search also came back empty, this
            # silently left the generic "No documents ingested yet. Please upload
            # files first." message in place — which is actively misleading here,
            # since we already confirmed tabular data DOES exist (the "No tabular
            # data" check above passed). The real problem is that SQL generation
            # itself failed (e.g. the LLM is unreachable, or produced invalid SQL),
            # not that nothing was uploaded. Surface the real reason instead, same
            # as _tabular_failure_response() does for SQL *execution* failures.
            if fallback["confidence"] == 0.0 and self.vector_store.collection.count() == 0:
                fallback["answer"] = (
                    f"I could not generate a valid SQL query for this question.\n\n"
                    f"Reason: {sql_result_obj['validation_message']}\n\n"
                    f"This usually means the LLM used for SQL generation is unavailable "
                    f"(check that Ollama is running), or the question needs rephrasing. "
                    f"There are also no semantic documents uploaded to fall back to."
                )
            fallback["query_type"]  = "tabular_fallback_semantic"
            fallback["sql"]         = sql_result_obj.get("sql")
            fallback["sql_result"]  = None
            return fallback


        sql = sql_result_obj["sql"]

        # PROBLEM 3/4 (SQL Planner / Validation): verify the SQL only references
        # tables that actually exist in the discovered schema *before* spending
        # a DuckDB execution + one-shot repair cycle on it. Catches a
        # hallucinated table name immediately and routes straight to the
        # one-shot repair with a precise reason, instead of surfacing DuckDB's
        # own (less actionable) "Catalog Error".
        schema_ok, schema_reason = self.duckdb_manager.validate_sql_schema(sql)
        if not schema_ok:
            logger.warning(f"SQL failed schema validation: {schema_reason} | SQL: {sql}")
            try:
                repaired = repair_sql(
                    question, schema, failing_sql=sql, error_message=schema_reason,
                    model=self.model, base_url=self.ollama_url,
                )
            except Exception as repair_err:
                logger.error(f"Schema-validation repair call failed: {repair_err}. Falling back to semantic.")
                return self._tabular_failure_response(
                    question, session_history, filters, k,
                    sql=sql, error=RuntimeError(schema_reason),
                )
            repaired_ok = bool(repaired.get("is_valid") and repaired.get("sql"))
            if repaired_ok:
                repaired_schema_ok, _ = self.duckdb_manager.validate_sql_schema(repaired["sql"])
                repaired_ok = repaired_schema_ok
            if repaired_ok:
                sql = repaired["sql"]
                logger.info(f"SQL schema-validation repair succeeded | Fixed SQL: {sql}")
            else:
                return self._tabular_failure_response(
                    question, session_history, filters, k,
                    sql=sql, error=RuntimeError(schema_reason),
                )

        try:
            query_result = self.duckdb_manager.execute_query(sql)
        except Exception as e:
            logger.warning(f"SQL execution failed: {e} | SQL: {sql}. Attempting one-shot repair.")

            # One-shot self-repair: re-prompt the LLM with the exact DuckDB error before
            # giving up and falling back to semantic search. Catches cases like a
            # hallucinated function (e.g. RIGHT() used instead of ROUND()) or a missing
            # GROUP BY, which validate_sql() can't detect ahead of execution.
            try:
                repaired = repair_sql(
                    question, schema, failing_sql=sql, error_message=str(e),
                    model=self.model, base_url=self.ollama_url,
                )
            except Exception as repair_err:
                logger.error(f"SQL repair call itself failed: {repair_err}. Falling back to semantic.")
                return self._tabular_failure_response(
                    question, session_history, filters, k,
                    sql=sql, error=e,
                )

            if repaired["is_valid"] and repaired["sql"]:
                try:
                    query_result = self.duckdb_manager.execute_query(repaired["sql"])
                    sql = repaired["sql"]
                    logger.info(f"SQL repair succeeded | Fixed SQL: {sql}")
                except Exception as e2:
                    logger.error(
                        f"Repaired SQL also failed: {e2} | SQL: {repaired['sql']}. "
                        f"Falling back to semantic."
                    )
                    return self._tabular_failure_response(
                        question, session_history, filters, k,
                        sql=repaired["sql"], error=e2,
                    )
            else:
                logger.error("SQL repair did not produce valid SQL. Falling back to semantic.")
                return self._tabular_failure_response(
                    question, session_history, filters, k,
                    sql=sql, error=e,
                )

        # FIX: If SQL runs but returns 0 rows, this is very often a wrong JOIN/WHERE that
        # eliminated every row (rather than a real "no data" case) — give the LLM one shot
        # at repairing it with that explicit feedback before giving up on tabular entirely.
        if query_result["row_count"] == 0:
            logger.warning(
                f"SQL returned 0 rows for: '{question}'. "
                f"SQL: {sql}. Attempting one-shot zero-row repair."
            )
            try:
                repaired = repair_sql(
                    question, schema, failing_sql=sql,
                    error_message=(
                        "The query executed without a DuckDB error but returned ZERO rows. "
                        "This almost always means a JOIN or WHERE condition does not actually "
                        "hold for any real row — most commonly an unnecessary JOIN to a second "
                        "table on a guessed/loosely-named relationship (e.g. comparing two "
                        "columns that hold different kinds of values, such as a subject name "
                        "vs a section letter). First check whether ONE table already contains "
                        "every column the question needs (the metric, the name, and the "
                        "category) — if so, drop the JOIN entirely and query that single table."
                    ),
                    model=self.model, base_url=self.ollama_url,
                )
            except Exception as repair_err:
                logger.error(f"Zero-row SQL repair call failed: {repair_err}.")
                repaired = {"is_valid": False, "sql": None}

            if repaired["is_valid"] and repaired["sql"]:
                try:
                    repaired_result = self.duckdb_manager.execute_query(repaired["sql"])
                    if repaired_result["row_count"] > 0:
                        logger.info(f"Zero-row SQL repair succeeded | Fixed SQL: {repaired['sql']}")
                        sql = repaired["sql"]
                        query_result = repaired_result
                except Exception as e2:
                    logger.warning(f"Repaired zero-row SQL also failed to execute: {e2}")

        if query_result["row_count"] == 0:
            fallback = self._answer_semantic(question, session_history, filters, k)
            if fallback["confidence"] > 0:
                fallback["query_type"] = "tabular_fallback_semantic"
                fallback["sql"]        = sql
                fallback["sql_result"] = query_result
                return fallback
            # Both returned nothing — give honest answer with SQL info
            return {
                "answer": (
                    f"The query returned no results.\n\n"
                    f"SQL attempted: `{sql}`\n\n"
                    "Please verify column names match your data or rephrase your question."
                ),
                "query_type": "tabular",
                "confidence": 0.0,
                "sources":    [],
                "chunks":     [],
                "sql":        sql,
                "sql_result": query_result,
            }

        result_text = format_query_result(query_result, question)
        return self._build_tabular_response(question, sql, query_result, result_text)

    def _build_tabular_response(
        self,
        question: str,
        sql: str,
        query_result: Dict[str, Any],
        result_text: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Shared tail: turn an already-executed, non-empty query_result into the final
        natural-language answer dict. Used by both the deterministic heuristic path and
        the normal LLM-generated-SQL path so the two stay in sync.
        """
        if result_text is None:
            result_text = format_query_result(query_result, question)
        actual_row_count = query_result.get("row_count", len(query_result.get("rows", [])))

        # BUGFIX: compute ground truth for categorical/binary columns (e.g.
        # admission_status) directly from the rows, in Python, before the LLM
        # ever sees them. This is what lets us both (a) instruct the model
        # with facts it must not contradict, and (b) verify/override its
        # prose afterward instead of trusting it blindly.
        rows = query_result.get("rows", [])
        columns = query_result.get("columns", [])
        cat_summary = compute_categorical_summary(rows, columns)
        verified_facts_text = format_verified_facts(cat_summary)

        facts_block = ""
        if verified_facts_text:
            facts_block = (
                f"\nVerified ground-truth value counts (computed by code, not by you — "
                f"these are 100% accurate and MUST NOT be contradicted):\n"
                f"{verified_facts_text}\n"
            )

        prompt = (
            f"The following data was already correctly filtered, ranked, and/or "
            f"aggregated by a SQL query specifically built to answer this question. "
            f"Do not say information is missing — present these exact rows as the answer.\n\n"
            f"Question: {question}\n\n"
            f"SQL used: {sql}\n\n"
            f"Query result (Row count: {actual_row_count}):\n{result_text}\n"
            f"{facts_block}\n"
            f"Write a natural-language answer using ONLY the data shown above. Rules:\n"
            f"- Never echo raw output like 'count(\"name\")=268' or 'row 1: x=y' — translate every "
            f"value into a plain English sentence (e.g. '268 students are Male').\n"
            f"- If the question implied a comparison or breakdown across a SMALL number of "
            f"categories (e.g. 'X vs Y', 'by gender', up to ~10 groups), state EVERY group's value "
            f"explicitly — do not report only the first group.\n"
            f"- NEVER assume every row shares the same value for a categorical or binary/status "
            f"column (e.g. admission_status, is_active, pass/fail). Check each row, and if the "
            f"'Verified ground-truth value counts' above lists more than one value for a column, "
            f"your answer MUST mention every one of those values and how many rows have each — "
            f"do not claim 'all' or 'every' row shares one value when the counts show otherwise.\n"
            f"- If the result is a LIST of individual matching rows (e.g. 'which students have X', "
            f"potentially many rows), do NOT enumerate every single row as a wall of text. Instead: "
            f"state the total count first (use the exact Row count shown above, even if only some "
            f"rows are displayed), then show ALL identifying values (e.g. every student_id) as a "
            f"compact comma-separated list or a short Markdown table — never silently drop rows or "
            f"only mention the first N without saying how many there are in total.\n"
            f"- Include exact numbers exactly as they appear in the result — do not round, estimate, "
            f"or omit any value present in the data.\n"
            f"- If the result only contains names/labels (e.g. \"who are the top 5\"), list them "
            f"plainly — do not claim underlying numeric values are missing if none were requested.\n"
            f"- Use a short Markdown table or bullet list when presenting 2+ rows of comparison data; "
            f"use a single plain sentence for a single-value result."
        )

        try:
            answer = _call_ollama_generate(prompt, self.model, self.ollama_url)
        except Exception as e:
            answer = f"Query result:\n{result_text}"
            logger.warning(f"LLM explanation failed, returning raw result: {e}")

        # BUGFIX: never trust the LLM's prose alone for categorical/binary
        # columns. Cross-check its claims against the code-computed ground
        # truth; if it contradicts (e.g. says "all admitted" while the
        # verified counts show a mix), log it loudly and always append the
        # verified breakdown so the user-facing answer is guaranteed correct
        # regardless of what the model wrote.
        mismatch_detected = False
        for col, counts in cat_summary.items():
            if len(counts) <= 1:
                continue
            values_str = [str(v) for v in counts.keys()]
            # BUGFIX: word-boundary check must guard against ANY adjacent word
            # character, not just digits. An earlier version of this fix only
            # excluded digit neighbors (to stop "0" matching inside "10"), but
            # categorical columns aren't always numeric — a value like "A" would
            # still wrongly match inside "Average" or "Admitted" under a
            # digits-only lookaround. Using \w on both sides catches both cases.
            mentions_all_values = all(
                re.search(rf"(?<!\w){re.escape(v)}(?!\w)", answer, re.IGNORECASE)
                for v in values_str
            )
            claims_uniformity = bool(
                re.search(r"\ball\b|\bevery\b|\beach\b", answer, re.IGNORECASE)
            )
            if claims_uniformity and not mentions_all_values:
                mismatch_detected = True
                logger.warning(
                    f"Tabular answer may contradict verified data for column '{col}': "
                    f"ground truth counts={counts}, but answer does not mention all values. "
                    f"Appending verified breakdown to correct the user-facing answer."
                )

        verified_breakdown_md = format_verified_breakdown_markdown(cat_summary)
        if verified_breakdown_md:
            answer = f"{answer.strip()}\n\n{verified_breakdown_md}"

        sources = []
        for tname in self.duckdb_manager.list_tables():
            info = self.duckdb_manager.get_table_info(tname)
            if info and info.get("source_file"):
                sources.append(Path(info["source_file"]).name)

        logger.info(f"Tabular answer done | SQL: {sql} | rows: {query_result['row_count']}")
        return {
            "answer":            answer,
            "query_type":        "tabular",
            # BUGFIX: confidence is no longer a blind 1.0 — if the model's prose
            # looked like it contradicted the verified ground-truth counts,
            # reflect that so callers (API/UI) can show a warning instead of
            # silently presenting an unverified claim as 100% confident.
            "confidence":        0.85 if mismatch_detected else 1.0,
            "low_confidence_warning": mismatch_detected,
            "sources":           list(set(sources)),
            "chunks":            [],
            "sql":               sql,
            "sql_result":        query_result,
            "verified_summary":  cat_summary,
        }

    def _attach_chart_if_requested(self, question: str, result: Dict[str, Any]) -> None:
        """
        NEW: Additive hook for AI-powered chart generation.

        Runs AFTER the normal answer has already been produced and mutates
        `result` in place by adding a "chart" key when (and only when) the
        question expresses visualization intent. Never raises — a problem
        generating a chart must never turn a good text answer into an error.
        """
        try:
            chart = maybe_generate_chart(question, self.duckdb_manager, self.model, self.ollama_url)
            if chart:
                result["chart"] = chart
        except Exception as e:
            logger.error(f"Chart generation failed unexpectedly (answer unaffected): {e}", exc_info=True)

    def check_ollama(self) -> bool:
        """
        Ping Ollama and confirm the configured model is installed.
        Used by the /health endpoint — must be a real method (not dead code)
        or api/app.py's `service.check_ollama()` call raises AttributeError,
        which /health silently swallows and reports as "Ollama down" even
        when Ollama is running fine.
        """
        try:
            req = urllib.request.Request(f"{self.ollama_url}/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=5) as resp:
                data       = json.loads(resp.read())
                names      = [m["name"] for m in data.get("models", [])]
                base_names = [n.split(":")[0] for n in names]
                self_base  = self.model.split(":")[0]
                # Match on full tagged name first, then fall back to base name
                # (e.g. self.model="phi3:latest" vs installed "phi3:latest",
                # or self.model="llama3.2" vs installed "llama3.2:latest").
                return self.model in names or self_base in base_names
        except Exception:
            return False
