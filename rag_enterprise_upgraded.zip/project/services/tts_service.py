"""
services/tts_service.py — Offline Read Aloud (Text-to-Speech) service.

100% offline. Never calls out to any network / cloud TTS API. Designed so the
engine underneath can be swapped (Piper, pyttsx3, or a future engine) without
any change to the API contract in routers/tts_router.py or to the frontend.

Architecture
------------
TTSEngine            - abstract interface: synthesize_to_wav(text, out_path)
PiperEngine           - preferred engine (Piper, ONNX voice models, local files only)
Pyttsx3Engine         - fallback engine (system TTS: espeak-ng / SAPI5 / NSSpeech)
TTSService            - orchestrates engine selection, sentence-safe chunking,
                        merging chunks into one continuous WAV, disk caching,
                        and cache eviction/cleanup. This is the only class the
                        rest of the app talks to (see api/dependencies.py).

Nothing in this file touches the RAG pipeline, Ollama, ChromaDB, DuckDB,
sessions, or any existing service.
"""

from __future__ import annotations

import hashlib
import os
import re
import time
import wave
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from utils.logger import get_logger

logger = get_logger("tts")


class TTSUnavailableError(RuntimeError):
    """Raised when no offline TTS engine could be initialized."""


class TTSSynthesisError(RuntimeError):
    """Raised when audio generation fails for a given input."""


# ─────────────────────────────────────────────────────────────────────────────
# Engine interface
# ─────────────────────────────────────────────────────────────────────────────

class TTSEngine(ABC):
    """Common interface every offline TTS engine implements.

    Keeping this tiny and file-based (write a WAV to a path) means a new
    engine can be plugged in later purely by adding a subclass here — no
    changes needed anywhere else (service orchestration, API, or frontend).
    """

    name: str = "base"

    @abstractmethod
    def synthesize_to_wav(self, text: str, out_path: Path) -> None:
        """Synthesize `text` and write a mono 16-bit PCM WAV file to out_path."""
        raise NotImplementedError


class PiperEngine(TTSEngine):
    """Preferred engine: Piper (ONNX voice models, fully offline)."""

    name = "piper"

    def __init__(self, model_path: str, config_path: str = "", use_cuda: bool = False):
        from piper import PiperVoice  # imported lazily so a missing package
                                       # never breaks app startup — TTSService
                                       # falls back to the next engine instead.

        model_path = Path(model_path)
        if not model_path.exists():
            raise FileNotFoundError(f"Piper voice model not found: {model_path}")

        cfg_path = Path(config_path) if config_path else Path(f"{model_path}.json")
        if not cfg_path.exists():
            raise FileNotFoundError(f"Piper voice config not found: {cfg_path}")

        self._voice = PiperVoice.load(str(model_path), config_path=str(cfg_path), use_cuda=use_cuda)
        logger.info(f"Piper TTS engine loaded: {model_path.name}")

    def synthesize_to_wav(self, text: str, out_path: Path) -> None:
        with wave.open(str(out_path), "wb") as wav_file:
            self._voice.synthesize_wav(text, wav_file)


class Pyttsx3Engine(TTSEngine):
    """Fallback engine: system-native offline TTS via pyttsx3.

    Uses espeak-ng on Linux, SAPI5 on Windows, NSSpeechSynthesizer on macOS —
    all fully offline, no model download required, so Read Aloud still works
    immediately even before a Piper voice model has been installed.
    """

    name = "pyttsx3"

    def __init__(self, voice_id: str = "", rate: int = 175):
        import pyttsx3  # lazy import, same reasoning as PiperEngine

        # pyttsx3 engines are not thread-safe / reusable across calls reliably
        # on all platforms, so we keep just the config here and construct a
        # fresh engine per synthesis call in synthesize_to_wav().
        self._voice_id = voice_id
        self._rate = rate

        # Fail fast at construction time if the driver can't even start,
        # so TTSService can fall back to "no engine available" cleanly
        # instead of failing later on the first real request.
        probe = pyttsx3.init()
        try:
            if not probe.getProperty("voices"):
                raise RuntimeError("No system TTS voices installed")
        finally:
            probe.stop()
        logger.info("pyttsx3 (system offline TTS) engine ready")

    def synthesize_to_wav(self, text: str, out_path: Path) -> None:
        import pyttsx3

        engine = pyttsx3.init()
        try:
            engine.setProperty("rate", self._rate)
            if self._voice_id:
                engine.setProperty("voice", self._voice_id)
            engine.save_to_file(text, str(out_path))
            engine.runAndWait()
        finally:
            engine.stop()


# ─────────────────────────────────────────────────────────────────────────────
# Chunking helpers
# ─────────────────────────────────────────────────────────────────────────────

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def _split_into_chunks(text: str, max_chars: int) -> List[str]:
    """Split text into chunks on sentence boundaries, each <= max_chars.

    Never breaks mid-sentence (unless a single sentence itself exceeds
    max_chars, in which case it is kept whole rather than corrupted — Piper
    and pyttsx3 both handle long single sentences fine, just slower).
    This keeps playback of long responses seamless: chunks are synthesized
    separately for robustness/memory, then merged into one continuous WAV.
    """
    text = text.strip()
    if not text:
        return []

    sentences = _SENTENCE_SPLIT_RE.split(text)
    chunks: List[str] = []
    current = ""

    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
        candidate = f"{current} {sentence}".strip() if current else sentence
        if len(candidate) <= max_chars or not current:
            current = candidate
        else:
            chunks.append(current)
            current = sentence

    if current:
        chunks.append(current)

    return chunks


def _merge_wavs(chunk_paths: List[Path], out_path: Path) -> None:
    """Concatenate same-format mono PCM WAV files into a single WAV file."""
    if not chunk_paths:
        raise TTSSynthesisError("No audio chunks were generated.")

    with wave.open(str(chunk_paths[0]), "rb") as first:
        params = first.getparams()

    with wave.open(str(out_path), "wb") as out_wav:
        out_wav.setparams(params)
        for p in chunk_paths:
            with wave.open(str(p), "rb") as chunk_wav:
                out_wav.writeframes(chunk_wav.readframes(chunk_wav.getnframes()))


# ─────────────────────────────────────────────────────────────────────────────
# Cache
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CacheStats:
    files: int
    total_bytes: int


class _AudioCache:
    """Local-disk-only cache, keyed by a hash of the exact text synthesized.

    Nothing here ever leaves the machine. Oldest entries are evicted once the
    cache exceeds a configured size cap, and entries past a TTL are purged on
    each cleanup pass — keeps disk usage bounded without an external process.
    """

    def __init__(self, cache_dir: str, enabled: bool, max_mb: int, ttl_hours: int):
        self.dir = Path(cache_dir)
        self.enabled = enabled
        self.max_bytes = max_mb * 1024 * 1024
        self.ttl_seconds = ttl_hours * 3600
        if self.enabled:
            self.dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def key_for(text: str, engine_name: str) -> str:
        h = hashlib.sha256()
        h.update(engine_name.encode("utf-8"))
        h.update(b"\x00")
        h.update(text.encode("utf-8"))
        return h.hexdigest()

    def path_for(self, key: str) -> Path:
        return self.dir / f"{key}.wav"

    def get(self, key: str) -> Optional[Path]:
        if not self.enabled:
            return None
        p = self.path_for(key)
        if p.exists():
            try:
                os.utime(p, None)  # touch for LRU-by-mtime eviction
            except OSError:
                pass
            return p
        return None

    def put(self, key: str, src_path: Path) -> Path:
        dest = self.path_for(key)
        if not self.enabled:
            return src_path
        try:
            if src_path != dest:
                src_path.replace(dest)
            self._evict_if_needed()
            return dest
        except OSError as e:
            logger.warning(f"TTS cache write failed, serving uncached: {e}")
            return src_path

    def _evict_if_needed(self) -> None:
        try:
            entries = [(p, p.stat()) for p in self.dir.glob("*.wav")]
        except OSError:
            return

        now = time.time()
        # TTL purge first
        kept = []
        for p, st in entries:
            if now - st.st_mtime > self.ttl_seconds:
                try:
                    p.unlink(missing_ok=True)
                except OSError:
                    pass
            else:
                kept.append((p, st))

        # Size-based LRU eviction (oldest mtime first)
        total = sum(st.st_size for _, st in kept)
        if total <= self.max_bytes:
            return
        kept.sort(key=lambda t: t[1].st_mtime)
        for p, st in kept:
            if total <= self.max_bytes:
                break
            try:
                p.unlink(missing_ok=True)
                total -= st.st_size
            except OSError:
                pass

    def clear(self) -> int:
        count = 0
        for p in self.dir.glob("*.wav"):
            try:
                p.unlink(missing_ok=True)
                count += 1
            except OSError:
                pass
        return count

    def stats(self) -> CacheStats:
        try:
            entries = list(self.dir.glob("*.wav"))
            return CacheStats(files=len(entries), total_bytes=sum(p.stat().st_size for p in entries))
        except OSError:
            return CacheStats(files=0, total_bytes=0)


# ─────────────────────────────────────────────────────────────────────────────
# Orchestrating service
# ─────────────────────────────────────────────────────────────────────────────

class TTSService:
    """Public entry point used by routers/tts_router.py.

    Selects an available engine at startup (Piper preferred, pyttsx3 as an
    offline fallback), and exposes a single synthesize() method that handles
    chunking + merging + caching + temp-file cleanup.
    """

    def __init__(
        self,
        engine_mode: str,
        piper_model_path: str,
        piper_config_path: str,
        piper_use_cuda: bool,
        pyttsx3_voice_id: str,
        pyttsx3_rate: int,
        max_chars_per_chunk: int,
        max_input_chars: int,
        cache_dir: str,
        cache_enabled: bool,
        cache_max_mb: int,
        cache_ttl_hours: int,
        temp_dir: str,
    ):
        self.max_chars_per_chunk = max_chars_per_chunk
        self.max_input_chars = max_input_chars
        self.temp_dir = Path(temp_dir)
        self.temp_dir.mkdir(parents=True, exist_ok=True)

        self.cache = _AudioCache(cache_dir, cache_enabled, cache_max_mb, cache_ttl_hours)
        self.engine: Optional[TTSEngine] = self._select_engine(
            engine_mode, piper_model_path, piper_config_path, piper_use_cuda,
            pyttsx3_voice_id, pyttsx3_rate,
        )

    # ── engine selection ────────────────────────────────────────────────

    def _select_engine(
        self, mode: str, piper_model_path: str, piper_config_path: str, piper_use_cuda: bool,
        pyttsx3_voice_id: str, pyttsx3_rate: int,
    ) -> Optional[TTSEngine]:
        mode = (mode or "auto").lower()
        errors = []

        def try_piper() -> Optional[TTSEngine]:
            try:
                return PiperEngine(piper_model_path, piper_config_path, piper_use_cuda)
            except Exception as e:
                errors.append(f"piper: {e}")
                return None

        def try_pyttsx3() -> Optional[TTSEngine]:
            try:
                return Pyttsx3Engine(pyttsx3_voice_id, pyttsx3_rate)
            except Exception as e:
                errors.append(f"pyttsx3: {e}")
                return None

        engine: Optional[TTSEngine] = None
        if mode == "piper":
            engine = try_piper()
        elif mode == "pyttsx3":
            engine = try_pyttsx3()
        else:  # auto
            engine = try_piper() or try_pyttsx3()

        if engine is None:
            logger.warning(
                "No offline TTS engine could be initialized (Read Aloud will be "
                f"unavailable until one is configured). Details: {'; '.join(errors)}"
            )
        return engine

    @property
    def is_available(self) -> bool:
        return self.engine is not None

    @property
    def engine_name(self) -> str:
        return self.engine.name if self.engine else "none"

    # ── synthesis ────────────────────────────────────────────────────────

    def synthesize(self, text: str) -> tuple[bytes, bool]:
        """Return (wav_bytes, was_cached) for the given text.

        Raises TTSUnavailableError if no engine is configured, or
        TTSSynthesisError if generation fails.
        """
        if self.engine is None:
            raise TTSUnavailableError(
                "No offline TTS engine is configured on this server. "
                "Install a Piper voice model or pyttsx3 to enable Read Aloud."
            )

        text = (text or "").strip()
        if not text:
            raise TTSSynthesisError("No text to read aloud.")
        if len(text) > self.max_input_chars:
            text = text[: self.max_input_chars]
            logger.info(f"TTS input truncated to {self.max_input_chars} chars")

        cache_key = _AudioCache.key_for(text, self.engine.name)
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached.read_bytes(), True

        chunks = _split_into_chunks(text, self.max_chars_per_chunk)
        if not chunks:
            raise TTSSynthesisError("No text to read aloud.")

        chunk_paths: List[Path] = []
        stamp = f"{int(time.time() * 1000)}_{os.getpid()}"
        try:
            for i, chunk in enumerate(chunks):
                cp = self.temp_dir / f"tts_{stamp}_{i}.wav"
                try:
                    self.engine.synthesize_to_wav(chunk, cp)
                except Exception as e:
                    raise TTSSynthesisError(f"Audio generation failed: {e}") from e
                chunk_paths.append(cp)

            merged_path = self.temp_dir / f"tts_{stamp}_merged.wav"
            if len(chunk_paths) == 1:
                chunk_paths[0].replace(merged_path)
            else:
                _merge_wavs(chunk_paths, merged_path)
                for cp in chunk_paths:
                    cp.unlink(missing_ok=True)

            final_path = self.cache.put(cache_key, merged_path)
            data = final_path.read_bytes()
            return data, False
        finally:
            # Best-effort cleanup of any leftover temp chunk files.
            for cp in chunk_paths:
                try:
                    cp.unlink(missing_ok=True)
                except OSError:
                    pass

    def clear_cache(self) -> int:
        return self.cache.clear()

    def cache_stats(self) -> CacheStats:
        return self.cache.stats()
