#!/usr/bin/env bash
set -e

BOLD="\033[1m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
RED="\033[0;31m"
CYAN="\033[0;36m"
RESET="\033[0m"

info()    { echo -e "${CYAN}[INFO]${RESET}  $1"; }
success() { echo -e "${GREEN}[OK]${RESET}    $1"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $1"; }
error()   { echo -e "${RED}[ERROR]${RESET} $1"; exit 1; }
step()    { echo -e "\n${BOLD}━━━  $1  ━━━${RESET}"; }

# ─── Detect OS ───────────────────────────────────────────────────────────────
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if command -v apt-get &>/dev/null; then OS="debian"
        elif command -v yum &>/dev/null;     then OS="rhel"
        else OS="linux"; fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then OS="mac"
    else OS="unknown"; fi
    info "Detected OS: $OS"
}

# ─── Check System Tools ────────────────────────────────────────────────────────
check_system_deps() {
    step "System Dependencies"
    info "Checking required tools (no installation attempted)..."

    command -v tesseract &>/dev/null \
        && success "tesseract: $(tesseract --version 2>&1 | head -1)" \
        || warn "tesseract not found — OCR on scanned PDFs/images will be limited"

    command -v pdfinfo &>/dev/null \
        && success "poppler: found" \
        || warn "poppler not found — scanned PDF conversion may be limited"

    command -v python3 &>/dev/null \
        && success "python3: $(python3 --version)" \
        || error "python3 not found. Please install Python 3.10+ first."

    command -v curl &>/dev/null \
        && success "curl: found" \
        || error "curl not found. Please install curl."
}

# ─── Ollama — install to user home ───────────────────────────────────────────────
install_ollama() {
    step "Ollama"

    if command -v ollama &>/dev/null; then
        success "Ollama already installed: $(ollama --version 2>/dev/null || echo 'ok')"
        return 0
    fi

    # Download binary directly to ~/.local/bin
    info "Installing Ollama to ~/.local/bin..."
    mkdir -p "$HOME/.local/bin"

    OLLAMA_VERSION="latest"
    ARCH=$(uname -m)
    case "$ARCH" in
        x86_64)  ARCH_TAG="amd64" ;;
        aarch64) ARCH_TAG="arm64" ;;
        *)        ARCH_TAG="amd64" ;;
    esac

    OLLAMA_URL="https://github.com/ollama/ollama/releases/latest/download/ollama-linux-${ARCH_TAG}"

    if curl -fsSL "$OLLAMA_URL" -o "$HOME/.local/bin/ollama"; then
        chmod +x "$HOME/.local/bin/ollama"
        export PATH="$HOME/.local/bin:$PATH"
        success "Ollama installed to ~/.local/bin/ollama"
    else
        warn "Direct download failed. Trying official installer (may ask for password)..."
        # Run installer but tell it to skip systemd service registration
        OLLAMA_NO_PRIV=1 curl -fsSL https://ollama.com/install.sh | OLLAMA_INSTALL_DIR="$HOME/.local/bin" sh 2>/dev/null \
            || warn "Ollama installer failed. If ollama is already in PATH, continuing..."
    fi

    # Verify
    command -v ollama &>/dev/null \
        && success "Ollama available: $(ollama --version 2>/dev/null)" \
        || error "Ollama not found. Install manually: https://ollama.com/download"
}

start_ollama() {
    info "Checking Ollama server..."
    # Ensure ~/.local/bin is in PATH
    export PATH="$HOME/.local/bin:$PATH"

    if curl -s --max-time 3 http://localhost:11434/api/tags &>/dev/null; then
        success "Ollama server already running"
        return 0
    fi

    info "Starting Ollama server in background..."
    mkdir -p logs
    nohup ollama serve > logs/ollama.log 2>&1 &
    OLLAMA_PID=$!
    echo $OLLAMA_PID > .ollama.pid

    for i in $(seq 1 25); do
        sleep 1
        if curl -s --max-time 2 http://localhost:11434/api/tags &>/dev/null; then
            success "Ollama server started (PID $OLLAMA_PID)"
            return 0
        fi
    done
    error "Ollama failed to start in 25 seconds. Check logs/ollama.log"
}

pull_models() {
    step "Ollama Models"
    export PATH="$HOME/.local/bin:$PATH"

    for model in "llama3.2" "nomic-embed-text"; do
        if ollama list 2>/dev/null | grep -q "$model"; then
            success "Model already available: $model"
        else
            info "Pulling $model (may take several minutes on first run)..."
            ollama pull "$model" \
                && success "Pulled: $model" \
                || error "Could not pull $model. Check connectivity."
        fi
    done
}

# ─── Python venv ─────────────────────────────────────────────────────────────
setup_python() {
    step "Python Environment"

    PYTHON=""
    for cmd in python3.11 python3.12 python3.10 python3 python; do
        if command -v $cmd &>/dev/null; then
            VER=$($cmd -c "import sys; print(sys.version_info >= (3,10))" 2>/dev/null)
            if [[ "$VER" == "True" ]]; then PYTHON=$cmd; break; fi
        fi
    done
    [[ -z "$PYTHON" ]] && error "Python 3.10+ not found."
    success "Using: $PYTHON ($($PYTHON --version))"

    if [[ ! -d "venv" ]]; then
        info "Creating virtual environment..."
        $PYTHON -m venv venv
        success "venv created"
    else
        success "venv already exists"
    fi

    source venv/bin/activate
    pip install --upgrade pip -q
    success "venv activated"
}

# ─── Python Packages ───────────────────────────────────────────────────────────
install_python_deps() {
    step "Python Packages"

    info "Installing core packages..."
    pip install -q \
        fastapi "uvicorn[standard]" pydantic python-multipart \
        chromadb duckdb pandas openpyxl xlrd \
        pypdf python-docx python-pptx \
        beautifulsoup4 lxml \
        rank-bm25 tiktoken numpy python-dotenv \
        && success "Core packages installed"

    info "Installing image/OCR packages..."
    pip install -q Pillow pdf2image pytesseract \
        && success "Pillow + pytesseract installed"

    info "Installing reranker (sentence-transformers)..."
    pip install -q sentence-transformers 2>/dev/null \
        && success "Reranker installed" \
        || warn "Reranker skipped — retrieval works fine without it"

    info "Installing PDF export (reportlab)..."
    pip install -q "reportlab>=4.0.0" \
        && success "reportlab installed" \
        || warn "reportlab skipped — the chat UI's PDF export ('Download' button) will not work"

    info "Installing Read Aloud (TTS) packages..."
    pip install -q pyttsx3 piper-tts 2>/dev/null \
        && success "TTS packages installed" \
        || warn "TTS packages skipped — Read Aloud will be unavailable"

    # Catch-all: true up against requirements.txt in case a dependency was
    # added there but missed in the curated list above (this is exactly what
    # broke PDF export before — this script had drifted out of sync with
    # requirements.txt). Safe/fast to re-run; already-installed packages skip.
    if [[ -f "requirements.txt" ]]; then
        info "Syncing any remaining packages from requirements.txt..."
        pip install -q -r requirements.txt 2>/dev/null \
            && success "requirements.txt fully synced" \
            || warn "Some optional packages in requirements.txt could not be installed — check logs above"
    fi
}

# ─── Directories & Config ─────────────────────────────────────────────────────
setup_dirs() {
    step "Directories & Config"
    mkdir -p logs data chroma_db
    success "Directories ready: logs/ data/ chroma_db/"
    if [[ ! -f ".env" && -f ".env.example" ]]; then
        cp .env.example .env
        success "Created .env from .env.example"
    fi
}

# ─── Validate ────────────────────────────────────────────────────────────────
validate() {
    step "Validation"
    source venv/bin/activate
    python -c "import fastapi, chromadb, duckdb, pandas" \
        && success "Core imports OK" \
        || error "Core import check failed"
    curl -s --max-time 3 http://localhost:11434/api/tags &>/dev/null \
        && success "Ollama reachable" \
        || warn "Ollama not reachable — check logs/ollama.log"
}

# ─── Launch ──────────────────────────────────────────────────────────────────
launch() {
    step "Launching"
    source venv/bin/activate
    export PATH="$HOME/.local/bin:$PATH"
    [[ -f ".env" ]] && export $(grep -v '^#' .env | xargs) 2>/dev/null

    PORT=${API_PORT:-8000}
    HOST=${API_HOST:-0.0.0.0}

    echo ""
    echo -e "${BOLD}${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${BOLD}  Enterprise RAG Agent v2.0 — READY${RESET}"
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo ""
    echo -e "  ${BOLD}API:${RESET}    http://localhost:${PORT}"
    echo -e "  ${BOLD}Docs:${RESET}   http://localhost:${PORT}/docs"
    echo -e "  ${BOLD}Health:${RESET} http://localhost:${PORT}/health"
    echo ""
    echo -e "  ${YELLOW}Press Ctrl+C to stop${RESET}"
    echo ""

    uvicorn main:app --host "$HOST" --port "$PORT" --workers 1
}

# ─── Main ────────────────────────────────────────────────────────────────────
main() {
    clear
    echo -e "${BOLD}${CYAN}"
    echo "  ╔═══════════════════════════════════════════╗"
    echo "  ║     Enterprise RAG Agent — Setup v2.0     ║"
    echo "  ╚═══════════════════════════════════════════╝"
    echo -e "${RESET}"

    [[ ! -f "main.py" ]] && error "Run from the rag_enterprise/ directory:\n  cd rag_enterprise && bash setup.sh"

    detect_os
    setup_dirs
    check_system_deps
    install_ollama
    start_ollama
    pull_models
    setup_python
    install_python_deps
    validate
    launch
}

main "$@"
