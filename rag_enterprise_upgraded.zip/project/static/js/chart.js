/* ============================================================
   static/js/chart.js — AI-Powered Chart Rendering (Apache ECharts)

   NEW FEATURE — purely additive frontend module.
   - Loaded locally (static/js/echarts.min.js), no CDN, no internet required.
   - Renders the structured chart metadata returned by the backend
     ( {type:"chart", chart_type, title, x, y, ...} ) as an interactive
     Apache ECharts visualization inside the chat.
   - Reuses the existing app theme (CSS variables from styles.css) so charts
     look like they have always been part of the UI.
   - Tracks every live chart instance so previous instances can always be
     disposed before new ones are created — avoids memory leaks even though
     app.js's renderChat() rebuilds the entire #chat-log innerHTML on every
     update.

   Public API (used by app.js):
     window.AIChart.disposeAll()
     window.AIChart.buildCard(chartSpec) -> HTMLElement   (the whole card:
       interactive chart + summary + download buttons, ready to insert)
   ============================================================ */

(() => {
  "use strict";

  if (!window.echarts) {
    // ECharts failed to load (e.g. file missing) — degrade silently.
    // renderMessage() in app.js already guards on chartSpec presence, so
    // simply not defining window.AIChart means chart cards are skipped.
    console.warn("[chart.js] Apache ECharts not found — AI chart rendering disabled.");
    return;
  }

  // ── Instance registry (for leak-free disposal) ───────────────────────────
  const _instances = new Map(); // container element -> {chart, resizeHandler, observer}

  function disposeAll() {
    for (const [, entry] of _instances) {
      try {
        window.removeEventListener("resize", entry.resizeHandler);
        if (entry.fsHandler) document.removeEventListener("fullscreenchange", entry.fsHandler);
        if (entry.observer) entry.observer.disconnect();
        entry.chart.dispose();
      } catch (e) { /* ignore */ }
    }
    _instances.clear();
    // Defensive cleanup: if a chart card was disposed while its fullscreen
    // element was still active (e.g. chat re-rendered mid-fullscreen), make
    // sure the browser doesn't stay stuck showing a now-removed element.
    if (document.fullscreenElement && document.exitFullscreen) {
      try { document.exitFullscreen(); } catch (e) { /* ignore */ }
    }
  }

  // ── Theme: read the app's own CSS variables so charts always match ──────
  function readTheme() {
    const cs = getComputedStyle(document.documentElement);
    const v = (name, fallback) => (cs.getPropertyValue(name) || "").trim() || fallback;
    return {
      text:      v("--text", "#E8E9ED"),
      textMuted: v("--text-muted", "#9AA1B2"),
      border:    v("--border", "#262B3B"),
      surface:   v("--surface", "#151A28"),
      surface2:  v("--surface-2", "#10141F"),
      accent:    v("--accent", "#6B76A3"),
      accentDark:v("--accent-dark", "#4A5471"),
      accentGlow:v("--accent-glow", "#98A0B7"),
      success:   v("--success", "#6BB700"),
      warning:   v("--warning", "#E0B400"),
      danger:    v("--danger", "#E0616E"),
      fontUi:    v("--font-ui", "sans-serif"),
    };
  }

  // A small palette derived from the app's own accent/slate tones so multi-
  // category charts (pie/donut/multi-bar) stay visually consistent with the
  // rest of the UI instead of introducing unrelated colors.
  function palette(theme) {
    return [
      theme.accent, theme.accentGlow, theme.success, theme.warning,
      theme.danger, theme.accentDark, "#7FB3D5", "#C39BD3",
      "#82C99A", "#E5B15C",
    ];
  }

  // ── Option builders per chart type ───────────────────────────────────────
  function baseAxisTextStyle(theme) {
    return { color: theme.textMuted, fontFamily: theme.fontUi, fontSize: 11 };
  }

  function buildOption(spec, theme) {
    const type = spec.chart_type;
    const colors = palette(theme);
    const common = {
      backgroundColor: "transparent",
      color: colors,
      textStyle: { color: theme.text, fontFamily: theme.fontUi },
      grid: { left: 48, right: 24, top: 36, bottom: 48, containLabel: true },
      tooltip: {
        trigger: type === "pie" || type === "donut" ? "item" : "axis",
        backgroundColor: theme.surface2,
        borderColor: theme.border,
        textStyle: { color: theme.text },
      },
    };

    const x = spec.x || [];
    const y = spec.y || [];

    switch (type) {
      case "horizontal_bar":
        return {
          ...common,
          xAxis: { type: "value", axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme), splitLine: { lineStyle: { color: theme.border, opacity: 0.4 } } },
          yAxis: { type: "category", data: x, axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme) },
          series: [{ type: "bar", data: y, barMaxWidth: 28, itemStyle: { borderRadius: [0, 4, 4, 0] } }],
        };

      case "pie":
      case "donut":
        return {
          ...common,
          legend: { bottom: 0, textStyle: { color: theme.textMuted, fontSize: 11 } },
          series: [{
            type: "pie",
            radius: type === "donut" ? ["45%", "72%"] : "62%",
            center: ["50%", "46%"],
            avoidLabelOverlap: true,
            itemStyle: { borderColor: theme.surface, borderWidth: 2 },
            label: { color: theme.textMuted, fontSize: 11 },
            data: x.map((name, i) => ({ name, value: y[i] ?? 0 })),
          }],
        };

      case "line":
      case "area":
        return {
          ...common,
          xAxis: { type: "category", data: x, boundaryGap: false, axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme) },
          yAxis: { type: "value", axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme), splitLine: { lineStyle: { color: theme.border, opacity: 0.4 } } },
          series: [{
            type: "line", data: y, smooth: true, symbolSize: 6,
            areaStyle: type === "area" ? { opacity: 0.18 } : undefined,
            lineStyle: { width: 2.5 },
          }],
        };

      case "scatter":
        return {
          ...common,
          xAxis: { type: "value", name: spec.x_label || "", nameTextStyle: { color: theme.textMuted }, axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme), splitLine: { lineStyle: { color: theme.border, opacity: 0.4 } } },
          yAxis: { type: "value", name: spec.y_label || "", nameTextStyle: { color: theme.textMuted }, axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme), splitLine: { lineStyle: { color: theme.border, opacity: 0.4 } } },
          series: [{ type: "scatter", symbolSize: 9, data: x.map((xv, i) => [xv, y[i]]) }],
        };

      case "histogram":
        return {
          ...common,
          xAxis: { type: "category", data: x, axisLine: { lineStyle: { color: theme.border } }, axisLabel: { ...baseAxisTextStyle(theme), rotate: x.length > 8 ? 30 : 0 } },
          yAxis: { type: "value", axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme), splitLine: { lineStyle: { color: theme.border, opacity: 0.4 } } },
          series: [{ type: "bar", data: y, barCategoryGap: "5%", itemStyle: { borderRadius: [3, 3, 0, 0] } }],
        };

      case "bar":
      default:
        return {
          ...common,
          xAxis: { type: "category", data: x, axisLine: { lineStyle: { color: theme.border } }, axisLabel: { ...baseAxisTextStyle(theme), rotate: x.length > 8 ? 30 : 0 } },
          yAxis: { type: "value", axisLine: { lineStyle: { color: theme.border } }, axisLabel: baseAxisTextStyle(theme), splitLine: { lineStyle: { color: theme.border, opacity: 0.4 } } },
          series: [{ type: "bar", data: y, barMaxWidth: 40, itemStyle: { borderRadius: [4, 4, 0, 0] } }],
        };
    }
  }

  // ── Download helpers ─────────────────────────────────────────────────────
  function triggerDownload(href, filename) {
    const a = document.createElement("a");
    a.href = href;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function safeFilename(title) {
    return (title || "chart").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || "chart";
  }

  function downloadPNG(chart, spec) {
    const url = chart.getDataURL({ type: "png", pixelRatio: 2, backgroundColor: "#ffffff00" });
    triggerDownload(url, `${safeFilename(spec.title)}.png`);
  }

  function downloadSVG(spec, theme, width, height) {
    // Render a one-off SVG-renderer instance off-screen purely to export —
    // the visible chart keeps using the faster canvas renderer.
    const host = document.createElement("div");
    host.style.width = width + "px";
    host.style.height = height + "px";
    host.style.position = "fixed";
    host.style.left = "-9999px";
    document.body.appendChild(host);
    const svgChart = window.echarts.init(host, null, { renderer: "svg", width, height });
    svgChart.setOption(buildOption(spec, theme));
    try {
      const svgStr = svgChart.renderToSVGString ? svgChart.renderToSVGString() : null;
      if (svgStr) {
        const blob = new Blob([svgStr], { type: "image/svg+xml" });
        const url = URL.createObjectURL(blob);
        triggerDownload(url, `${safeFilename(spec.title)}.svg`);
        setTimeout(() => URL.revokeObjectURL(url), 2000);
      } else {
        const url = svgChart.getDataURL({ type: "svg" });
        triggerDownload(url, `${safeFilename(spec.title)}.svg`);
      }
    } finally {
      svgChart.dispose();
      host.remove();
    }
  }

  // IMPROVED PDF export: now includes (1) the AI's text response for this
  // message, (2) the chart image, and (3) the AI-generated insights —
  // stacked on the page(s) in that order, paginating automatically if the
  // content doesn't fit on one page. `answerText` is optional so any older
  // caller that still calls downloadPDF(chart, spec) keeps working exactly
  // as before (it just gets a PDF without the AI-response section).
  async function downloadPDF(chart, spec, answerText) {
    if (!window.jspdf || !window.jspdf.jsPDF) {
      console.warn("[chart.js] jsPDF not available — cannot export PDF.");
      return;
    }
    const { jsPDF } = window.jspdf;
    const pngUrl = chart.getDataURL({ type: "png", pixelRatio: 2, backgroundColor: "#ffffff" });
    const img = new Image();
    await new Promise((resolve) => { img.onload = resolve; img.src = pngUrl; });

    const orientation = img.width >= img.height ? "landscape" : "portrait";
    const doc = new jsPDF({ orientation, unit: "pt", format: "a4" });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 36;
    const maxW = pageW - margin * 2;
    let y = margin;

    const ensureSpace = (needed) => {
      if (y + needed > pageH - margin) { doc.addPage(); y = margin; }
    };
    const writeParagraph = (text, fontSize, lineHeight, color) => {
      doc.setFontSize(fontSize);
      if (color !== undefined) doc.setTextColor(color);
      const lines = doc.splitTextToSize(String(text), maxW);
      for (const line of lines) {
        ensureSpace(lineHeight);
        doc.text(line, margin, y);
        y += lineHeight;
      }
      if (color !== undefined) doc.setTextColor(0);
    };

    // Title
    doc.setFontSize(16);
    doc.text(spec.title || "Chart", margin, y);
    y += 22;

    // 1) AI response text
    if (answerText) {
      writeParagraph("AI Response", 11, 15);
      writeParagraph(answerText, 9.5, 12, 90);
      y += 8;
    }

    // 2) Chart image
    const maxH = pageH - margin * 2;
    const ratio = Math.min(maxW / img.width, maxH / img.height);
    const w = img.width * ratio;
    const h = img.height * ratio;
    ensureSpace(h + 10);
    doc.addImage(pngUrl, "PNG", margin, y, w, h);
    y += h + 18;

    if (spec.explanation) {
      writeParagraph(spec.explanation, 9.5, 12, 90);
      y += 4;
    }

    // 3) AI-generated insights
    const insights = spec.insights || {};
    const bullets = [];
    if (insights.highest) bullets.push(`Highest: ${insights.highest.label} (${insights.highest.value})`);
    if (insights.lowest) bullets.push(`Lowest: ${insights.lowest.label} (${insights.lowest.value})`);
    if (insights.trend) bullets.push(`Trend: ${insights.trend}`);
    if (insights.outliers && insights.outliers.length) {
      bullets.push(`Outliers: ${insights.outliers.map(o => o.label).join(", ")}`);
    }
    if (bullets.length || spec.summary) {
      writeParagraph("AI-Generated Insights", 11, 15);
      for (const b of bullets) writeParagraph("• " + b, 9.5, 12);
      if (spec.summary) { y += 2; writeParagraph(spec.summary, 9.5, 12); }
    }

    doc.save(`${safeFilename(spec.title)}.pdf`);
  }

  function downloadCSV(spec) {
    const xLabel = spec.x_label || "Label";
    const yLabel = spec.y_label || "Value";
    const rows = [[xLabel, yLabel]];
    (spec.x || []).forEach((xv, i) => rows.push([xv, (spec.y || [])[i]]));
    const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    triggerDownload(url, `${safeFilename(spec.title)}.csv`);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  // Renders the structured "insights" object (highest/lowest/trend/outliers)
  // as a small bullet list beneath the chart, in addition to the existing
  // free-text summary/explanation. Returns "" when there's nothing to show.
  function buildInsightsHtml(spec) {
    const insights = spec.insights || {};
    const items = [];
    if (insights.highest) {
      items.push(`<li><span class="ai-chart-insight-label">Highest</span> ${escapeHtml(String(insights.highest.label))} (${escapeHtml(String(insights.highest.value))})</li>`);
    }
    if (insights.lowest) {
      items.push(`<li><span class="ai-chart-insight-label">Lowest</span> ${escapeHtml(String(insights.lowest.label))} (${escapeHtml(String(insights.lowest.value))})</li>`);
    }
    if (insights.trend) {
      items.push(`<li><span class="ai-chart-insight-label">Trend</span> ${escapeHtml(insights.trend)}</li>`);
    }
    if (insights.outliers && insights.outliers.length) {
      items.push(`<li><span class="ai-chart-insight-label">Outliers</span> ${escapeHtml(insights.outliers.map(o => o.label).join(", "))}</li>`);
    }
    if (!items.length) return "";
    return `<div class="ai-chart-insights">
      <div class="ai-chart-insights-title">Insights</div>
      <ul class="ai-chart-insights-list">${items.join("")}</ul>
    </div>`;
  }

  // Toggles native browser Fullscreen mode on the whole card (chart +
  // summary + actions), so the person still sees insights/downloads while
  // the chart itself gets much more room. Actual resize + class toggling on
  // enter/exit happens via the "fullscreenchange" listener registered once
  // in ensureChart() below (kept in the instance registry so disposeAll()
  // can always remove it — no leaked listeners, no orphaned fullscreen state).
  function toggleFullscreen(card) {
    if (document.fullscreenElement === card) {
      if (document.exitFullscreen) document.exitFullscreen();
    } else if (card.requestFullscreen) {
      card.requestFullscreen();
    }
  }

  // ── Public: build the full chart card (chart + summary + downloads) ─────
  // Returns a DOM element ready to be appended into a chat message.
  // `answerText` (optional) is the AI's text answer for this message — used
  // only by the PDF export so it can include the AI response alongside the
  // chart and insights. Omitting it keeps everything working as before.
  function buildCard(spec, answerText) {
    const card = document.createElement("div");
    card.className = "ai-chart-card";

    if (spec.type === "chart_error") {
      card.classList.add("ai-chart-card-error");
      card.innerHTML = `<div class="ai-chart-error-msg">${escapeHtml(spec.message || "Not enough structured data is available to generate this chart.")}</div>`;
      return card;
    }

    // Header
    const header = document.createElement("div");
    header.className = "ai-chart-header";
    header.innerHTML = `<span class="ai-chart-title">${escapeHtml(spec.title || "Chart")}</span>
      <span class="ai-chart-type-tag">${escapeHtml((spec.chart_type || "").replace("_", " "))}</span>`;
    card.appendChild(header);

    // Chart canvas container (lazy init via IntersectionObserver so charts
    // off-screen in a long chat history don't all initialize at once).
    const chartHost = document.createElement("div");
    chartHost.className = "ai-chart-canvas";
    card.appendChild(chartHost);

    // Summary + AI-generated insights (highest/lowest/trend/outliers/summary)
    const insightsHtml = buildInsightsHtml(spec);
    if (spec.explanation || spec.summary || insightsHtml) {
      const summary = document.createElement("div");
      summary.className = "ai-chart-summary";
      const bits = [];
      if (spec.explanation) bits.push(`<p class="ai-chart-explanation">${escapeHtml(spec.explanation)}</p>`);
      if (insightsHtml) bits.push(insightsHtml);
      if (spec.summary) bits.push(`<p class="ai-chart-summary-text">${escapeHtml(spec.summary)}</p>`);
      summary.innerHTML = bits.join("");
      card.appendChild(summary);
    }

    // Download options + fullscreen
    const actions = document.createElement("div");
    actions.className = "ai-chart-actions";
    actions.innerHTML = `
      <button type="button" class="ai-chart-btn" data-act="png">PNG</button>
      <button type="button" class="ai-chart-btn" data-act="svg">SVG</button>
      <button type="button" class="ai-chart-btn" data-act="pdf">PDF</button>
      <button type="button" class="ai-chart-btn" data-act="csv">CSV</button>
      <button type="button" class="ai-chart-btn" data-act="fullscreen" title="Toggle fullscreen">Fullscreen</button>
    `;
    card.appendChild(actions);

    let chartInstance = null;

    function ensureChart() {
      if (chartInstance) return chartInstance;
      const theme = readTheme();
      chartInstance = window.echarts.init(chartHost, null, { renderer: "canvas" });
      chartInstance.setOption(buildOption(spec, theme));

      const resizeHandler = () => { try { chartInstance.resize(); } catch (e) { /* ignore */ } };
      window.addEventListener("resize", resizeHandler);

      let observer = null;
      if (window.ResizeObserver) {
        observer = new ResizeObserver(resizeHandler);
        observer.observe(chartHost);
      }

      // Fullscreen: toggle a layout class + resize the chart on enter/exit so
      // it fills (or un-fills) the viewport responsively. Registered once per
      // card and stored in the instance registry so disposeAll() always
      // removes it — no leaked listeners, no stuck fullscreen state even if
      // the card is torn down (e.g. renderChat() rebuild) while fullscreen.
      const fsHandler = () => {
        const isFs = document.fullscreenElement === card;
        card.classList.toggle("ai-chart-fullscreen", isFs);
        requestAnimationFrame(() => { try { chartInstance.resize(); } catch (e) { /* ignore */ } });
      };
      document.addEventListener("fullscreenchange", fsHandler);

      _instances.set(chartHost, { chart: chartInstance, resizeHandler, observer, fsHandler });
      return chartInstance;
    }

    // Initialize once the card is actually in the DOM/visible. A microtask
    // delay is enough here since app.js appends synchronously; ECharts also
    // needs the container to have a measurable size (CSS gives it a fixed
    // min-height so this is safe even at 0 scroll offset).
    requestAnimationFrame(() => ensureChart());

    actions.addEventListener("click", async (e) => {
      const btn = e.target.closest(".ai-chart-btn");
      if (!btn) return;
      const act = btn.dataset.act;
      const chart = ensureChart();
      const theme = readTheme();
      const rect = chartHost.getBoundingClientRect();
      btn.disabled = true;
      try {
        if (act === "png") downloadPNG(chart, spec);
        else if (act === "svg") downloadSVG(spec, theme, Math.max(rect.width, 400), Math.max(rect.height, 300));
        else if (act === "pdf") await downloadPDF(chart, spec, answerText);
        else if (act === "csv") downloadCSV(spec);
        else if (act === "fullscreen") { toggleFullscreen(card); return; }
      } catch (err) {
        console.error("[chart.js] download failed:", err);
      } finally {
        btn.disabled = false;
      }
    });

    return card;
  }

  function escapeHtml(str) {
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  window.AIChart = { disposeAll, buildCard };
})();
