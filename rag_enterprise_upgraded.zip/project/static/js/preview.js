/* ============================================================
   Document Preview — frontend module
   Vanilla JS, no build step, no external CDNs (intranet-safe).
   Talks only to the new, additive /preview/* endpoints.
   Exposes: window.DocPreview.open(docName)
   ============================================================ */

(() => {
  "use strict";

  const API = "";
  const MAX_CACHE_ENTRIES = 60;

  // ───────────────────────── tiny cache (LRU-ish by insertion order) ─────────────────────────
  const cache = new Map();
  function cacheGet(key) { return cache.has(key) ? cache.get(key) : undefined; }
  function cacheSet(key, val) {
    if (cache.size >= MAX_CACHE_ENTRIES) {
      const oldestKey = cache.keys().next().value;
      const oldest = cache.get(oldestKey);
      if (oldest && oldest.__blobUrl) URL.revokeObjectURL(oldest.__blobUrl);
      cache.delete(oldestKey);
    }
    cache.set(key, val);
  }

  function $(sel, root = document) { return root.querySelector(sel); }

  async function fetchJson(path) {
    const res = await fetch(API + path);
    let body = null;
    try { body = await res.json(); } catch { /* not json */ }
    if (!res.ok) throw new Error((body && body.detail) || `HTTP ${res.status}`);
    return body;
  }

  async function fetchBlobUrl(path) {
    const res = await fetch(API + path);
    if (!res.ok) {
      let detail = `HTTP ${res.status}`;
      try { const b = await res.json(); if (b?.detail) detail = b.detail; } catch { /* ignore */ }
      throw new Error(detail);
    }
    const blob = await res.blob();
    return URL.createObjectURL(blob);
  }

  const ICONS = {
    pdf: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`,
    docx: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/></svg>`,
    excel: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="9" y1="10" x2="9" y2="20"/></svg>`,
    image: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></svg>`,
    file: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`,
    close: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    zoomIn: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>`,
    zoomOut: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/></svg>`,
    fitWidth: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8V5a1 1 0 0 1 1-1h3"/><path d="M17 4h3a1 1 0 0 1 1 1v3"/><path d="M21 16v3a1 1 0 0 1-1 1h-3"/><path d="M7 20H4a1 1 0 0 1-1-1v-3"/></svg>`,
    reset: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>`,
    prev: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`,
    next: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`,
    download: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    warn: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 9v4M12 17h.01M10.29 3.86l-8.18 14.14A2 2 0 0 0 3.93 21h16.14a2 2 0 0 0 1.82-2.99L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>`,
  };

  // ───────────────────────── DOM scaffold (built once) ─────────────────────────
  let els = null;
  let currentDoc = null;   // docName
  let currentKind = null;
  let pdfState = null;     // {page, totalPages, dpi, zoom, fitWidth}
  let excelState = null;   // {sheets, activeSheet}
  let imgState = null;     // {scale, tx, ty, naturalW, naturalH}
  let escHandlerBound = false;

  function ensureDom() {
    if (els) return els;

    const overlay = document.createElement("div");
    overlay.className = "dp-overlay";
    overlay.innerHTML = `
      <div class="dp-panel" role="dialog" aria-modal="true" aria-label="Document preview">
        <div class="dp-header">
          <div class="dp-header-icon" id="dp-header-icon">${ICONS.file}</div>
          <div class="dp-header-text">
            <div class="dp-title" id="dp-title">Document</div>
            <div class="dp-subtitle" id="dp-subtitle">&nbsp;</div>
          </div>
          <div class="dp-header-actions">
            <button class="dp-icon-btn" id="dp-download-header" title="Download original file">${ICONS.download}</button>
            <button class="dp-icon-btn dp-close-btn" id="dp-close-btn" title="Close preview (Esc)">${ICONS.close}</button>
          </div>
        </div>
        <div class="dp-toolbar" id="dp-toolbar" hidden></div>
        <div class="dp-body" id="dp-body"></div>
      </div>
    `;
    document.body.appendChild(overlay);

    els = {
      overlay,
      headerIcon: $("#dp-header-icon", overlay),
      title: $("#dp-title", overlay),
      subtitle: $("#dp-subtitle", overlay),
      downloadHeaderBtn: $("#dp-download-header", overlay),
      closeBtn: $("#dp-close-btn", overlay),
      toolbar: $("#dp-toolbar", overlay),
      body: $("#dp-body", overlay),
    };

    els.closeBtn.addEventListener("click", close);
    overlay.addEventListener("mousedown", (e) => { if (e.target === overlay) close(); });
    els.downloadHeaderBtn.addEventListener("click", () => downloadCurrent());

    if (!escHandlerBound) {
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && els.overlay.classList.contains("is-open")) close();
      });
      escHandlerBound = true;
    }

    return els;
  }

  function downloadCurrent() {
    if (!currentDoc) return;
    const a = document.createElement("a");
    a.href = `${API}/preview/${encodeURIComponent(currentDoc)}/file?download=true`;
    a.download = currentDoc;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function setLoading(message) {
    els.body.innerHTML = `
      <div class="dp-loading">
        <div class="dp-spinner"></div>
        <div>${message || "Preparing preview…"}</div>
      </div>`;
  }

  function setMessage({ title, sub, showDownload }) {
    els.body.innerHTML = `
      <div class="dp-message">
        <div class="dp-message-icon">${ICONS.warn}</div>
        <div class="dp-message-title">${escapeHtml(title)}</div>
        ${sub ? `<div class="dp-message-sub">${escapeHtml(sub)}</div>` : ""}
        ${showDownload ? `<button class="dp-download-btn" id="dp-fallback-download">${ICONS.download} Download file</button>` : ""}
      </div>`;
    if (showDownload) {
      $("#dp-fallback-download", els.body).addEventListener("click", downloadCurrent);
    }
  }

  function escapeHtml(str) {
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function clearToolbar() {
    els.toolbar.innerHTML = "";
    els.toolbar.hidden = true;
  }

  // ───────────────────────── open / close ─────────────────────────

  async function open(docName) {
    ensureDom();
    currentDoc = docName;
    currentKind = null;
    pdfState = null;
    excelState = null;
    imgState = null;

    els.title.textContent = docName;
    els.subtitle.textContent = "Loading preview…";
    els.headerIcon.innerHTML = ICONS.file;
    els.downloadHeaderBtn.disabled = true;
    clearToolbar();
    setLoading("Preparing preview…");

    requestAnimationFrame(() => els.overlay.classList.add("is-open"));
    document.body.style.overflow = "hidden";

    try {
      const metaKey = `meta|${docName}`;
      let meta = cacheGet(metaKey);
      if (!meta) {
        meta = await fetchJson(`/preview/${encodeURIComponent(docName)}/meta`);
        cacheSet(metaKey, meta);
      }

      if (currentDoc !== docName) return; // user opened something else while this was loading

      els.downloadHeaderBtn.disabled = !meta.download_available;

      if (!meta.supported) {
        currentKind = null;
        els.subtitle.textContent = "Preview not supported";
        setMessage({
          title: "Preview is not available for this file type.",
          sub: meta.download_available
            ? "You can still download the original file below."
            : "The original file is not available to download either.",
          showDownload: meta.download_available,
        });
        return;
      }

      if (!meta.available) {
        currentKind = meta.kind;
        els.subtitle.textContent = "Preview unavailable";
        setMessage({
          title: "Preview is not available for this document.",
          sub: meta.error || "The original file could not be located (it may have been uploaded before preview support was added).",
          showDownload: meta.download_available,
        });
        return;
      }

      currentKind = meta.kind;
      els.headerIcon.innerHTML = ICONS[meta.kind] || ICONS.file;

      if (meta.kind === "pdf") await openPdf(docName, meta);
      else if (meta.kind === "docx") await openDocx(docName, meta);
      else if (meta.kind === "excel") await openExcel(docName, meta);
      else if (meta.kind === "image") openImage(docName, meta);
      else setMessage({ title: "Preview is not available for this file type.", showDownload: meta.download_available });

    } catch (e) {
      if (currentDoc !== docName) return;
      els.subtitle.textContent = "Preview failed";
      setMessage({
        title: "This document could not be previewed.",
        sub: e.message || "An unexpected error occurred while preparing the preview.",
        showDownload: true,
      });
    }
  }

  function close() {
    els.overlay.classList.remove("is-open");
    document.body.style.overflow = "";
    currentDoc = null;
    currentKind = null;
    // Panel content is cleared on next open(); no need to tear down here,
    // which keeps close/reopen of the same doc instant if still cached.
  }

  // ───────────────────────── PDF viewer ─────────────────────────

  async function openPdf(docName, meta) {
    pdfState = { page: 1, totalPages: meta.page_count || 1, dpi: 150, zoom: 1, fitWidth: true };
    els.subtitle.textContent = `PDF · ${pdfState.totalPages} page${pdfState.totalPages !== 1 ? "s" : ""}`;
    buildPdfToolbar();
    els.body.innerHTML = `<div class="dp-pdf-scroll" id="dp-pdf-scroll"><div class="dp-pdf-page-wrap"><img class="dp-pdf-page" id="dp-pdf-img" alt="PDF page"/></div></div>`;
    await renderPdfPage();
  }

  function buildPdfToolbar() {
    els.toolbar.hidden = false;
    els.toolbar.innerHTML = `
      <div class="dp-toolbar-group">
        <button class="dp-icon-btn" id="dp-pdf-prev" title="Previous page">${ICONS.prev}</button>
        <span class="dp-page-indicator">
          <input type="number" class="dp-page-input" id="dp-pdf-page-input" min="1" value="1"/> / <span id="dp-pdf-total"></span>
        </span>
        <button class="dp-icon-btn" id="dp-pdf-next" title="Next page">${ICONS.next}</button>
      </div>
      <div class="dp-toolbar-sep"></div>
      <div class="dp-toolbar-group">
        <button class="dp-icon-btn" id="dp-pdf-zoom-out" title="Zoom out">${ICONS.zoomOut}</button>
        <span class="dp-zoom-level" id="dp-pdf-zoom-level">100%</span>
        <button class="dp-icon-btn" id="dp-pdf-zoom-in" title="Zoom in">${ICONS.zoomIn}</button>
        <button class="dp-icon-btn" id="dp-pdf-fit-width" title="Fit to width">${ICONS.fitWidth}</button>
      </div>
    `;
    $("#dp-pdf-total", els.toolbar).textContent = pdfState.totalPages;
    $("#dp-pdf-page-input", els.toolbar).value = pdfState.page;

    $("#dp-pdf-prev", els.toolbar).addEventListener("click", () => gotoPdfPage(pdfState.page - 1));
    $("#dp-pdf-next", els.toolbar).addEventListener("click", () => gotoPdfPage(pdfState.page + 1));
    $("#dp-pdf-page-input", els.toolbar).addEventListener("change", (e) => gotoPdfPage(parseInt(e.target.value, 10) || 1));
    $("#dp-pdf-zoom-in", els.toolbar).addEventListener("click", () => setPdfZoom(pdfState.zoom + 0.15, false));
    $("#dp-pdf-zoom-out", els.toolbar).addEventListener("click", () => setPdfZoom(pdfState.zoom - 0.15, false));
    $("#dp-pdf-fit-width", els.toolbar).addEventListener("click", () => setPdfZoom(null, true));
  }

  function gotoPdfPage(n) {
    n = Math.max(1, Math.min(pdfState.totalPages, n));
    if (n === pdfState.page) return;
    pdfState.page = n;
    $("#dp-pdf-page-input", els.toolbar).value = n;
    renderPdfPage();
  }

  function setPdfZoom(zoom, fitWidth) {
    pdfState.fitWidth = !!fitWidth;
    if (zoom != null) pdfState.zoom = Math.max(0.3, Math.min(3, zoom));
    applyPdfZoom();
  }

  function applyPdfZoom() {
    const img = $("#dp-pdf-img", els.body);
    const scroll = $("#dp-pdf-scroll", els.body);
    if (!img || !img.naturalWidth) return;
    let widthPx;
    if (pdfState.fitWidth) {
      widthPx = scroll.clientWidth - 48; // account for padding
      pdfState.zoom = widthPx / img.naturalWidth;
    } else {
      widthPx = img.naturalWidth * pdfState.zoom;
    }
    img.style.width = `${widthPx}px`;
    const zoomLevelEl = $("#dp-pdf-zoom-level", els.toolbar);
    if (zoomLevelEl) zoomLevelEl.textContent = `${Math.round(pdfState.zoom * 100)}%`;
  }

  async function renderPdfPage() {
    const requestedDoc = currentDoc, requestedPage = pdfState.page;
    setLoading(`Rendering page ${pdfState.page}…`);
    const key = `pdf|${currentDoc}|${pdfState.page}|${pdfState.dpi}`;
    try {
      let cached = cacheGet(key);
      let url;
      if (!cached) {
        url = await fetchBlobUrl(`/preview/${encodeURIComponent(currentDoc)}/pdf/page/${pdfState.page}?dpi=${pdfState.dpi}`);
        cacheSet(key, { __blobUrl: url });
      } else {
        url = cached.__blobUrl;
      }
      if (currentDoc !== requestedDoc || pdfState.page !== requestedPage) return;

      els.body.innerHTML = `<div class="dp-pdf-scroll" id="dp-pdf-scroll"><div class="dp-pdf-page-wrap"><img class="dp-pdf-page" id="dp-pdf-img" alt="PDF page ${pdfState.page}"/></div></div>`;
      const img = $("#dp-pdf-img", els.body);
      img.onload = () => applyPdfZoom();
      img.src = url;
    } catch (e) {
      if (currentDoc !== requestedDoc) return;
      setMessage({ title: "This page could not be rendered.", sub: e.message, showDownload: true });
    }
  }

  // ───────────────────────── DOCX viewer ─────────────────────────

  async function openDocx(docName, meta) {
    els.subtitle.textContent = "Word document · read-only";
    setLoading("Rendering document…");
    const key = `docx|${docName}`;
    try {
      let data = cacheGet(key);
      if (!data) {
        data = await fetchJson(`/preview/${encodeURIComponent(docName)}/docx/html`);
        cacheSet(key, data);
      }
      if (currentDoc !== docName) return;
      els.body.innerHTML = `<div class="dp-docx-scroll"><div class="dp-docx-page">${data.html}</div></div>`;
    } catch (e) {
      if (currentDoc !== docName) return;
      setMessage({ title: "This document could not be rendered.", sub: e.message, showDownload: true });
    }
  }

  // ───────────────────────── Excel viewer ─────────────────────────

  async function openExcel(docName, meta) {
    const sheets = meta.sheets || [];
    excelState = { sheets, activeSheet: sheets[0] || null };
    els.subtitle.textContent = `Workbook · ${sheets.length} sheet${sheets.length !== 1 ? "s" : ""}`;
    buildExcelToolbar();
    if (excelState.activeSheet) await renderExcelSheet(docName, excelState.activeSheet);
    else setMessage({ title: "This workbook has no sheets to preview." });
  }

  function buildExcelToolbar() {
    els.toolbar.hidden = false;
    els.toolbar.innerHTML = `<div class="dp-sheet-tabs" id="dp-sheet-tabs"></div>`;
    const tabs = $("#dp-sheet-tabs", els.toolbar);
    excelState.sheets.forEach((name) => {
      const tab = document.createElement("button");
      tab.className = "dp-sheet-tab" + (name === excelState.activeSheet ? " is-active" : "");
      tab.textContent = name;
      tab.addEventListener("click", () => {
        if (excelState.activeSheet === name) return;
        excelState.activeSheet = name;
        [...tabs.children].forEach((c) => c.classList.toggle("is-active", c === tab));
        renderExcelSheet(currentDoc, name);
      });
      tabs.appendChild(tab);
    });
  }

  async function renderExcelSheet(docName, sheetName) {
    const requestedDoc = docName;
    setLoading(`Loading sheet "${sheetName}"…`);
    const key = `excel|${docName}|${sheetName}`;
    try {
      let data = cacheGet(key);
      if (!data) {
        data = await fetchJson(`/preview/${encodeURIComponent(docName)}/excel/sheets/${encodeURIComponent(sheetName)}`);
        cacheSet(key, data);
      }
      if (currentDoc !== requestedDoc || excelState.activeSheet !== sheetName) return;

      const headHtml = `<tr>${data.columns.map((c) => `<th>${escapeHtml(c)}</th>`).join("")}</tr>`;
      const bodyHtml = data.rows.map((row) => `<tr>${row.map((v) => `<td>${escapeHtml(v)}</td>`).join("")}</tr>`).join("");
      const note = data.truncated
        ? `<div class="dp-excel-note">Showing the first ${data.rows.length.toLocaleString()} of ${data.total_rows.toLocaleString()} rows for performance.</div>`
        : "";

      els.body.innerHTML = `
        ${note}
        <div class="dp-excel-wrap">
          <table class="dp-excel-table">
            <thead>${headHtml}</thead>
            <tbody>${bodyHtml}</tbody>
          </table>
        </div>`;
    } catch (e) {
      if (currentDoc !== requestedDoc) return;
      setMessage({ title: "This sheet could not be loaded.", sub: e.message, showDownload: true });
    }
  }

  // ───────────────────────── Image viewer ─────────────────────────

  function openImage(docName, meta) {
    els.subtitle.textContent = "Image";
    buildImageToolbar();
    els.body.innerHTML = `<div class="dp-image-wrap" id="dp-image-wrap"><img class="dp-image-el" id="dp-image-el" alt="${escapeHtml(docName)}"/></div>`;
    const wrap = $("#dp-image-wrap", els.body);
    const img = $("#dp-image-el", els.body);

    imgState = { scale: 1, tx: 0, ty: 0, naturalW: 0, naturalH: 0 };

    img.onload = () => {
      imgState.naturalW = img.naturalWidth;
      imgState.naturalH = img.naturalHeight;
      fitImageToScreen();
    };
    img.src = `${API}/preview/${encodeURIComponent(docName)}/file`;

    let dragging = false, startX = 0, startY = 0, startTx = 0, startTy = 0;
    wrap.addEventListener("mousedown", (e) => {
      dragging = true; wrap.classList.add("is-panning");
      startX = e.clientX; startY = e.clientY; startTx = imgState.tx; startTy = imgState.ty;
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      imgState.tx = startTx + (e.clientX - startX);
      imgState.ty = startTy + (e.clientY - startY);
      applyImageTransform();
    });
    window.addEventListener("mouseup", () => { dragging = false; wrap.classList.remove("is-panning"); });
    wrap.addEventListener("wheel", (e) => {
      e.preventDefault();
      const delta = e.deltaY < 0 ? 0.12 : -0.12;
      setImageScale(imgState.scale + delta);
    }, { passive: false });
  }

  function buildImageToolbar() {
    els.toolbar.hidden = false;
    els.toolbar.innerHTML = `
      <div class="dp-toolbar-group">
        <button class="dp-icon-btn" id="dp-img-zoom-out" title="Zoom out">${ICONS.zoomOut}</button>
        <span class="dp-zoom-level" id="dp-img-zoom-level">100%</span>
        <button class="dp-icon-btn" id="dp-img-zoom-in" title="Zoom in">${ICONS.zoomIn}</button>
      </div>
      <div class="dp-toolbar-sep"></div>
      <div class="dp-toolbar-group">
        <button class="dp-icon-btn" id="dp-img-fit" title="Fit to screen">${ICONS.fitWidth}</button>
        <button class="dp-icon-btn" id="dp-img-reset" title="Reset zoom">${ICONS.reset}</button>
      </div>
    `;
    $("#dp-img-zoom-in", els.toolbar).addEventListener("click", () => setImageScale(imgState.scale + 0.15));
    $("#dp-img-zoom-out", els.toolbar).addEventListener("click", () => setImageScale(imgState.scale - 0.15));
    $("#dp-img-fit", els.toolbar).addEventListener("click", fitImageToScreen);
    $("#dp-img-reset", els.toolbar).addEventListener("click", resetImageZoom);
  }

  function setImageScale(scale) {
    imgState.scale = Math.max(0.1, Math.min(6, scale));
    applyImageTransform();
  }

  function fitImageToScreen() {
    const wrap = $("#dp-image-wrap", els.body);
    if (!wrap || !imgState.naturalW) return;
    const availW = wrap.clientWidth - 32, availH = wrap.clientHeight - 32;
    imgState.scale = Math.min(availW / imgState.naturalW, availH / imgState.naturalH, 1);
    imgState.tx = 0; imgState.ty = 0;
    applyImageTransform();
  }

  function resetImageZoom() {
    imgState.scale = 1; imgState.tx = 0; imgState.ty = 0;
    applyImageTransform();
  }

  function applyImageTransform() {
    const img = $("#dp-image-el", els.body);
    if (!img) return;
    img.style.width = `${imgState.naturalW}px`;
    img.style.height = `${imgState.naturalH}px`;
    img.style.transform = `translate(${imgState.tx}px, ${imgState.ty}px) scale(${imgState.scale})`;
    const zoomLevelEl = $("#dp-img-zoom-level", els.toolbar);
    if (zoomLevelEl) zoomLevelEl.textContent = `${Math.round(imgState.scale * 100)}%`;
  }

  // Re-fit fit-to-width / fit-to-screen content on desktop window resize.
  window.addEventListener("resize", () => {
    if (!els || !els.overlay.classList.contains("is-open")) return;
    if (currentKind === "pdf" && pdfState && pdfState.fitWidth) applyPdfZoom();
    if (currentKind === "image" && imgState) fitImageToScreen();
  });

  window.DocPreview = { open, close };
})();
