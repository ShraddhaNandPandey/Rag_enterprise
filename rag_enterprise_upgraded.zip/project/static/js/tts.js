/* ============================================================
   tts.js — Read Aloud (offline Text-to-Speech) widget
   ------------------------------------------------------------
   Fully self-contained. Does NOT modify app.js / the existing chat
   logic in any way. Instead it watches #chat-log with a
   MutationObserver and attaches a speaker button to every assistant
   message's action row as soon as app.js renders it — the same
   pattern any "add-on" browser extension would use, so the existing
   RAG pipeline, chat logic, and business logic files stay untouched.

   Talks only to the new, additive backend endpoints:
     POST   /api/tts
     GET    /api/tts/status
   Never calls any external/cloud service — everything is same-origin.
   ============================================================ */

(() => {
  "use strict";

  const API_BASE = ""; // same-origin, mirrors app.js's API constant
  const SPEEDS = [0.75, 1, 1.25, 1.5];
  const LS_SPEED_KEY = "tts:lastSpeed";
  const LS_VOLUME_KEY = "tts:lastVolume";
  const MAX_MEMORY_CACHE = 24; // in-memory blob-URL cache entries this tab keeps

  const state = {
    availability: null,     // null = unknown, true/false once /api/tts/status resolves
    engineName: "",
    memoryCache: new Map(), // textHash -> objectURL (this browser tab only)
    memoryCacheOrder: [],
    current: null,          // playback state for the message currently loaded/playing
  };

  // ───────────────────────── icons ─────────────────────────

  const ICON = {
    speaker: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.5 8.5a5 5 0 0 1 0 7"></path><path d="M18.5 5.5a9 9 0 0 1 0 13"></path></svg>`,
    speakerOff: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>`,
    playing: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.5 8.5a5 5 0 0 1 0 7"></path><path d="M18.5 5.5a9 9 0 0 1 0 13"></path></svg>`,
    play: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="6 4 20 12 6 20 6 4"></polygon></svg>`,
    pause: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`,
    stop: `<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="5" y="5" width="14" height="14" rx="1.5"></rect></svg>`,
    replay: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>`,
    volume: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.5 8.5a5 5 0 0 1 0 7"></path></svg>`,
    volumeMute: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>`,
  };

  // ───────────────────────── helpers ─────────────────────────

  function $(sel, root = document) { return root.querySelector(sel); }

  function toast(message, type = "info") {
    // Reuse the host app's toast stack if present, so notifications look
    // native instead of introducing a second notification style.
    const stack = document.getElementById("toast-stack");
    if (!stack) return;
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.textContent = message;
    stack.appendChild(el);
    setTimeout(() => el.remove(), 4500);
  }

  function formatDuration(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  // Fast, synchronous 32-bit hash (FNV-1a). Only used as a client-side cache
  // key / "is this the same message" check — the server has its own
  // cryptographic cache key, this one just needs to be stable and cheap.
  function hashText(text) {
    let h = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) {
      h ^= text.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(16);
  }

  // Linearize a rendered message bubble (which may contain <p>, <ul>, <table>,
  // <pre>, <br> from renderRichText in app.js) back into plain, readable text
  // for the TTS engine, without touching app.js itself.
  function extractSpeakableText(bubbleEl) {
    const clone = bubbleEl.cloneNode(true);
    clone.querySelectorAll("br").forEach((br) => br.replaceWith("\n"));
    clone.querySelectorAll("p, li, tr, pre, h1, h2, h3, h4").forEach((el) => {
      el.append("\n");
    });
    clone.querySelectorAll("td, th").forEach((el) => { el.append(". "); });
    const text = clone.textContent
      .replace(/[ \t]+/g, " ")
      .replace(/\n{2,}/g, "\n")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .join(". ")
      .replace(/\.\s*\./g, ".")
      .trim();
    return text;
  }

  // ───────────────────────── availability check ─────────────────────────

  async function checkAvailability() {
    try {
      const res = await fetch(API_BASE + "/api/tts/status");
      if (!res.ok) throw new Error("status " + res.status);
      const body = await res.json();
      state.availability = !!body.available;
      state.engineName = body.engine || "";
    } catch {
      state.availability = false;
    }
    reflectAvailabilityOnButtons();
  }

  function reflectAvailabilityOnButtons() {
    document.querySelectorAll(".tts-btn").forEach((btn) => {
      if (state.availability === false) {
        btn.classList.add("is-unavailable");
        btn.title = "Read Aloud engine is not available on this server";
        btn.setAttribute("aria-disabled", "true");
      } else {
        btn.classList.remove("is-unavailable");
        btn.title = "Read aloud";
        btn.removeAttribute("aria-disabled");
      }
    });
  }

  // ───────────────────────── memory (blob) cache ─────────────────────────

  function cacheGet(key) { return state.memoryCache.get(key) || null; }

  function cachePut(key, url) {
    state.memoryCache.set(key, url);
    state.memoryCacheOrder.push(key);
    while (state.memoryCacheOrder.length > MAX_MEMORY_CACHE) {
      const oldest = state.memoryCacheOrder.shift();
      const oldUrl = state.memoryCache.get(oldest);
      if (oldUrl && oldUrl !== url) URL.revokeObjectURL(oldUrl);
      state.memoryCache.delete(oldest);
    }
  }

  // ───────────────────────── DOM: attach buttons ─────────────────────────

  function attachButtons(root = document) {
    const rows = root.querySelectorAll(".msg.assistant .msg-actions:not([data-tts-ready])");
    rows.forEach((actions) => {
      actions.setAttribute("data-tts-ready", "1");

      const col = actions.parentElement;
      const bubble = col ? col.querySelector(".msg-bubble") : null;
      if (!bubble) return;

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "tts-btn";
      btn.title = "Read aloud";
      btn.setAttribute("aria-label", "Read this response aloud");
      btn.innerHTML = ICON.speaker;

      btn.addEventListener("click", () => onSpeakerClick(btn, bubble, col));

      // Insert right after the timestamp, before regenerate/copy — a stable,
      // predictable position matching where ChatGPT places its own control.
      const time = actions.querySelector(".msg-time");
      if (time && time.nextSibling) actions.insertBefore(btn, time.nextSibling);
      else actions.appendChild(btn);
    });

    reflectAvailabilityOnButtons();
    reconcileCurrentPlaybackUI();
  }

  // If the message currently playing got re-rendered (full re-render on any
  // chat state change), re-attach the "now playing" look to its new DOM node
  // instead of silently losing the indicator.
  function reconcileCurrentPlaybackUI() {
    const cur = state.current;
    if (!cur || !cur.audio) return;
    if (cur.buttonEl && document.contains(cur.buttonEl)) return; // still attached, fine

    const rows = document.querySelectorAll(".msg.assistant .msg-actions[data-tts-ready]");
    for (const actions of rows) {
      const col = actions.parentElement;
      const bubble = col ? col.querySelector(".msg-bubble") : null;
      if (!bubble) continue;
      if (hashText(extractSpeakableText(bubble)) === cur.key) {
        const btn = actions.querySelector(".tts-btn");
        cur.buttonEl = btn;
        cur.colEl = col;
        setButtonPlayingState(btn, !cur.audio.paused);
        mountPlayerBar(col, cur);
        return;
      }
    }
  }

  // ───────────────────────── click handling ─────────────────────────

  function onSpeakerClick(btn, bubbleEl, colEl) {
    if (state.availability === false) {
      toast("Read Aloud isn't available on this server (no offline TTS engine configured).", "error");
      return;
    }
    if (btn.disabled) return; // generating

    const text = extractSpeakableText(bubbleEl);
    if (!text) { toast("Nothing to read aloud.", "info"); return; }
    const key = hashText(text);

    if (state.current && state.current.key === key) {
      // Same message: toggle play/pause instead of restarting.
      togglePlayPause();
      return;
    }

    // A different message (or nothing) was playing — stop it first so only
    // one message ever plays at a time.
    stopPlayback();
    startPlayback(btn, bubbleEl, colEl, text, key);
  }

  async function startPlayback(btn, bubbleEl, colEl, text, key) {
    setButtonLoading(btn, true);

    let url = cacheGet(key);
    let fromCache = !!url;
    try {
      if (!url) {
        const res = await fetch(API_BASE + "/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        if (!res.ok) {
          let detail = "Audio generation failed.";
          try { detail = (await res.json()).detail || detail; } catch { /* ignore */ }
          throw new Error(detail);
        }
        const blob = await res.blob();
        url = URL.createObjectURL(blob);
        cachePut(key, url);
      }
    } catch (e) {
      setButtonLoading(btn, false);
      toast("Read Aloud failed: " + (e.message || "unknown error"), "error");
      return;
    }

    const audio = new Audio(url);
    audio.preload = "auto";
    const savedSpeed = parseFloat(localStorage.getItem(LS_SPEED_KEY) || "1") || 1;
    const savedVolume = parseFloat(localStorage.getItem(LS_VOLUME_KEY) || "1");
    audio.playbackRate = SPEEDS.includes(savedSpeed) ? savedSpeed : 1;
    audio.volume = isFinite(savedVolume) ? Math.min(1, Math.max(0, savedVolume)) : 1;

    state.current = {
      key, url, audio, text,
      buttonEl: btn, bubbleEl, colEl,
      speed: audio.playbackRate,
      fromCache,
    };

    mountPlayerBar(colEl, state.current);
    setButtonLoading(btn, false);
    setButtonPlayingState(btn, true);

    audio.addEventListener("ended", () => {
      setButtonPlayingState(btn, false);
      updatePlayerButtons(state.current, false);
    });
    audio.addEventListener("error", () => {
      toast("Playback error — the audio could not be played.", "error");
      stopPlayback();
    });

    try {
      await audio.play();
    } catch (e) {
      toast("Playback was blocked by the browser. Click play again.", "info");
      setButtonPlayingState(btn, false);
    }
  }

  function togglePlayPause() {
    const cur = state.current;
    if (!cur || !cur.audio) return;
    if (cur.audio.paused) {
      cur.audio.play();
      setButtonPlayingState(cur.buttonEl, true);
      updatePlayerButtons(cur, true);
    } else {
      cur.audio.pause();
      setButtonPlayingState(cur.buttonEl, false);
      updatePlayerButtons(cur, false);
    }
  }

  function stopPlayback() {
    const cur = state.current;
    if (!cur) return;
    try { cur.audio.pause(); cur.audio.currentTime = 0; } catch { /* ignore */ }
    if (cur.buttonEl) setButtonPlayingState(cur.buttonEl, false);
    if (cur.playerEl) cur.playerEl.remove();
    state.current = null;
  }

  // ───────────────────────── speaker button visual states ─────────────────────────

  function setButtonLoading(btn, loading) {
    btn.disabled = loading;
    btn.innerHTML = loading ? `<span class="tts-spinner" aria-hidden="true"></span>` : ICON.speaker;
    btn.setAttribute("aria-busy", loading ? "true" : "false");
    if (loading) btn.title = "Generating audio…";
  }

  function setButtonPlayingState(btn, playing) {
    if (!btn) return;
    btn.classList.toggle("is-playing", playing);
    btn.setAttribute("aria-pressed", playing ? "true" : "false");
    btn.innerHTML = playing ? ICON.playing : ICON.speaker;
    btn.title = playing ? "Playing — click to pause" : "Read aloud";
  }

  // ───────────────────────── player bar ─────────────────────────

  function mountPlayerBar(colEl, cur) {
    if (!colEl) return;
    const existing = colEl.querySelector(".tts-player");
    if (existing) existing.remove();

    const bar = document.createElement("div");
    bar.className = "tts-player";
    bar.setAttribute("role", "group");
    bar.setAttribute("aria-label", "Read aloud playback controls");

    const row1 = document.createElement("div");
    row1.className = "tts-player-row";

    const playBtn = makeIconButton(ICON.pause, "Pause", () => togglePlayPause());
    playBtn.classList.add("tts-player-btn", "tts-play-pause");

    const stopBtn = makeIconButton(ICON.stop, "Stop", () => stopPlayback());
    stopBtn.classList.add("tts-player-btn");

    const replayBtn = makeIconButton(ICON.replay, "Replay from the start", () => {
      cur.audio.currentTime = 0;
      cur.audio.play();
      setButtonPlayingState(cur.buttonEl, true);
      updatePlayerButtons(cur, true);
    });
    replayBtn.classList.add("tts-player-btn");

    const progressWrap = document.createElement("div");
    progressWrap.className = "tts-progress-wrap";

    const curTime = document.createElement("span");
    curTime.className = "tts-time";
    curTime.textContent = "0:00";

    const progress = document.createElement("input");
    progress.type = "range";
    progress.className = "tts-progress";
    progress.min = "0";
    progress.max = "100";
    progress.value = "0";
    progress.setAttribute("aria-label", "Playback position");

    const totalTime = document.createElement("span");
    totalTime.className = "tts-time";
    totalTime.textContent = "0:00";

    progressWrap.append(curTime, progress, totalTime);
    row1.append(playBtn, stopBtn, replayBtn, progressWrap);

    const row2 = document.createElement("div");
    row2.className = "tts-player-row-secondary";

    const speedGroup = document.createElement("div");
    speedGroup.className = "tts-speed-group";
    speedGroup.setAttribute("role", "group");
    speedGroup.setAttribute("aria-label", "Playback speed");
    SPEEDS.forEach((s) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "tts-speed-btn" + (cur.audio.playbackRate === s ? " is-active" : "");
      b.textContent = s + "×";
      b.addEventListener("click", () => {
        cur.audio.playbackRate = s;
        localStorage.setItem(LS_SPEED_KEY, String(s));
        speedGroup.querySelectorAll(".tts-speed-btn").forEach((x) => x.classList.remove("is-active"));
        b.classList.add("is-active");
      });
      speedGroup.appendChild(b);
    });

    const nowPlaying = document.createElement("span");
    nowPlaying.className = "tts-now-playing";
    nowPlaying.innerHTML = `<span class="tts-bars" aria-hidden="true"><span></span><span></span><span></span></span> Now playing`;

    const volumeGroup = document.createElement("div");
    volumeGroup.className = "tts-volume-group";
    const volIcon = document.createElement("span");
    volIcon.innerHTML = ICON.volume;
    volIcon.style.cursor = "pointer";
    volIcon.title = "Mute / unmute";
    volIcon.setAttribute("role", "button");
    volIcon.tabIndex = 0;
    const volume = document.createElement("input");
    volume.type = "range";
    volume.className = "tts-volume";
    volume.min = "0"; volume.max = "1"; volume.step = "0.05";
    volume.value = String(cur.audio.volume);
    volume.setAttribute("aria-label", "Volume");

    let lastVolume = cur.audio.volume || 1;
    const setVol = (v) => {
      cur.audio.volume = v;
      volume.value = String(v);
      volIcon.innerHTML = v === 0 ? ICON.volumeMute : ICON.volume;
      localStorage.setItem(LS_VOLUME_KEY, String(v));
    };
    volume.addEventListener("input", () => setVol(parseFloat(volume.value)));
    const toggleMute = () => setVol(cur.audio.volume > 0 ? 0 : (lastVolume || 1));
    volIcon.addEventListener("click", () => {
      if (cur.audio.volume > 0) lastVolume = cur.audio.volume;
      toggleMute();
    });
    volIcon.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); volIcon.click(); } });

    volumeGroup.append(volIcon, volume);
    row2.append(speedGroup, nowPlaying, volumeGroup);

    bar.append(row1, row2);
    colEl.appendChild(bar);

    cur.playerEl = bar;
    cur.progressEl = progress;
    cur.curTimeEl = curTime;
    cur.totalTimeEl = totalTime;
    cur.playPauseBtn = playBtn;
    cur.nowPlayingEl = nowPlaying;

    // Wire time/progress updates for this specific audio element.
    cur.audio.addEventListener("loadedmetadata", () => {
      totalTime.textContent = formatDuration(cur.audio.duration);
    });
    cur.audio.addEventListener("timeupdate", () => {
      if (!cur.audio.duration) return;
      progress.value = String((cur.audio.currentTime / cur.audio.duration) * 100);
      curTime.textContent = formatDuration(cur.audio.currentTime);
    });
    progress.addEventListener("input", () => {
      if (!cur.audio.duration) return;
      cur.audio.currentTime = (parseFloat(progress.value) / 100) * cur.audio.duration;
    });
  }

  function makeIconButton(iconHtml, label, onClick) {
    const b = document.createElement("button");
    b.type = "button";
    b.innerHTML = iconHtml;
    b.title = label;
    b.setAttribute("aria-label", label);
    b.addEventListener("click", onClick);
    return b;
  }

  function updatePlayerButtons(cur, playing) {
    if (!cur || !cur.playPauseBtn) return;
    cur.playPauseBtn.innerHTML = playing ? ICON.pause : ICON.play;
    cur.playPauseBtn.title = playing ? "Pause" : "Resume";
    if (cur.nowPlayingEl) cur.nowPlayingEl.style.visibility = playing ? "visible" : "hidden";
  }

  // ───────────────────────── keyboard shortcut ─────────────────────────
  // Alt+R: read the most recent assistant response aloud (optional enhancement).
  document.addEventListener("keydown", (e) => {
    if (!(e.altKey && (e.key === "r" || e.key === "R"))) return;
    const tag = (document.activeElement && document.activeElement.tagName) || "";
    if (tag === "TEXTAREA" || tag === "INPUT") return;
    const bubbles = document.querySelectorAll(".msg.assistant .msg-bubble");
    if (!bubbles.length) return;
    const lastBubble = bubbles[bubbles.length - 1];
    const actions = lastBubble.parentElement.querySelector(".msg-actions");
    const btn = actions && actions.querySelector(".tts-btn");
    if (btn) { e.preventDefault(); btn.click(); }
  });

  // ───────────────────────── boot ─────────────────────────

  function init() {
    const log = document.getElementById("chat-log");
    if (!log) { setTimeout(init, 200); return; } // static/index.html not fully parsed yet
    attachButtons(log);
    checkAvailability();

    const observer = new MutationObserver(() => attachButtons(log));
    observer.observe(log, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
