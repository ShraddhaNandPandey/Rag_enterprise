"""
tools/query_router.py — Routes questions to "tabular", "semantic", or "hybrid"
(PART 7 of the RAG audit) pipelines.

Strategy:
  1. Filename hints — if the question mentions a known tabular/semantic filename, route there.
     If it mentions BOTH a tabular and a semantic filename → hybrid.
  2. Keyword heuristics — fast, free, catches most obvious cases.
     If BOTH tabular and semantic keywords are present → hybrid.
  3. LLM classification fallback — for ambiguous questions, ask the configured LLM,
     which can also answer "both".

Backward compatible: when a question only ever scores on one side (the
overwhelming majority of questions), routing behaves exactly as before —
"hybrid" is only returned when there is a genuine, positive signal for both
pipelines. Set ENABLE_HYBRID_ROUTING=false to disable this third route
entirely and restore the original strict tabular/semantic binary behaviour.
"""

import json
import re
import urllib.request
import urllib.error
from typing import Dict, List, Optional

from config.settings import OLLAMA_BASE_URL, LLM_MODEL, ROUTER_SYSTEM_PROMPT, ENABLE_HYBRID_ROUTING
from utils.logger import get_logger

logger = get_logger("router")

_TABULAR_KEYWORDS = [
    "total", "sum", "average", "avg", "count", "maximum", "max", "minimum", "min",
    "how many", "how much", "percentage", "percent", "growth", "rate",
    "highest", "lowest", "top ", "rank", "ranking", "compare", "comparison",
    "mean", "median", "aggregate", "calculate", "number of",
    # Row-lookup phrasing — these ask for a specific record/row, which is a SQL
    # "SELECT * WHERE ..." query, not a semantic/document question, even though
    # they don't contain an obvious aggregation keyword.
    "detail of", "details of", "details for", "detail for", "info about",
    "information about", "info on", "information on", "record of", "record for",
    "profile of", "who is", "tell me about", "show me", "list of", "data for",
    "data on",
]

_SEMANTIC_KEYWORDS = [
    "what is", "explain", "describe", "why", "how to", "policy", "procedure",
    "definition", "meaning", "summary", "summarize", "process", "guideline",
    "rule", "overview",
]


class QueryRouter:
    """Classify a question as 'tabular' or 'semantic'."""

    def __init__(self, model: str = LLM_MODEL, ollama_url: str = OLLAMA_BASE_URL):
        self.model = model
        self.ollama_url = ollama_url
        self.has_tabular = False
        self.has_semantic = False
        self.tabular_sources: List[str] = []
        self.semantic_sources: List[str] = []

    def update_has_tabular(self, has_tabular: bool) -> None:
        self.has_tabular = has_tabular

    def update_has_semantic(self, has_semantic: bool) -> None:
        self.has_semantic = has_semantic

    def update_sources(self, tabular_sources: List[str], semantic_sources: List[str]) -> None:
        self.tabular_sources = tabular_sources or []
        self.semantic_sources = semantic_sources or []

    def route_with_evidence(
        self,
        question: str,
        vector_store=None,
        duckdb_manager=None,
    ) -> Dict[str, str]:
        """
        PROBLEM 1 (Router): decide the retrieval strategy from actual evidence
        rather than keyword lists — probe both stores cheaply and let the
        real, measured relevance signal drive the decision. Only when the
        evidence is genuinely ambiguous does this defer to route()'s
        keyword/LLM heuristics, which remain unchanged for full backward
        compatibility (and as the behaviour when no stores are supplied).

        Evidence gathered:
          - Semantic evidence: top hybrid_search score against ChromaDB/BM25.
          - Table evidence: word overlap between the question and the
            discovered table/column names (i.e. actual schema, not a
            hardcoded keyword list) — a proxy for "does a table exist whose
            structure plausibly answers this question".
        """
        if vector_store is None or duckdb_manager is None:
            return self.route(question)
        if not self.has_tabular and not self.has_semantic:
            return {"query_type": "semantic", "method": "no_data"}

        q_tokens = set(re.findall(r"[a-z0-9_]+", question.lower()))

        # --- Semantic evidence: real retrieval, not a guess ---
        semantic_score = 0.0
        if self.has_semantic:
            try:
                probe = vector_store.hybrid_search(question, k=1)
                if probe:
                    semantic_score = float(probe[0].get("confidence", probe[0].get("score", 0.0)))
            except Exception as e:
                logger.debug(f"Evidence probe: semantic search failed, ignoring: {e}")

        # --- Table evidence: overlap with discovered schema, not hardcoded terms ---
        table_score = 0.0
        if self.has_tabular:
            try:
                schema_text = duckdb_manager.get_schema()
                schema_tokens = set(re.findall(r"[a-z0-9_]+", schema_text.lower()))
                overlap = q_tokens & schema_tokens
                # Normalize by question length so short/generic questions don't
                # trivially "match" just because of common short tokens.
                table_score = len(overlap) / max(len(q_tokens), 1)
            except Exception as e:
                logger.debug(f"Evidence probe: schema overlap failed, ignoring: {e}")

        SEMANTIC_STRONG = 0.35
        TABLE_STRONG = 0.25
        # Below this, a side is treated as "no real evidence at all" rather
        # than merely "not strong enough alone" — the distinction matters
        # for deciding when it's safe to skip hybrid consideration entirely.
        SEMANTIC_NEGLIGIBLE = 0.10
        TABLE_NEGLIGIBLE = 0.08

        semantic_hit = semantic_score >= SEMANTIC_STRONG
        table_hit = table_score >= TABLE_STRONG

        if ENABLE_HYBRID_ROUTING and semantic_hit and table_hit:
            return {"query_type": "hybrid", "method": "evidence_probe_both",
                    "semantic_score": round(semantic_score, 3), "table_score": round(table_score, 3)}

        # One side is strong and the other genuinely has ~nothing — safe to
        # commit to a single pipeline directly from evidence.
        if table_hit and semantic_score < SEMANTIC_NEGLIGIBLE:
            return {"query_type": "tabular", "method": "evidence_probe_table",
                    "semantic_score": round(semantic_score, 3), "table_score": round(table_score, 3)}
        if semantic_hit and table_score < TABLE_NEGLIGIBLE:
            return {"query_type": "semantic", "method": "evidence_probe_semantic",
                    "semantic_score": round(semantic_score, 3), "table_score": round(table_score, 3)}

        # Either both sides are weak, or one is strong but the other still
        # shows a non-trivial (if sub-threshold) signal — evidence alone
        # can't safely rule out a hybrid question here. Defer to the
        # existing filename-hint / keyword / LLM-classification chain,
        # which is where hybrid detection via genuine dual keyword signals
        # (e.g. "explain the policy AND show average salary by department")
        # already lives.
        return self.route(question)

    def route(self, question: str) -> Dict[str, str]:
        """
        Return {"query_type": "tabular"|"semantic", "method": str}.
        method explains which strategy decided the route (for logging/debugging).
        """
        if not self.has_tabular:
            return {"query_type": "semantic", "method": "no_tabular_data"}

        # If the semantic/vector store has no documents at all (e.g. the only uploads
        # were CSV/XLSX files, which are ingested into DuckDB only — see
        # ingestion_service.py's docstring on never embedding numerical data), routing
        # to "semantic" can only ever produce "No documents ingested yet." Skip the
        # keyword/LLM steps entirely and force tabular, since that's the only pipeline
        # that actually has any data to answer from.
        if not self.has_semantic:
            return {"query_type": "tabular", "method": "semantic_store_empty"}

        q_lower = question.lower()

        # 1. Filename hints — PART 7: mentioning both a tabular and a
        # semantic filename in the same question is itself a hybrid signal.
        tabular_hint = any(
            (fname.rsplit(".", 1)[0].lower()) in q_lower
            for fname in self.tabular_sources if fname
        )
        semantic_hint = any(
            (fname.rsplit(".", 1)[0].lower()) in q_lower
            for fname in self.semantic_sources if fname
        )
        if ENABLE_HYBRID_ROUTING and tabular_hint and semantic_hint:
            return {"query_type": "hybrid", "method": "filename_hint_both"}
        if tabular_hint:
            return {"query_type": "tabular", "method": "filename_hint"}
        if semantic_hint:
            return {"query_type": "semantic", "method": "filename_hint"}

        # 2. Keyword heuristics
        tabular_score = sum(1 for kw in _TABULAR_KEYWORDS if kw in q_lower)
        semantic_score = sum(1 for kw in _SEMANTIC_KEYWORDS if kw in q_lower)

        # PART 7: a genuine positive signal on BOTH sides (e.g. "explain the
        # overtime policy and list employees eligible for it") means the
        # question needs DuckDB + ChromaDB together, not a forced pick of
        # whichever score is marginally higher.
        if ENABLE_HYBRID_ROUTING and tabular_score > 0 and semantic_score > 0:
            return {"query_type": "hybrid", "method": "keyword_heuristic_both"}
        if tabular_score > 0 and tabular_score > semantic_score:
            return {"query_type": "tabular", "method": "keyword_heuristic"}
        if semantic_score > 0 and semantic_score > tabular_score:
            return {"query_type": "semantic", "method": "keyword_heuristic"}

        # 3. LLM fallback for ambiguous cases
        try:
            llm_route = self._llm_classify(question)
            if llm_route:
                if llm_route == "hybrid" and not ENABLE_HYBRID_ROUTING:
                    llm_route = "semantic"
                return {"query_type": llm_route, "method": "llm_classification"}
        except Exception as e:
            logger.warning(f"LLM routing failed, defaulting to semantic: {e}")

        return {"query_type": "semantic", "method": "default_fallback"}

    def _llm_classify(self, question: str) -> Optional[str]:
        """Ask the LLM to classify the question as tabular, semantic, or both."""
        prompt = ROUTER_SYSTEM_PROMPT.format(question=question)
        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.0, "num_predict": 10},
        }).encode()

        req = urllib.request.Request(
            f"{self.ollama_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            answer = data.get("response", "").strip().lower()

        if "both" in answer or "hybrid" in answer:
            return "hybrid"
        if "tabular" in answer:
            return "tabular"
        if "semantic" in answer:
            return "semantic"
        return None
