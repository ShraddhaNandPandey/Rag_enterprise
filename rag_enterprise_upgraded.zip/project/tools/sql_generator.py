"""
tools/sql_generator.py — LLM-driven DuckDB SQL generation with safety validation.
"""

import json
import re
import urllib.request
import urllib.error
from typing import Any, Dict, Optional, Tuple

from config.settings import (
    OLLAMA_BASE_URL, LLM_MODEL, LLM_TIMEOUT, SQL_SYSTEM_PROMPT, SQL_FORBIDDEN_PATTERNS,
)
from utils.logger import get_logger

logger = get_logger("sql_generator")


def _call_ollama(prompt: str, model: str, base_url: str, timeout: int = LLM_TIMEOUT) -> str:
    payload = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.0, "num_predict": 512},
    }).encode()

    req = urllib.request.Request(
        f"{base_url}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data.get("response", "").strip()
    except urllib.error.URLError as e:
        raise ConnectionError(f"Ollama unreachable at {base_url}: {e}")
    except Exception as e:
        raise ConnectionError(f"Ollama call failed: {e}")


def _clean_sql(raw: str) -> str:
    """Strip markdown fences, preambles, and trailing semicolons/explanations."""
    text = raw.strip()

    # Remove markdown code fences
    text = re.sub(r"^```(?:sql)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"```\s*$", "", text)
    text = text.strip()

    # If the LLM added a preamble like "Here is the SQL:", try to extract from SELECT/WITH onward
    match = re.search(r"(?is)\b(SELECT|WITH)\b.*", text)
    if match:
        text = match.group(0).strip()

    # Cut at first semicolon followed by more text (multi-statement attempt) — keep only first statement
    # but allow a single trailing semicolon
    if ";" in text:
        first_stmt = text.split(";")[0].strip()
        text = first_stmt

    return text.strip()


def validate_sql(sql: str) -> Tuple[bool, str]:
    """Validate that SQL is a safe, read-only SELECT/WITH statement."""
    if not sql or not sql.strip():
        return False, "Empty SQL."

    sql_upper = sql.upper().strip()
    if not (sql_upper.startswith("SELECT") or sql_upper.startswith("WITH")):
        return False, "Only SELECT (or WITH...SELECT) queries are allowed."

    for pattern in SQL_FORBIDDEN_PATTERNS:
        if re.search(pattern, sql_upper, re.IGNORECASE):
            return False, f"Forbidden pattern detected: {pattern}"

    return True, "OK"


def generate_sql(
    question: str,
    table_schema: str,
    model: str = LLM_MODEL,
    base_url: str = OLLAMA_BASE_URL,
    sample_rows: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate a DuckDB SQL query from a natural-language question.

    Returns:
      {
        "sql": str | None,
        "is_valid": bool,
        "validation_message": str,
        "raw_response": str,
      }
    """
    schema_block = table_schema
    if sample_rows:
        schema_block = f"{table_schema}\n\nSample data:\n{sample_rows}"

    prompt = SQL_SYSTEM_PROMPT.format(table_schema=schema_block, question=question)

    try:
        raw_response = _call_ollama(prompt, model=model, base_url=base_url)
    except ConnectionError as e:
        logger.error(f"SQL generation LLM call failed: {e}")
        return {
            "sql": None,
            "is_valid": False,
            "validation_message": f"LLM unavailable: {e}",
            "raw_response": "",
        }

    sql = _clean_sql(raw_response)
    is_valid, message = validate_sql(sql)

    if not is_valid:
        logger.warning(f"Generated SQL failed validation: {message} | Raw: {raw_response[:200]}")

    return {
        "sql": sql if is_valid else None,
        "is_valid": is_valid,
        "validation_message": message,
        "raw_response": raw_response,
    }


SQL_REPAIR_PROMPT = """You are a SQL expert for DuckDB. A previously generated query failed to
execute. Fix it using the exact error message below. Output ONLY the corrected raw SQL —
NO explanation, NO markdown, NO backticks, NO preamble.

Tables and Schema:
{table_schema}

Original question: {question}

Failing SQL:
{failing_sql}

DuckDB error:
{error_message}

Common causes to check for:
- A string function (e.g. RIGHT, LEFT, SUBSTR) used on a numeric column — use ROUND, CAST, or
  plain arithmetic instead.
- An aggregate function (AVG, SUM, COUNT, MIN, MAX) used in ORDER BY/SELECT alongside a
  non-aggregated column with no GROUP BY — either add GROUP BY for every non-aggregated column,
  or remove the aggregate if the question actually means per-row arithmetic.
- A misspelled or invented function name — use only real DuckDB SQL functions.
- A column name that doesn't match the schema exactly (case-sensitive).
- A computed value that's only in ORDER BY but not in the SELECT list — make sure every value
  the question asks about is included in SELECT with a clear alias.
- An unnecessary JOIN: if the error is "column X does not exist" on a joined table, first check
  whether ANOTHER table already has column X directly. If so, the real fix is to DROP the join
  entirely and query that single table instead — do not just swap in whatever column name DuckDB
  suggested as a "close match" on the wrong table, since that produces a query that runs without
  error but answers a different question than the one asked.

Corrected SQL:"""


def repair_sql(
    question: str,
    table_schema: str,
    failing_sql: str,
    error_message: str,
    model: str = LLM_MODEL,
    base_url: str = OLLAMA_BASE_URL,
) -> Dict[str, Any]:
    """
    Re-prompt the LLM with the exact DuckDB execution error and ask it to self-correct.
    Used as a one-shot retry after the first generated SQL fails to execute, so a single
    hallucinated function name or GROUP BY mistake doesn't immediately fall back to semantic
    search and produce a misleading "no documents" message.
    """
    prompt = SQL_REPAIR_PROMPT.format(
        table_schema=table_schema,
        question=question,
        failing_sql=failing_sql,
        error_message=error_message,
    )

    try:
        raw_response = _call_ollama(prompt, model=model, base_url=base_url)
    except ConnectionError as e:
        logger.error(f"SQL repair LLM call failed: {e}")
        return {
            "sql": None,
            "is_valid": False,
            "validation_message": f"LLM unavailable: {e}",
            "raw_response": "",
        }

    sql = _clean_sql(raw_response)
    is_valid, message = validate_sql(sql)

    if not is_valid:
        logger.warning(f"Repaired SQL still failed validation: {message} | Raw: {raw_response[:200]}")
    else:
        logger.info(f"SQL repaired successfully | Original: {failing_sql[:100]} | Fixed: {sql[:100]}")

    return {
        "sql": sql if is_valid else None,
        "is_valid": is_valid,
        "validation_message": message,
        "raw_response": raw_response,
    }


def format_query_result(query_result: Dict[str, Any], question: str = "") -> str:
    """Format a DuckDB query result dict into a readable text block for the LLM prompt."""
    columns = query_result.get("columns", [])
    rows = query_result.get("rows", [])
    row_count = query_result.get("row_count", len(rows))

    if row_count == 0:
        return "No rows returned."

    # Limit displayed rows to avoid blowing up the prompt context window, but allow
    # enough rows that common "list all matching X" questions (e.g. up to ~200 students)
    # aren't truncated before the LLM even sees most of the data.
    MAX_DISPLAY_ROWS = 200
    display_rows = rows[:MAX_DISPLAY_ROWS]

    lines = [f"Row count: {row_count}", f"Columns: {', '.join(columns)}"]

    if row_count > MAX_DISPLAY_ROWS:
        lines.append(
            f"*** WARNING: only the first {MAX_DISPLAY_ROWS} of {row_count} total rows are "
            f"shown below. You MUST still report the TOTAL row count ({row_count}) in your "
            f"answer, and explicitly say that the list below is a partial sample, not all rows. ***"
        )
    lines.append("")

    for i, row in enumerate(display_rows, 1):
        row_str = ", ".join(f"{k}={v}" for k, v in row.items())
        lines.append(f"{i}. {row_str}")

    if row_count > MAX_DISPLAY_ROWS:
        lines.append(f"... and {row_count - MAX_DISPLAY_ROWS} more row(s) not shown above.")

    return "\n".join(lines)