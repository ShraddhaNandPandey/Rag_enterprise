"""
utils/doc_identity.py — Deterministic document identity for cross-document isolation.

PROBLEM 5 (Document Isolation): every ingested file must carry a stable
document_id, a content_hash (so the same bytes always map to the same id,
and so a changed file is detected as a *new* version rather than silently
merging with stale rows/chunks from the old one), a version counter, and
its originating source path.

This module only computes identity — it does not touch ChromaDB or DuckDB.
It is called once per file from loaders/file_loader.py and the resulting
fields are merged into every doc's `metadata` dict, so they flow, for free,
through the existing chunker -> vectorstore pipeline (which already copies
the whole metadata dict onto every chunk) and through the existing DuckDB
registration calls (which already accept a metadata dict).

Purely additive: existing metadata keys (source, source_name, type, page,
...) are untouched, so nothing that reads the old keys breaks.
"""

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict

from utils.logger import get_logger

logger = get_logger("doc_identity")

# Small on-disk ledger mapping content_hash -> {document_id, version, first_seen}
# so that re-ingesting the exact same file content always resolves to the same
# document_id, while a *changed* file (different bytes) under the same filename
# gets a NEW document_id and an incremented version. This is what lets the
# ingestion layer tell "duplicate re-upload" apart from "this file was updated"
# without guessing from the filename alone.
_LEDGER_PATH = Path(__file__).resolve().parent.parent / "data" / "document_identity_ledger.json"


def _load_ledger() -> Dict[str, Any]:
    try:
        if _LEDGER_PATH.exists():
            return json.loads(_LEDGER_PATH.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning(f"Could not read document identity ledger, starting fresh: {e}")
    return {}


def _save_ledger(ledger: Dict[str, Any]) -> None:
    try:
        _LEDGER_PATH.parent.mkdir(parents=True, exist_ok=True)
        _LEDGER_PATH.write_text(json.dumps(ledger, indent=2), encoding="utf-8")
    except Exception as e:
        logger.warning(f"Could not persist document identity ledger: {e}")


def compute_content_hash(file_path: str) -> str:
    """SHA-256 of the file's raw bytes. Same bytes -> same hash, always."""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def get_document_identity(file_path: str) -> Dict[str, Any]:
    """
    Return {document_id, content_hash, version, source, ingested_at} for a file.

    - document_id is derived from the content hash (12-char prefix, stable and
      short enough to be a friendly DuckDB/Chroma metadata value).
    - version increments only when the SAME filename is re-ingested with
      DIFFERENT content — a byte-identical re-upload keeps version 1 and is
      treated as a duplicate by the ingestion layer, not a new version.
    """
    path = Path(file_path)
    content_hash = compute_content_hash(file_path)
    document_id = f"doc_{content_hash[:12]}"

    ledger = _load_ledger()
    name_key = path.name

    version = 1
    prior = ledger.get(name_key)
    if prior and prior.get("content_hash") != content_hash:
        version = int(prior.get("version", 1)) + 1
    elif prior and prior.get("content_hash") == content_hash:
        version = int(prior.get("version", 1))

    ledger[name_key] = {
        "content_hash": content_hash,
        "document_id":  document_id,
        "version":      version,
        "updated_at":   time.time(),
    }
    _save_ledger(ledger)

    is_duplicate = bool(prior and prior.get("content_hash") == content_hash and prior.get("version") == version
                         and prior.get("document_id") == document_id)

    return {
        "document_id":  document_id,
        "content_hash": content_hash,
        "version":      version,
        "source":       str(path),
        "is_duplicate_content": is_duplicate,
    }
