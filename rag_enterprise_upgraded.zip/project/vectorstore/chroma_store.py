"""
vectorstore/chroma_store.py — ChromaDB Vector Store with Hybrid Search (BM25 + Dense).

Features:
- ChromaDB persistent store for embeddings
- BM25 sparse retrieval
- Hybrid search with configurable weighting
- MMR (Maximal Marginal Relevance) for diversity
- Source-level filtering and deletion
"""

import json
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from config.settings import (
    CHROMA_COLLECTION, CHROMA_PATH, EMBED_MODEL,
    MMR_FETCH_K, OLLAMA_BASE_URL,
    SCORE_THRESHOLD, TOP_K, BM25_WEIGHT, VECTOR_WEIGHT,
    EMBED_BATCH_SIZE,
)
from utils.logger import get_logger

logger = get_logger("vectorstore")


# ─── Embedding helper ─────────────────────────────────────────────────────────

def _embed_texts(texts: List[str], model: str = EMBED_MODEL, base_url: str = OLLAMA_BASE_URL) -> List[List[float]]:
    """Embed a batch of texts using Ollama's /api/embed endpoint."""
    import urllib.request
    import urllib.error

    payload = json.dumps({"model": model, "input": texts}).encode()
    req = urllib.request.Request(
        f"{base_url}/api/embed",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read())
            embeddings = data.get("embeddings", [])
            if not embeddings:
                # Fallback to single embed endpoint
                raise ValueError("No embeddings returned")
            return embeddings
    except Exception as e:
        logger.error(f"Embedding failed: {e}")
        raise


def _embed_single(text: str, model: str = EMBED_MODEL, base_url: str = OLLAMA_BASE_URL) -> List[float]:
    """Embed a single text string."""
    return _embed_texts([text], model=model, base_url=base_url)[0]


# ─── BM25 index (in-memory, rebuilt on each search from stored corpus) ─────────

class _BM25Index:
    """Lightweight wrapper around rank_bm25 for hybrid search."""

    def __init__(self):
        self._corpus: List[str] = []
        self._ids: List[str] = []
        self._index = None

    def clear(self):
        self._corpus = []
        self._ids = []
        self._index = None

    def build(self, texts: List[str], ids: List[str]) -> None:
        from rank_bm25 import BM25Okapi
        self._corpus = texts
        self._ids = ids
        tokenized = [t.lower().split() for t in texts]
        self._index = BM25Okapi(tokenized)

    def search(self, query: str, k: int = TOP_K) -> List[Tuple[str, float]]:
        """Return list of (id, score) sorted by descending BM25 score."""
        if self._index is None or not self._corpus:
            return []
        tokens = query.lower().split()
        scores = self._index.get_scores(tokens)
        # Pair with ids and sort
        ranked = sorted(zip(self._ids, scores), key=lambda x: x[1], reverse=True)
        return [(doc_id, float(score)) for doc_id, score in ranked[:k] if score > 0]


# ─── VectorStore ──────────────────────────────────────────────────────────────

class VectorStore:
    """ChromaDB-backed vector store with hybrid BM25+dense search."""

    def __init__(
        self,
        path: str = CHROMA_PATH,
        collection_name: str = CHROMA_COLLECTION,
        embed_model: str = EMBED_MODEL,
        ollama_url: str = OLLAMA_BASE_URL,
    ):
        self.path = path
        self.collection_name = collection_name
        self.embed_model = embed_model
        self.ollama_url = ollama_url
        self._bm25 = _BM25Index()

        import chromadb
        from chromadb.config import Settings as ChromaSettings

        try:
            Path(path).mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(
                f"Cannot create ChromaDB storage directory '{path}': {e}. "
                f"Check filesystem permissions and available disk space."
            ) from e

        try:
            self._client = chromadb.PersistentClient(
                path=path,
                settings=ChromaSettings(
                    anonymized_telemetry=False,
                    allow_reset=True,
                ),
            )
            self.collection = self._client.get_or_create_collection(
                name=collection_name,
                metadata={"hnsw:space": "cosine"},
            )
        except Exception as e:
            raise RuntimeError(
                f"Failed to initialize ChromaDB at '{path}' (collection='{collection_name}'): {e}. "
                f"The store may be corrupted or locked by another process."
            ) from e

        try:
            doc_count = self.collection.count()
        except Exception as e:
            logger.warning(f"Could not get initial collection count: {e}")
            doc_count = "?"

        logger.info(
            f"VectorStore initialized | path={path} | "
            f"collection={collection_name} | docs={doc_count}"
        )
        # Rebuild BM25 from existing corpus
        try:
            self._rebuild_bm25()
        except Exception as e:
            logger.warning(f"Initial BM25 index build failed (will retry on next ingest): {e}")

    # ── Ingestion ─────────────────────────────────────────────────────────────

    def add_chunks(self, chunks: List[Dict[str, Any]]) -> int:
        """Embed and store a list of chunks. Returns count of successfully stored chunks."""
        if not chunks:
            return 0

        embedded = 0
        batch_size = EMBED_BATCH_SIZE

        for i in range(0, len(chunks), batch_size):
            batch = chunks[i: i + batch_size]
            texts = [c["text"] for c in batch]

            try:
                embeddings = _embed_texts(texts, model=self.embed_model, base_url=self.ollama_url)
            except Exception as e:
                logger.error(f"Embedding batch {i//batch_size} failed: {e}")
                continue

            ids = [str(uuid.uuid4()) for _ in batch]
            metadatas = [c.get("metadata", {}) for c in batch]

            # ChromaDB requires metadata values to be str/int/float/bool
            safe_metas = []
            for m in metadatas:
                safe = {}
                for k, v in m.items():
                    if isinstance(v, (str, int, float, bool)):
                        safe[k] = v
                    else:
                        safe[k] = str(v)
                safe_metas.append(safe)

            try:
                self.collection.add(
                    ids=ids,
                    embeddings=embeddings,
                    documents=texts,
                    metadatas=safe_metas,
                )
                embedded += len(batch)
            except Exception as e:
                logger.error(f"ChromaDB add failed for batch {i//batch_size}: {e}")

        # Rebuild BM25 after new data
        self._rebuild_bm25()
        logger.info(f"Added {embedded}/{len(chunks)} chunks to vector store")
        return embedded

    # ── Search ────────────────────────────────────────────────────────────────

    def hybrid_search(
        self,
        query: str,
        k: int = TOP_K,
        filters: Optional[Dict] = None,
    ) -> List[Dict[str, Any]]:
        """
        Hybrid search: combines dense (ChromaDB cosine) + sparse (BM25).
        Falls back to dense-only if BM25 fails.
        """
        dense_results = self._dense_search(query, k=max(k * 2, MMR_FETCH_K), filters=filters)

        try:
            bm25_results = self._bm25_search(query, k=max(k * 2, MMR_FETCH_K), filters=filters)
        except Exception as e:
            logger.warning(f"BM25 search failed, using dense only: {e}")
            bm25_results = []

        merged = self._merge_results(dense_results, bm25_results, k=k)
        return merged

    def _dense_search(
        self, query: str, k: int = TOP_K, filters: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """Dense vector search via ChromaDB."""
        if self.collection.count() == 0:
            return []
        try:
            query_embedding = _embed_single(query, model=self.embed_model, base_url=self.ollama_url)
        except Exception as e:
            logger.error(f"Query embedding failed: {e}")
            return []

        kwargs = {
            "query_embeddings": [query_embedding],
            "n_results": min(k, self.collection.count()),
            "include": ["documents", "metadatas", "distances"],
        }
        if filters:
            kwargs["where"] = filters

        try:
            results = self.collection.query(**kwargs)
        except Exception as e:
            logger.error(f"ChromaDB query failed: {e}")
            return []

        chunks = []
        if results and results.get("documents"):
            docs = results["documents"][0]
            metas = results["metadatas"][0]
            dists = results["distances"][0]
            for doc, meta, dist in zip(docs, metas, dists):
                score = max(0.0, 1.0 - dist)  # cosine distance → similarity
                if score >= SCORE_THRESHOLD:
                    chunks.append({
                        "text": doc,
                        "metadata": meta,
                        "score": round(score, 4),
                        "confidence": round(score, 4),
                        "source": "dense",
                    })
        return chunks

    def _bm25_search(
        self, query: str, k: int = TOP_K, filters: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """BM25 sparse search over in-memory index."""
        bm25_hits = self._bm25.search(query, k=k)
        if not bm25_hits:
            return []

        ids = [hit[0] for hit in bm25_hits]
        scores_map = {hit[0]: hit[1] for hit in bm25_hits}

        try:
            results = self.collection.get(
                ids=ids,
                include=["documents", "metadatas"],
            )
        except Exception as e:
            logger.error(f"ChromaDB get for BM25 failed: {e}")
            return []

        chunks = []
        if results and results.get("documents"):
            max_score = max(scores_map.values()) if scores_map else 1.0
            for doc_id, doc, meta in zip(results["ids"], results["documents"], results["metadatas"]):
                raw_score = scores_map.get(doc_id, 0.0)
                norm_score = raw_score / max_score if max_score > 0 else 0.0
                # Apply metadata filter manually if needed
                if filters and not self._matches_filter(meta, filters):
                    continue
                chunks.append({
                    "text": doc,
                    "metadata": meta,
                    "score": round(norm_score, 4),
                    "confidence": round(norm_score, 4),
                    "source": "bm25",
                })
        return chunks

    def _merge_results(
        self,
        dense: List[Dict],
        bm25: List[Dict],
        k: int = TOP_K,
    ) -> List[Dict[str, Any]]:
        """Weighted merge of dense and BM25 results. Deduplicates by text."""
        seen: Dict[str, Dict] = {}

        for chunk in dense:
            key = chunk["text"][:200]
            if key not in seen:
                seen[key] = dict(chunk)
                seen[key]["_dense_score"] = chunk["score"]
                seen[key]["_bm25_score"] = 0.0
            else:
                seen[key]["_dense_score"] = max(seen[key].get("_dense_score", 0), chunk["score"])

        for chunk in bm25:
            key = chunk["text"][:200]
            if key not in seen:
                seen[key] = dict(chunk)
                seen[key]["_dense_score"] = 0.0
                seen[key]["_bm25_score"] = chunk["score"]
            else:
                seen[key]["_bm25_score"] = max(seen[key].get("_bm25_score", 0), chunk["score"])

        for key in seen:
            ds = seen[key].get("_dense_score", 0.0)
            bs = seen[key].get("_bm25_score", 0.0)
            hybrid = VECTOR_WEIGHT * ds + BM25_WEIGHT * bs
            seen[key]["score"] = round(hybrid, 4)
            seen[key]["confidence"] = round(hybrid, 4)

        ranked = sorted(seen.values(), key=lambda x: x["score"], reverse=True)
        # Clean up internal keys
        for r in ranked:
            r.pop("_dense_score", None)
            r.pop("_bm25_score", None)
        return ranked[:k]

    # ── Filter helpers ────────────────────────────────────────────────────────

    def _matches_filter(self, metadata: Dict, filters: Dict) -> bool:
        """Check if metadata satisfies a simple equality filter dict."""
        for k, v in filters.items():
            if isinstance(v, list):
                if metadata.get(k) not in v:
                    return False
            elif metadata.get(k) != v:
                return False
        return True

    def build_source_filter(self, source_names: List[str]) -> Dict:
        """Build a ChromaDB where clause to restrict to given source filenames."""
        if not source_names:
            return {}
        if len(source_names) == 1:
            return {"source_name": source_names[0]}
        return {"source_name": {"$in": source_names}}

    def _build_where_clause(self, filters: Dict) -> Dict:
        """
        Build a ChromaDB-compatible $and where clause from a flat filter dict.
        Handles special 'source_name' list key.
        """
        if not filters:
            return {}
        conditions = []
        for k, v in filters.items():
            if isinstance(v, list):
                conditions.append({k: {"$in": v}})
            else:
                conditions.append({k: v})
        if len(conditions) == 1:
            return conditions[0]
        return {"$and": conditions}

    # ── Knowledge base & management ───────────────────────────────────────────

    def get_knowledge_base(self) -> List[Dict[str, Any]]:
        """Return per-source aggregated stats for the KB panel."""
        if self.collection.count() == 0:
            return []

        try:
            results = self.collection.get(include=["metadatas"])
        except Exception as e:
            logger.error(f"get_knowledge_base failed: {e}")
            return []

        source_counts: Dict[str, int] = {}
        for meta in results.get("metadatas", []):
            src = meta.get("source_name", "unknown")
            source_counts[src] = source_counts.get(src, 0) + 1

        return [
            {"source_name": name, "chunk_count": count}
            for name, count in sorted(source_counts.items())
        ]

    def list_sources(self) -> List[str]:
        """Return list of unique source filenames in the collection."""
        kb = self.get_knowledge_base()
        return [entry["source_name"] for entry in kb]

    def get_stats(self) -> Dict[str, Any]:
        """Return basic collection stats. Never raises — degrades to zero/empty on failure."""
        try:
            count = self.collection.count()
        except Exception as e:
            logger.error(f"get_stats: collection.count() failed: {e}")
            count = 0
        sources = self.list_sources()
        return {
            "total_chunks": count,
            "unique_sources": len(sources),
            "sources": sources,
        }

    def delete_source(self, source_name: str) -> int:
        """Delete all chunks for a given source filename. Returns count deleted."""
        try:
            results = self.collection.get(
                where={"source_name": source_name},
                include=["documents"],
            )
            ids = results.get("ids", [])
            if ids:
                self.collection.delete(ids=ids)
                self._rebuild_bm25()
                logger.info(f"Deleted {len(ids)} chunks for source '{source_name}'")
            return len(ids)
        except Exception as e:
            logger.error(f"delete_source failed for '{source_name}': {e}")
            return 0

    def reset(self) -> None:
        """Delete all data from the collection."""
        try:
            self._client.delete_collection(self.collection_name)
            self.collection = self._client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},
            )
            self._bm25.clear()
            logger.warning(f"Vector store reset — collection '{self.collection_name}' cleared.")
        except Exception as e:
            logger.error(f"Reset failed: {e}")

    # ── BM25 index management ─────────────────────────────────────────────────

    def _rebuild_bm25(self) -> None:
        """Rebuild in-memory BM25 index from all current ChromaDB documents."""
        count = self.collection.count()
        if count == 0:
            self._bm25.clear()
            return
        try:
            results = self.collection.get(include=["documents"])
            texts = results.get("documents", [])
            ids = results.get("ids", [])
            if texts and ids:
                self._bm25.build(texts, ids)
        except Exception as e:
            logger.warning(f"BM25 rebuild failed: {e}")
